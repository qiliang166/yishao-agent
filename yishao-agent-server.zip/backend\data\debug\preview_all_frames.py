# -*- coding: utf-8 -*-
"""渲染提取的全部 16 帧（真实几何 + 原 PPT 原文）成一页缩略图预览，浏览器直接看。"""
import io, sys, json
from pathlib import Path
DEBUG = Path(__file__).resolve().parent
sys.path.insert(0, str(DEBUG))
sys.path.insert(0, str(DEBUG.parents[1]))

from frame_renderer import render_frame, assign_content_keys
from services.ppt_service import _resolve_color_vars, _load_scheme_data, _build_root_vars

scheme = _load_scheme_data("business", "chinese-red")
root = _build_root_vars(scheme)
d = json.load(open(DEBUG / "frameset_abalone.json", encoding="utf-8"))

cards = []
for f in d["frames"]:
    frame = assign_content_keys(f)
    inner = _resolve_color_vars(render_frame(frame, {}), scheme, css_vars=True)  # {} → 回退原文
    label = f"page{f['source_page']:02d} · {f['page_type']} · {f['container_count']}容器"
    cards.append(
        f"<div style='display:inline-block;vertical-align:top;margin:10px;'>"
        f"<div style='font:700 14px sans-serif;color:#111;margin:0 0 6px;'>{label}</div>"
        f"<div style='width:512px;height:288px;overflow:hidden;border:1px solid #bbb;box-shadow:0 2px 8px rgba(0,0,0,.15);'>"
        f"<div style='transform:scale(0.4);transform-origin:top left;'>{inner}</div></div></div>")

doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n"
       f"*{{margin:0;padding:0;box-sizing:border-box}}</style></head>"
       f"<body style='background:#eee;padding:16px;'>"
       f"<h2 style='font:800 22px sans-serif;color:#111;margin:8px 12px 16px;'>"
       f"从「鲍鱼一品煲SOP」提取的全部 16 个框架（真实几何 + 原文 · chinese-red 配色）</h2>"
       f"{''.join(cards)}</body></html>")
out = DEBUG / "all_frames_preview.html"
out.write_text(doc, encoding="utf-8")
w = io.open(1, "w", encoding="utf-8", closefd=False)
w.write(f"全部 16 帧预览已生成 → {out}\n"); w.flush()
