# -*- coding: utf-8 -*-
import json
from collections import defaultdict

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)
def flat(shapes):
    out=[]
    for s in shapes:
        out.append(s)
        if "group" in s: out.extend(flat(s["group"]))
    return out
def area(s): return (s.get("w") or 0)*(s.get("h") or 0)

CARD_FILLS={"F1F5F9","E2E8F0","ECEFF1","F8FAFC","FEF3C7","FFF7ED","FEF2F2","F0FDF4","FDE68A","FCE7F3","FFFFFF","E0F2FE","E0F7FA","C8E6C9","F9F3D9","F9E5A3","FEF9C3","1E293B"}
NAVY={"0F172A","1E293B","334155","475569","455A64","64748B","1B3A5C"}
AMBER={"B45309","D97706","F59E0B","92400E","FCD34D","F0BC6E","D99E3E"}

def assign(deck, sl):
    fs=flat(sl["shapes"]); page=sl["page"]
    npic=sum(1 for s in fs if s["kind"]=="PICTURE")
    ntab=sum(1 for s in fs if s["kind"]=="TABLE")
    mf=max((max(t["sizes"]) for s in fs if (t:=s.get("txt")) and t["sizes"]),default=0)
    alltxt=" ".join(t["text"] for s in fs if (t:=s.get("txt")) and t["chars"]>0)
    if page==1: return "C-COVER"
    if npic>=1 and any((s.get("h") or 0)>55 and (s.get("w") or 0)>90 for s in fs) and ("方法论" in alltxt or "Methodology" in alltxt or "交响" in alltxt or "掌握一门" in alltxt):
        return "C-BACKCOVER"
    if "CONTENTS" in alltxt: return "C-TOC"
    if mf>=120: return "C-SECTION"
    big_tab=[s for s in fs if s["kind"]=="TABLE" and (s.get("h") or 0)>40]
    if big_tab and len([s for s in fs if s.get("fill") and area(s)>=120 and (s.get("h") or 0)>15])<=1:
        return "H2-TABLE"
    arrows=sum(1 for s in fs if (t:=s.get("txt")) and t["text"] in ("否→","是→")) + alltxt.count("→")
    if "诊断树" in alltxt and arrows>=4:
        return "H9-DIAGTREE"
    # summary 3-band methodology (closing before back cover): 3 full-width bands w>=85 h~22, with 01/02/03 sz48
    fwbig=[s for s in fs if s.get("fill") in (NAVY|AMBER) and (s.get("w") or 0)>=85 and 18<(s.get("h") or 0)<26]
    if len(fwbig)>=3 and ("方法论" in alltxt or "升华" in alltxt or "思维" in alltxt or "精神" in alltxt):
        return "H11-SUMMARY3BAND"
    # chef notes: numbered long list, big card h>45, title 笔记
    if "笔记" in alltxt:
        return "H10-CHEFNOTES"
    cards=[s for s in fs if s.get("fill") and area(s)>=120 and (s.get("w") or 0)<96 and (s.get("t") or 0)>3 and (s.get("h") or 0)>10]
    def colcount(hmin):
        main=[c for c in cards if (c.get("h") or 0)>hmin and 10<(c.get("t") or 0)<45]
        lefts=sorted(set(round(c.get("l") or 0) for c in main)); m=[]
        for l in lefts:
            if not m or l-m[-1]>6: m.append(l)
        return len(m), main
    ncol, maincards = colcount(25)
    conn=sum(1 for s in fs if s.get("fill") in AMBER and 1.3<(s.get("w") or 0)<4 and 1.3<(s.get("h") or 0)<4)
    pastel=[s for s in fs if s.get("fill") and s.get("fill") not in (NAVY|AMBER) and s.get("fill") in CARD_FILLS and 15<(s.get("w") or 0)<25 and 4<(s.get("h") or 0)<16]
    strip=[s for s in fs if s.get("fill") in (NAVY|AMBER|CARD_FILLS) and 10<(s.get("w") or 0)<25 and 6<(s.get("h") or 0)<15 and 13<(s.get("t") or 0)<30]
    # SOP flow
    if ("流程" in alltxt or "SOP" in alltxt) and (ncol>=4 or len(strip)>=4):
        return "H7-SOPFLOW"
    # timeline / color path
    if ("色泽" in alltxt or "路径" in alltxt) and (len(pastel)>=3 or conn>=3):
        return "H6-TIMELINE"
    # technique workflow strip (small process cards + big body bands)
    if ("技法" in alltxt) and (len(strip)>=4 or conn>=3):
        return "H8-TECHWORKFLOW"
    # image + info cards
    if npic>=1:
        return "H5-IMGCARDS"
    # food archive (role/param/mechanism/risk) - keyword or 4 stacked info cards no cols
    if ("食材" in alltxt or "档案" in alltxt or "核心食材" in alltxt) and ncol<3:
        return "H5-IMGCARDS"  # food archive family (image optional)
    # 3-col deep step
    if ncol>=3:
        if any((c.get("h") or 0)>45 for c in maincards):
            return "H1-STEP3COL"
        return "H4-NCARD"
    if ncol==2:
        # quadrant if 4 cards, else 2-col
        q=[c for c in cards if (c.get("h") or 0)>15]
        return "H3-2COL"
    if len(pastel)>=3 or conn>=3:
        return "H6-TIMELINE"
    if len(strip)>=4:
        return "H8-TECHWORKFLOW"
    return "H-MIXED?"

amap=defaultdict(list)
for deck,d in ALL.items():
    for sl in d["slides"]:
        amap[assign(deck,sl)].append(f"{deck}p{sl['page']}")

print("=== FINAL SKELETON counts ===")
tot=0
for sk,pages in sorted(amap.items(), key=lambda x:-len(x[1])):
    tot+=len(pages)
    print(f"  {sk}: {len(pages)}")
print("  TOTAL:", tot)
print("\n=== leftover H-MIXED? ===")
print(amap.get("H-MIXED?",[]))
with open(r"D:\YISHAOAGENT\backend\data\debug\col5_assign_final.json","w",encoding="utf-8") as f:
    json.dump({k:v for k,v in amap.items()}, f, ensure_ascii=False, indent=1)
