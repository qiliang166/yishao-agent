# -*- coding: utf-8 -*-
"""Verify principle page via the REAL production functions:
_load_style_vi_section -> extract ## HTML 模板 -> _fill_slide_template -> _resolve_color_vars
Uses the real 11-page abalone outline (index 2 = principle)."""
import os, sys, re, json, yaml
_B = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _B); os.chdir(_B)
import services.ppt_service as ps

# real outline principle slide
raw = open('data/debug/last_outline_response.txt', encoding='utf-8').read()
raw = re.sub(r'^```json\s*|\s*```$', '', raw.strip())
outline = json.loads(raw)
slides = outline if isinstance(outline, list) else (outline.get('slides') or outline.get('pages'))
principle = None
for s in (slides if isinstance(slides, list) else []):
    st = (s.get('page_type') or s.get('type') or s.get('stype') or '')
    if st == 'principle':
        principle = s; break
if principle is None:
    principle = slides[2] if isinstance(slides, list) and len(slides) > 2 else {}
print("PRINCIPLE heading:", principle.get('heading'))
print("key_points:", len(principle.get('key_points', [])))
for kp in principle.get('key_points', []):
    print("  -", (kp if isinstance(kp,str) else kp.get('text','')))

# real pipeline: load VI section, extract template, fill, resolve
vi = ps._load_style_vi_section('business', 'principle', 'deep-blue', resolve_vars=False, column_id='col4')
m = re.search(r'```html\s*\n(.*?)\n```', vi, re.DOTALL)
tmpl = m.group(1).strip()
html = ps._fill_slide_template(tmpl, principle, 11)

# residual placeholder check
resid = re.findall(r'\{\{[^}]+\}\}', html)
print("RESIDUAL placeholders:", resid)

# hardcoded non-white hex check
hexes = re.findall(r'#[0-9a-fA-F]{3,6}', html)
bad = [h for h in hexes if h.lower() not in ('#ffffff','#fff')]
print("NON-WHITE hardcoded hex:", bad)

# resolve colors with real scheme
scheme = yaml.safe_load(open('resources/vi/business/tokens.yaml', encoding='utf-8'))['color_schemes']['deep-blue']
root = ps._build_root_vars(scheme)
resolved = ps._resolve_color_vars(html, scheme, css_vars=True)
doc = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
       f'body{{margin:0;background:#2b2b2b;padding:40px;display:flex;justify-content:center;}}</style>'
       f'</head><body>{resolved}</body></html>')
open('data/debug/principle_production.html','w',encoding='utf-8').write(doc)
print("WROTE data/debug/principle_production.html", len(doc), "bytes")
print("module count (absolute-position divs):", resolved.count('position:absolute'))
