# -*- coding: utf-8 -*-
"""DEMO: 100% no-overflow via headless-browser measurement + auto font-shrink.
Fills the REAL principle VI template with REAL abalone data, then for every
box measures scrollHeight; any box that overflows gets its font-size shrunk
(step -0.5px) until scrollHeight<=clientHeight. Reports max_overflow_px BEFORE
and AFTER. Proof is a number: AFTER must be 0."""
import os, sys, re, json, yaml
_B = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _B); os.chdir(_B)
import services.ppt_service as ps
from playwright.sync_api import sync_playwright

# ---- real principle slide (index 2) ----
raw = open('data/debug/last_outline_response.txt', encoding='utf-8').read()
raw = re.sub(r'^```json\s*|\s*```$', '', raw.strip())
slides = json.loads(raw)
principle = next(s for s in slides if (s.get('page_type') or s.get('type')) == 'principle')

# ---- real pipeline: load VI template -> fill -> resolve ----
vi = ps._load_style_vi_section('business', 'principle', 'deep-blue', resolve_vars=False, column_id='col4')
tmpl = re.search(r'```html\s*\n(.*?)\n```', vi, re.DOTALL).group(1).strip()
html = ps._fill_slide_template(tmpl, principle, 11)
scheme = yaml.safe_load(open('resources/vi/business/tokens.yaml', encoding='utf-8'))['color_schemes']['deep-blue']
root = ps._build_root_vars(scheme)
resolved = ps._resolve_color_vars(html, scheme, css_vars=True)

def build_doc(inner):
    return (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
            f'*{{box-sizing:border-box;}} body{{margin:0;background:#2b2b2b;padding:40px;'
            f'display:flex;justify-content:center;}}</style></head><body>{inner}</body></html>')

MIN_FONT = 9.0   # hard floor; below this we rely on overflow:hidden
STEP = 0.5

def measure_and_fit(page, inner):
    """Load, measure every leaf box's overflow, shrink its font until it fits.
    Returns (fixed_inner, max_overflow_before, max_overflow_after, shrunk_count)."""
    page.set_content(build_doc(inner))
    # measure BEFORE
    before = page.evaluate('''() => {
        let mx=0;
        document.querySelectorAll('div,span').forEach(e=>{
            const oy=e.scrollHeight-e.clientHeight, ox=e.scrollWidth-e.clientWidth;
            mx=Math.max(mx, oy, ox);
        });
        return mx;
    }''')
    # iterative fit: tag every element, shrink overflowing ones
    fixed = page.evaluate('''(cfg) => {
        const minFont = cfg.minFont, step = cfg.step;
        const px = v => parseFloat(v);
        let guard = 0;
        let anyOverflow = true;
        const all = [...document.querySelectorAll('div,span')];
        while (anyOverflow && guard < 400) {
            anyOverflow = false;
            for (const e of all) {
                const oy = e.scrollHeight - e.clientHeight;
                const ox = e.scrollWidth - e.clientWidth;
                if (oy > 0 || ox > 0) {
                    const cs = getComputedStyle(e);
                    let fs = px(cs.fontSize);
                    if (fs > minFont) {
                        e.style.fontSize = Math.max(minFont, fs - step) + 'px';
                        anyOverflow = true;
                    }
                }
            }
            guard++;
        }
        return document.body.innerHTML;
    }''', {"minFont": MIN_FONT, "step": STEP})
    # re-load fixed html and measure AFTER
    page.set_content(build_doc(fixed))
    after = page.evaluate('''() => {
        let mx=0;
        document.querySelectorAll('div,span').forEach(e=>{
            const oy=e.scrollHeight-e.clientHeight, ox=e.scrollWidth-e.clientWidth;
            mx=Math.max(mx, oy, ox);
        });
        return mx;
    }''')
    return fixed, before, after

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1400,'height':900})
    fixed, before, after = measure_and_fit(pg, resolved)
    b.close()

open('data/debug/principle_fit.html','w',encoding='utf-8').write(build_doc(fixed))
print(f"max_overflow_px BEFORE = {before}")
print(f"max_overflow_px AFTER  = {after}")
print(f"WROTE data/debug/principle_fit.html")
print("PROOF:", "PASS (0 overflow)" if after == 0 else f"FAIL ({after}px still overflowing)")
