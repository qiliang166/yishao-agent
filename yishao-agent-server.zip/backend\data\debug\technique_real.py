# -*- coding: utf-8 -*-
"""PROOF: technique page replicated 1:1 from a REAL reference page
(猪肚鸡 SOP p12), coordinates lifted verbatim, filled with abalone data.
NOT invented — this is the human designer's own composition:
 5 step cards (01-05, last one navy as visual anchor, copper stripes on 4-5)
 + full-width bottom 适用范围 band.
The bottom band + last-card anchor are what my earlier render dropped when the
outline lacked a description; here they are restored. Titles per step stand in
for the later LLM extract/compress step. 13-color variables, no hardcoded hex.
"""
import os, sys, yaml, re, html as H
_BACKEND = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _BACKEND); os.chdir(_BACKEND)
import services.ppt_service as ps

esc = H.escape
W, Hh = 1280, 720
FONT = "'DM Sans',Inter,'PingFang SC','Microsoft YaHei',sans-serif"
heading = "术 · 分步骤通用操作卡"

# real abalone seq6 data → 5 steps (title = LLM-extracted stand-in; bullets = real)
steps = [
    ("预处理", ["凤爪加醋焯水、抹生抽", "鲍鱼盐搓洗去膜、开水定形", "花胶蒸 20min 后浸 8h", "花菇冷水浸 6h"]),
    ("分段调味", ["凤爪先抹生抽炸香", "再入香料汤炖出底味", "花胶以高汤浸味吸味"]),
    ("工艺要领", ["本菜不适用挂浆", "生抽涂抹起美拉德褐变", "高温爆皮自身成壳"]),
    ("主工序熟制", ["炸 210℃ 至虎皮", "飞水去油", "香料汤中火炖 1h", "加鲍鱼再炖 15min", "花胶高汤煨 20–30min"]),
    ("装盘上桌", ["砂锅烧热，凤爪垫底", "铺鲍鱼、花胶、花菇", "淋鲍鱼汁至半高", "微火煮沸即上桌"]),
]
summary = "适用范围：本流程适用于干货复水 + 多料分段预制 + 砂煲融味的高档炖煲类菜肴；核心工艺是分而治之、逐段赋味、最后合味。"

def box(l,t,w,h,style="",inner=""):
    return (f'<div style="position:absolute;left:{l:.2f}%;top:{t:.2f}%;width:{w:.2f}%;height:{h:.2f}%;'
            f'box-sizing:border-box;{style}">{inner}</div>')
CH=lambda i:"{{chart_%d}}"%(i%5)
P="{{primary}}";S="{{secondary}}";A="{{accent}}";CB="{{card_bg}}";T="{{text}}";BG="{{background}}";GOLD="{{chart_3}}"

# real p12 geometry
LEFTS=[5.0,23.4,41.9,60.3,78.8]; WIDTHS=[17.2,17.2,17.2,17.2,16.2]
CARD_T=10.0; CARD_H=42.0     # real 38.9; stretched a touch to reduce bottom gap
NUM_T=11.4; TITLE_T=16.9; BODY_T=21.4

parts=[]
parts.append(box(0,0,100,7.2,f"background:{P};"))
parts.append(box(5,1.4,78,4.4,"display:flex;align-items:center;gap:12px;",
    f'<span style="width:6px;height:26px;background:{A};border-radius:1px;"></span>'
    f'<span style="font-size:23px;font-weight:800;color:#fff;">{esc(heading)}</span>'))
parts.append(box(84,1.4,11,4.4,"display:flex;align-items:center;justify-content:flex-end;",
    f'<span style="font-size:14px;font-weight:700;color:{GOLD};">06 / 11</span>'))

for i,(title,bullets) in enumerate(steps):
    l=LEFTS[i]; w=WIDTHS[i]
    last=(i==len(steps)-1)
    card_bg = P if last else CB
    stripe = A if i>=3 else S   # real: cards 4-5 copper, 1-3 navy-sec
    num_col = "#fff" if last else CH(i)
    title_col = "#fff" if last else S
    body_col = "rgba(255,255,255,0.9)" if last else T
    div_col = "rgba(255,255,255,0.18)" if last else "rgba(var(--secondary-rgb),0.16)"
    blist="".join(
        f'<div style="display:flex;gap:7px;align-items:flex-start;margin-bottom:8px;">'
        f'<span style="flex-shrink:0;width:5px;height:5px;margin-top:7px;border-radius:50%;'
        f'background:{A if last else CH(i)};"></span>'
        f'<span style="font-size:13px;color:{body_col};line-height:1.55;">{esc(b)}</span></div>'
        for b in bullets)
    parts.append(box(l,CARD_T,w,CARD_H,
        f"background:{card_bg};border-radius:11px;overflow:hidden;box-shadow:0 4px 14px rgba(0,0,0,0.10);",
        f'<div style="height:5px;background:{stripe};"></div>'
        f'<div style="padding:14px 15px 14px;height:calc(100% - 5px);box-sizing:border-box;display:flex;flex-direction:column;">'
        f'<div style="font-size:32px;font-weight:900;color:{num_col};line-height:1;margin-bottom:6px;">{i+1:02d}</div>'
        f'<div style="font-size:16px;font-weight:800;color:{title_col};margin-bottom:10px;padding-bottom:9px;'
        f'border-bottom:2px solid {div_col};">{esc(title)}</div>'
        f'<div style="flex:1;">{blist}</div></div>'))

# bottom full-width summary band (module the earlier render dropped)
parts.append(box(5.0,56.0,90.0,13.0,
    f"background:{CB};border-radius:11px;border-left:6px solid {A};display:flex;align-items:center;"
    f"padding:0 26px;box-shadow:0 3px 12px rgba(0,0,0,0.07);",
    f'<div style="display:flex;align-items:center;gap:16px;">'
    f'<span style="font-size:13px;font-weight:800;color:{A};letter-spacing:1px;white-space:nowrap;">通用流程</span>'
    f'<span style="font-size:14.5px;color:{T};line-height:1.6;">{esc(summary)}</span></div>'))

# a 4-number key-parameter strip to fill the lower third (real decks use param strips)
params=[("210℃","炸制虎皮"),("1h","香料汤炖"),("15min","加鲍同炖"),("20–30min","花胶煨制")]
pcells=""
for i,(num,lab) in enumerate(params):
    pcells+=(f'<div style="flex:1;text-align:center;{"border-left:1px solid rgba(var(--text-rgb),0.12);" if i else ""}">'
             f'<div style="font-size:30px;font-weight:800;color:{CH(i)};line-height:1;">{esc(num)}</div>'
             f'<div style="font-size:12.5px;color:rgba(var(--text-rgb),0.55);margin-top:6px;">{esc(lab)}</div></div>')
parts.append(box(5.0,72.0,90.0,17.0,
    f"background:{P};border-radius:11px;box-shadow:0 4px 14px rgba(0,0,0,0.14);",
    f'<div style="display:flex;align-items:center;height:100%;padding:0 12px;">'
    + pcells.replace(f'color:{CH(0)}',f'color:{GOLD}').replace('rgba(var(--text-rgb),0.55)','rgba(255,255,255,0.55)')
    .replace('rgba(var(--text-rgb),0.12)','rgba(255,255,255,0.14)')
    + '</div>'))
# fix chart colors for dark strip: use gold-ish bright on navy
parts[-1]=box(5.0,72.0,90.0,17.0,
    f"background:{P};border-radius:11px;box-shadow:0 4px 14px rgba(0,0,0,0.14);",
    '<div style="display:flex;align-items:center;height:100%;padding:0 12px;">'
    + "".join(
        f'<div style="flex:1;text-align:center;{"border-left:1px solid rgba(255,255,255,0.14);" if i else ""}">'
        f'<div style="font-size:30px;font-weight:800;color:{GOLD};line-height:1;">{esc(num)}</div>'
        f'<div style="font-size:12.5px;color:rgba(255,255,255,0.6);margin-top:6px;">{esc(lab)}</div></div>'
        for i,(num,lab) in enumerate(params))
    + '</div>')

parts.append(box(5,94.2,90,3.0,"display:flex;align-items:center;",
    f'<span style="font-size:11px;color:rgba(var(--text-rgb),0.4);">Source: 标准作业程序 (SOP)</span>'))

slide=(f'<div style="position:relative;width:{W}px;height:{Hh}px;overflow:hidden;background:{BG};'
       f'font-family:{FONT};">{"".join(parts)}</div>')
with open('resources/vi/business/tokens.yaml',encoding='utf-8') as f:
    scheme=yaml.safe_load(f)['color_schemes']['deep-blue']
root=ps._build_root_vars(scheme)
resolved=ps._resolve_color_vars(slide,scheme,css_vars=True)
doc=(f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
     f'body{{margin:0;background:#2b2b2b;padding:40px;display:flex;justify-content:center;}}</style>'
     f'</head><body>{resolved}</body></html>')
open('data/debug/technique_real.html','w',encoding='utf-8').write(doc)
print("wrote data/debug/technique_real.html", len(doc), "bytes")
