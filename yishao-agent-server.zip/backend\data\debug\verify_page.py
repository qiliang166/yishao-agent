# -*- coding: utf-8 -*-
"""Reusable verifier: render any content page via the REAL pipeline
(_load_style_vi_section -> _fill_slide_template -> _resolve_color_vars),
then measure spill/clipped with headless chromium. Usage:
  python verify_page.py <page_type> [outline_index]
Writes data/debug/<page_type>_prod.html and prints the proof numbers."""
import os, sys, re, json, yaml
_B = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _B); os.chdir(_B)
import services.ppt_service as ps
from playwright.sync_api import sync_playwright

page_type = sys.argv[1]
force_idx = int(sys.argv[2]) if len(sys.argv) > 2 else None

raw = open('data/debug/last_outline_response.txt', encoding='utf-8').read()
raw = re.sub(r'^```json\s*|\s*```$', '', raw.strip())
slides = json.loads(raw)
if force_idx is not None:
    slide = slides[force_idx]
else:
    slide = next(s for s in slides if (s.get('page_type') or s.get('type')) == page_type)

print(f"[{page_type}] heading = {slide.get('heading')}")
kps = slide.get('key_points', [])
print(f"[{page_type}] key_points = {len(kps)}")

vi = ps._load_style_vi_section('business', page_type, 'deep-blue', resolve_vars=False, column_id='col4')
m = re.search(r'```html\s*\n(.*?)\n```', vi, re.DOTALL)
if not m:
    print("NO ## HTML 模板 in", page_type, "-> would fall to LLM"); sys.exit(2)
tmpl = m.group(1).strip()
html = ps._fill_slide_template(tmpl, slide, 11)

resid = re.findall(r'\{\{[^}]+\}\}', html)
hexes = [h for h in re.findall(r'#[0-9a-fA-F]{3,6}', html) if h.lower() not in ('#ffffff', '#fff')]
print(f"[{page_type}] residual placeholders = {resid}")
print(f"[{page_type}] non-white hardcoded hex = {hexes}")

scheme = yaml.safe_load(open('resources/vi/business/tokens.yaml', encoding='utf-8'))['color_schemes']['deep-blue']
root = ps._build_root_vars(scheme)
resolved = ps._resolve_color_vars(html, scheme, css_vars=True)
doc = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
       f'*{{box-sizing:border-box;}} html,body{{margin:0;padding:0;}}</style></head>'
       f'<body>{resolved}</body></html>')

FIT_JS = r'''
(cfg) => {
  const MINF=cfg.minFont, STEP=cfg.step;
  const slide=document.querySelector('body > div');
  const S=slide.getBoundingClientRect();
  const px=v=>parseFloat(v)||0;
  const texts=[...slide.querySelectorAll('div,span')].filter(e=>{
    if(e.children.length) return false;
    const t=(e.textContent||'').trim(); if(!t) return false;
    return e.scrollHeight > px(getComputedStyle(e).fontSize)*1.4 + 2;
  });
  let guard=0, changed=true;
  while(changed && guard<600){ changed=false;
    for(const e of texts){ if(e.scrollHeight-e.clientHeight>0){
      const fs=px(getComputedStyle(e).fontSize);
      if(fs>MINF){ e.style.fontSize=Math.max(MINF,fs-STEP)+'px'; changed=true; }
    }} guard++; }
  let clipped=0; for(const e of texts){ clipped=Math.max(clipped,e.scrollHeight-e.clientHeight); }
  let spill=0;
  slide.querySelectorAll('*').forEach(e=>{ const r=e.getBoundingClientRect();
    spill=Math.max(spill, Math.max(0,r.right-S.right), Math.max(0,r.bottom-S.bottom),
                   Math.max(0,S.left-r.left), Math.max(0,S.top-r.top)); });
  return {clipped:Math.round(clipped), spill:Math.round(spill), html:document.body.innerHTML};
}
'''
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1280,'height':720})
    pg.set_content(doc)
    res = pg.evaluate(FIT_JS, {"minFont":9.0, "step":0.5})
    b.close()

view = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
        f'*{{box-sizing:border-box;}} body{{margin:0;background:#2b2b2b;padding:40px;'
        f'display:flex;justify-content:center;}}</style></head><body>{res["html"]}</body></html>')
out = f'data/debug/{page_type}_prod.html'
open(out, 'w', encoding='utf-8').write(view)
print(f"[{page_type}] clipped_text_px = {res['clipped']}")
print(f"[{page_type}] spill_beyond_slide_px = {res['spill']}")
print(f"[{page_type}] modules(absolute) = {res['html'].count('position:absolute')}")
ok = (not resid) and (not hexes) and res['clipped']==0 and res['spill']==0
print(f"[{page_type}] PROOF:", "PASS" if ok else "FAIL", "->", out)
