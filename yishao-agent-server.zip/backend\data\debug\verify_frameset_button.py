# -*- coding: utf-8 -*-
"""
端到端验证：调用生产函数 _stage2_html_per_slide（网站「合成PPT」按钮走的同一函数），
确认 col5 每页都由「大模型选真实框架 + 填槽 + frameset_service 渲染」产出。
再用 Playwright 实测 spill/clip/残留/硬编码色。
"""
import io, sys, json, re
from pathlib import Path

BK = Path(__file__).resolve().parents[2]  # backend/
sys.path.insert(0, str(BK))

from services.ppt_service import (
    _stage2_html_per_slide, _load_scheme_data, _build_root_vars,
)
from services.llm_service import generate as llm_generate

PROVIDER, MODEL = "0df96678", "deepseek-v4-pro"
STYLE, SCHEME, COLUMN = "business", "chinese-red", "col5"

RESULT = BK.parent / "data" / "output" / "鲍鱼一品煲" / "鲍鱼一品煲_col5" / "result.json"

w = io.open(1, "w", encoding="utf-8", closefd=False)


def main():
    res = json.load(open(RESULT, encoding="utf-8"))
    plan = res.get("slide_plan") or res.get("slides") or res.get("structure")
    w.write(f"slide_plan: {len(plan)} 页\n"); w.flush()

    # normalize seq
    for i, s in enumerate(plan, 1):
        s.setdefault("seq", i)

    slides = _stage2_html_per_slide(
        PROVIDER, MODEL, llm_generate, plan,
        style_id=STYLE, parallel=3, temperature=0.3,
        column_id=COLUMN, color_scheme=SCHEME, project_id="")

    if not slides:
        w.write("FAIL: _stage2 returned None\n"); w.flush(); return

    ok_frameset = sum(1 for s in slides if s.get("frame_id"))
    w.write(f"生产函数返回 {len(slides)} 页，其中 {ok_frameset} 页用真实框架\n")
    for s in slides:
        w.write(f"  seq{s.get('seq')}: {s.get('type')} → frame={s.get('frame_id','(非框架)')}\n")
    w.flush()

    # ── assemble a preview doc for eyeballing ──
    scheme = _load_scheme_data(STYLE, SCHEME)
    root = _build_root_vars(scheme)
    pages = []
    for s in slides:
        h = s.get("html", "")
        pages.append(f"<div style='margin:20px auto;width:1280px;'>"
                     f"<div style='font:600 13px sans-serif;color:#666'>seq{s.get('seq')} · {s.get('frame_id','?')}</div>{h}</div>")
    doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n*{{margin:0;padding:0;box-sizing:border-box}}</style></head>"
           f"<body style='background:#ddd;padding:20px'>{''.join(pages)}</body></html>")
    out = Path(__file__).resolve().parent / "verify_frameset_button.html"
    out.write_text(doc, encoding="utf-8")
    w.write(f"预览写入 {out}\n"); w.flush()

    # ── Playwright per-slide spill/clip + residual/hex audit ──
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        w.write(f"Playwright 不可用，跳过实测: {e}\n"); w.flush(); return

    JS = r"""
    () => {
      const slide=document.querySelector('body>div>div:last-child')||document.querySelector('body>div');
      if(!slide) return {clip:0,spill:0,under:0,lowc:0};
      const S=slide.getBoundingClientRect();
      const px=v=>parseFloat(v)||0;
      const isPageNum=t=>/^\s*\d+\s*\/\s*\d+\s*$/.test(t);
      const lum=(r,g,b)=>{const a=[r,g,b].map(v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);});return 0.2126*a[0]+0.7152*a[1]+0.0722*a[2];};
      const parse=c=>{const m=(c||'').match(/rgba?\(([^)]+)\)/);if(!m)return null;const p=m[1].split(',').map(x=>parseFloat(x));return {r:p[0],g:p[1],b:p[2],a:p.length>3?p[3]:1};};
      const bgOf=e=>{const r=e.getBoundingClientRect();
        const stack=document.elementsFromPoint(r.left+r.width/2,r.top+r.height/2);
        for(const el of stack){if(el===e||e.contains(el))continue;const bg=parse(getComputedStyle(el).backgroundColor);if(bg&&bg.a>=0.5)return bg;}
        const sb=parse(getComputedStyle(slide).backgroundColor);return sb&&sb.a>=0.5?sb:{r:255,g:255,b:255,a:1};};
      let clip=0,spill=0,under=0,lowc=0;
      slide.querySelectorAll('div,span').forEach(e=>{
        const r=e.getBoundingClientRect();
        spill=Math.max(spill,Math.max(0,r.right-S.right),Math.max(0,r.bottom-S.bottom),
              Math.max(0,S.left-r.left),Math.max(0,S.top-r.top));
        if(e.children.length)return;const t=(e.textContent||'').trim();if(!t)return;
        clip=Math.max(clip,e.scrollHeight-e.clientHeight);
        if(!isPageNum(t)&&e.clientHeight>=24&&e.clientWidth>=40){
          if(e.scrollHeight/Math.max(1,e.clientHeight)<0.60)under++;}
        const fg=parse(getComputedStyle(e).color);if(fg){const bg=bgOf(e);
          const Lf=lum(fg.r,fg.g,fg.b)+0.05,Lb=lum(bg.r,bg.g,bg.b)+0.05;
          const ratio=Lf>Lb?Lf/Lb:Lb/Lf;if(ratio<4.5)lowc++;}
      });
      return {clip:Math.round(clip),spill:Math.round(spill),under,lowc};
    }
    """
    tot_clip = tot_spill = tot_resid = tot_hex = tot_under = tot_lowc = 0
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1280, "height": 720})
        for s in slides:
            h = s.get("html", "")
            # residual {{}} placeholders
            resid = len(re.findall(r"\{\{[^}]+\}\}", h))
            # hardcoded non-white hex outside :root
            hexes = [x for x in re.findall(r"#[0-9a-fA-F]{6}", h)
                     if x.lower() not in ("#ffffff", "#fff")]
            tot_resid += resid; tot_hex += len(hexes)
            doc1 = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n"
                    f"*{{box-sizing:border-box}}html,body{{margin:0;padding:0}}</style></head>"
                    f"<body>{h}</body></html>")
            pg.set_content(doc1)
            m = pg.evaluate(JS)
            tot_clip = max(tot_clip, m["clip"]); tot_spill = max(tot_spill, m["spill"])
            tot_under += m["under"]; tot_lowc += m["lowc"]
            ok_row = (m["clip"] == 0 and m["spill"] == 0 and m["under"] == 0
                      and m["lowc"] == 0 and resid == 0 and not hexes)
            flag = "" if ok_row else "  <-- CHECK"
            w.write(f"  seq{s.get('seq')} {s.get('frame_id','?'):20} clip={m['clip']} spill={m['spill']} "
                    f"欠填={m['under']} 低对比={m['lowc']} resid={resid} hex={len(hexes)}{flag}\n")
            w.flush()
        b.close()

    w.write("=" * 56 + "\n")
    w.write(f"汇总: max_clip={tot_clip} max_spill={tot_spill} 欠填={tot_under} "
            f"低对比={tot_lowc} 残留={tot_resid} 硬编码hex={tot_hex}\n")
    verdict = "PASS" if (tot_clip == 0 and tot_spill == 0 and tot_under == 0
                         and tot_lowc == 0 and tot_resid == 0 and tot_hex == 0) else "FAIL"
    w.write(f"判据(spill=0 clip=0 欠填=0 低对比=0 残留=0 硬码色=0): {verdict}\n")
    w.flush()


if __name__ == "__main__":
    main()
