# -*- coding: utf-8 -*-
import os, sys, re, json, yaml
_B = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _B); os.chdir(_B)
import services.ppt_service as ps
from playwright.sync_api import sync_playwright

raw = open('data/debug/last_outline_response.txt', encoding='utf-8').read()
raw = re.sub(r'^```json\s*|\s*```$', '', raw.strip())
slides = json.loads(raw)
principle = next(s for s in slides if (s.get('page_type') or s.get('type')) == 'principle')
vi = ps._load_style_vi_section('business', 'principle', 'deep-blue', resolve_vars=False, column_id='col4')
tmpl = re.search(r'```html\s*\n(.*?)\n```', vi, re.DOTALL).group(1).strip()
html = ps._fill_slide_template(tmpl, principle, 11)
scheme = yaml.safe_load(open('resources/vi/business/tokens.yaml', encoding='utf-8'))['color_schemes']['deep-blue']
root = ps._build_root_vars(scheme)
resolved = ps._resolve_color_vars(html, scheme, css_vars=True)
doc = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
       f'*{{box-sizing:border-box;}} body{{margin:0;background:#2b2b2b;padding:40px;display:flex;justify-content:center;}}</style>'
       f'</head><body>{resolved}</body></html>')

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1400,'height':900})
    pg.set_content(doc)
    culprits = pg.evaluate('''() => {
        const out=[];
        document.querySelectorAll('div,span').forEach((e,idx)=>{
            const oy=e.scrollHeight-e.clientHeight, ox=e.scrollWidth-e.clientWidth;
            if(oy>0||ox>0){
                out.push({idx, oy, ox,
                    tag:e.tagName,
                    fs:getComputedStyle(e).fontSize,
                    cls:(e.getAttribute('style')||'').slice(0,60),
                    txt:(e.textContent||'').trim().slice(0,24),
                    childCount:e.children.length});
            }
        });
        return out;
    }''')
    b.close()
for c in culprits:
    print(c)
print("TOTAL overflowing elems:", len(culprits))
