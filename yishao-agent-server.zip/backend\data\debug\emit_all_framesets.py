# -*- coding: utf-8 -*-
"""
把 16 个真实框架各吐成一个 VI 可编辑 .md（resources/vi/business/framesets/{frame_id}.md）。
几何/字号/配色 100% 来自 frameset JSON，由 frameset_service.render_frame 自动生成——
本脚本一个坐标都不打。每个文字格子内容 = 它的 content_key 占位符 {{role#n}}，
渲染时（render_from_vi）按大模型填的 slots 字典替换。
结构照 principle.md：标题说明 + ## HTML 模板 + ```html``` + 占位符表 + 护栏。
"""
import io, sys
from pathlib import Path

BK = Path(__file__).resolve().parents[2]  # backend/
sys.path.insert(0, str(BK))

from services import frameset_service as fset

STYLE = "business"
OUT_DIR = BK / "resources" / "vi" / STYLE / "framesets"

w = io.open(1, "w", encoding="utf-8", closefd=False)


def _placeholder_map(frame: dict) -> dict:
    """每个文字容器 content_key → 占位符字符串 {{content_key}}。"""
    m = {}
    for c in frame["containers"]:
        key = c.get("_content_key")
        if key:
            m[key] = "{{" + key + "}}"
    return m


def _slot_rows(frame: dict) -> list:
    """收集该框架的占位符清单，用于文档里的占位符表。"""
    rows = []
    seen = set()
    for c in sorted(frame["containers"], key=lambda x: x["z"]):
        key = c.get("_content_key")
        if not key or key in seen:
            continue
        seen.add(key)
        role = c["role"]
        role_cn = fset.ROLE_DESC.get(role, role)
        rows.append((key, role_cn, c.get("fs", ""), (c.get("example") or "")[:20]))
    return rows


def emit_one(fs: dict, frame: dict) -> str:
    fid = frame["frame_id"]
    ptype = frame.get("page_type", "")
    ph = _placeholder_map(frame)
    cw, ch = fs.get("canvas", [1280, 720])
    html = fset.render_frame(frame, ph, cw, ch)

    rows = _slot_rows(frame)
    n_panel = sum(1 for c in frame["containers"] if c["role"] == "panel")
    n_pic = sum(1 for c in frame["containers"] if c.get("kind") == "PICTURE")
    n_tab = sum(1 for c in frame["containers"] if c.get("kind") == "TABLE")

    slot_tbl = "\n".join(
        f"| `{{{{{k}}}}}` | {cn} | fs={fs_px} | 例：{ex} |"
        for k, cn, fs_px, ex in rows
    )

    doc = f"""# 框架 {fid}（页型：{ptype}）— 真实 PPT 提取，几何锁死

> 本框架**从真实 PPT 提取**：坐标/尺寸/字号/层级/配色 100% 来自 pptx，
> 由数据驱动渲染器（`backend/services/frameset_service.py` 的 `render_frame`）
> 按提取的 JSON 几何自动生成，**没有一个手写坐标**。
> 配色 = PPT 真实色映射到 VI 13 色变量（primary/secondary/accent/card_bg…）。
> 内容由大模型选中本框架后，把文字缩写/扩写填进固定格子，几何锁死不可改。
>
> 构成：{n_panel} 个色块背板，{len(rows)} 个文字位""" + \
        (f"，{n_pic} 张图" if n_pic else "") + \
        (f"，{n_tab} 个表格" if n_tab else "") + f"""。

---

## HTML 模板（必须照抄结构，只替换 {{{{占位符}}}} 内容）

```html
{html}
```

## 内容占位符（大模型按 content_key 填槽）

| 占位符 | 用途 | 字号 | 示例 |
|--------|------|------|------|
{slot_tbl}

- `page_number#*` 页码由系统按真实 seq/总页数自动覆盖，无需大模型填。
- 未被填的占位符渲染时清空为空串，不残留。

## 必须遵守

- **绝对禁止**修改任何布局尺寸（width/height/left/top/font-size）— 坐标均来自真实 PPT 提取，是护栏。
- **绝对禁止**修改 `var(--xxx)` 颜色变量 — 配色 = PPT 真实色映射，换配色只改 tokens.yaml。
- 唯一合法硬编码颜色为 `#ffffff` 及 `rgba(255,255,255,x)` / `rgba(0,0,0,x)`。
- 只能替换 `{{{{占位符}}}}` 为实际文字；过长缩写、过短扩写，填满不溢出。
- 本框架由代码填充（code-fill）+ fit-to-box 兜底，无需 LLM 生成 HTML。
"""
    return doc


def main():
    fs = fset.load_frameset(STYLE)
    if not fs:
        w.write("FAIL: frameset 加载失败\n"); w.flush(); return
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    n = 0
    for frame in fs["frames"]:
        fid = frame["frame_id"]
        doc = emit_one(fs, frame)
        (OUT_DIR / f"{fid}.md").write_text(doc, encoding="utf-8")
        n += 1
        w.write(f"  写 {fid}.md ({len(doc)} 字符)\n")
    w.write("=" * 56 + f"\n共写 {n} 个框架 → {OUT_DIR}\n")
    w.flush()


if __name__ == "__main__":
    main()
