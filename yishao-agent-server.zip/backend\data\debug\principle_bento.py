# -*- coding: utf-8 -*-
"""PROOF: principle page as a TRUE multi-module asymmetric composition.
Not "a row of identical cards" — a left dark theme-spine + right bento tiles,
each tile itself a mini multi-module (icon header / correct zone / reverse zone).
Real abalone data, 13-color variables (no hardcoded hex). Manual text-fit here
stands in for the later LLM compress/expand step.
"""
import os, sys, yaml, html as H
_BACKEND = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _BACKEND); os.chdir(_BACKEND)
import services.ppt_service as ps

esc = H.escape
W, Hh = 1280, 720
FONT = "'DM Sans',Inter,'PingFang SC','Microsoft YaHei',sans-serif"

# real data (seq3 principle) — 4 道, each "correct；wrong"
heading = "道 · 烹饪理念与原理"
theme_big = "道"
theme_sub = "烹饪理念与原理"
theme_note = "发 · 皮 · 序 · 味 — 四维拆解鲍鱼一品煲的烹饪哲学"
dao = [
    ("涨", "涨之道", "花胶先蒸后 50℃ 温水浸 8h，胶质均匀吸水还原弹滑", "沸水直涨则外层糊化、内部硬芯", "drop"),
    ("脆", "脆之道", "白醋焯水刻蚀表皮，210℃ 油温瞬间汽化膨起虎皮", "油温过低则表皮干硬、不起皮", "fire"),
    ("合", "合之道", "分而治之批量预制，最后砂煲以鲍汁融合诸味", "一锅乱炖则老嫩不齐、味不入", "merge"),
    ("时", "时之道", "花菇 6h 冷发保香、凤爪 1h 释胶、花胶煨 20–30min", "火候时序错配则质地尽失", "clock"),
]
ICONS = {
    "drop": '<path d="M12 3c-3 4-6 7-6 11a6 6 0 0012 0c0-4-3-7-6-11z"/>',
    "fire": '<path d="M12 2C8 6 8 9 10 12c1 1.5 1 3 0 4M14 6c2 3 4 5 4 9a6 6 0 01-12 0"/>',
    "merge": '<path d="M4 6h5l3 6M20 6h-5M4 18h5l3-6M20 18h-5"/><circle cx="12" cy="12" r="2"/>',
    "clock": '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
}
def svg(n, c, s=20, sw=1.7):
    return (f'<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" style="stroke:{c}" '
            f'stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round">{ICONS[n]}</svg>')

def box(l, t, w, h, style="", inner=""):
    return (f'<div style="position:absolute;left:{l:.2f}%;top:{t:.2f}%;width:{w:.2f}%;height:{h:.2f}%;'
            f'box-sizing:border-box;{style}">{inner}</div>')

CH = lambda i: "{{chart_%d}}" % (i % 5)
P="{{primary}}"; S="{{secondary}}"; A="{{accent}}"; CB="{{card_bg}}"; T="{{text}}"; BG="{{background}}"; NEG="{{semantic_negative}}"; GOLD="{{chart_3}}"

parts = []
# header
parts.append(box(0,0,100,7.2, f"background:{P};"))
parts.append(box(5,1.4,78,4.4,"display:flex;align-items:center;gap:12px;",
    f'<span style="width:6px;height:26px;background:{A};border-radius:1px;"></span>'
    f'<span style="font-size:23px;font-weight:800;color:#fff;">{esc(heading)}</span>'))
parts.append(box(84,1.4,11,4.4,"display:flex;align-items:center;justify-content:flex-end;",
    f'<span style="font-size:14px;font-weight:700;color:{GOLD};">03 / 11</span>'))

# LEFT dark theme spine (module 1) — big 道 + sub + index of 4
idx = "".join(
    f'<div style="display:flex;align-items:center;gap:10px;padding:9px 0;'
    f'{"border-top:1px solid rgba(255,255,255,0.12);" if i else ""}">'
    f'<div style="width:26px;height:26px;border-radius:7px;background:{CH(i)};color:#fff;font-size:14px;'
    f'font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;">{esc(d[0])}</div>'
    f'<span style="font-size:15px;color:rgba(255,255,255,0.9);font-weight:600;">{esc(d[1])}</span></div>'
    for i,d in enumerate(dao))
parts.append(box(5,10,25,82,
    f"background:{P};border-radius:14px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,0.2);",
    f'<div style="position:absolute;top:0;left:0;right:0;height:5px;background:{A};"></div>'
    f'<div style="padding:30px 24px;height:100%;box-sizing:border-box;display:flex;flex-direction:column;">'
    f'<div style="font-size:88px;font-weight:900;color:{A};line-height:0.9;">{esc(theme_big)}</div>'
    f'<div style="font-size:19px;font-weight:700;color:#fff;margin-top:8px;">{esc(theme_sub)}</div>'
    f'<div style="font-size:12.5px;color:rgba(255,255,255,0.55);line-height:1.6;margin-top:12px;">{esc(theme_note)}</div>'
    f'<div style="margin-top:auto;">{idx}</div></div>'))

# RIGHT bento of 4 tiles (module 2..5), 2x2 unequal-feel via internal richness
gx, gy, gw, gh = 32, 10, 63, 82
cols2 = [(gx, gw/2-1), (gx+gw/2+1, gw/2-1)]
rows2 = [(gy, gh/2-1.2), (gy+gh/2+1.2, gh/2-1.2)]
for i,(ch,name,ok,bad,ic) in enumerate(dao):
    l,w = cols2[i%2]; t,h = rows2[i//2]
    col = CH(i)
    parts.append(box(l,t,w,h,
        f"background:{CB};border-radius:12px;overflow:hidden;box-shadow:0 4px 14px rgba(0,0,0,0.09);",
        f'<div style="height:5px;background:{col};"></div>'
        f'<div style="padding:14px 18px 16px;height:calc(100% - 5px);box-sizing:border-box;display:flex;flex-direction:column;">'
        f'<div style="display:flex;align-items:center;gap:11px;margin-bottom:11px;">'
        f'<div style="width:40px;height:40px;border-radius:11px;background:{col};display:flex;align-items:center;'
        f'justify-content:center;flex-shrink:0;">{svg(ic,"#fff",22)}</div>'
        f'<div style="font-size:20px;font-weight:800;color:{S};">{esc(name)}</div></div>'
        f'<div style="font-size:14px;color:{T};line-height:1.6;margin-bottom:auto;">'
        f'<span style="color:{A};font-weight:800;">✓ </span>{esc(ok)}</div>'
        f'<div style="margin-top:12px;background:{NEG};border-radius:8px;padding:8px 12px;">'
        f'<span style="font-size:12.5px;color:rgba(255,255,255,0.92);"><b style="color:#F2C9C9;">✕ </b>{esc(bad)}</span></div>'
        f'</div>'))

slide = (f'<div style="position:relative;width:{W}px;height:{Hh}px;overflow:hidden;background:{BG};'
         f'font-family:{FONT};">{"".join(parts)}</div>')

with open('resources/vi/business/tokens.yaml',encoding='utf-8') as f:
    scheme = yaml.safe_load(f)['color_schemes']['deep-blue']
root = ps._build_root_vars(scheme)
resolved = ps._resolve_color_vars(slide, scheme, css_vars=True)
doc = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
       f'body{{margin:0;background:#2b2b2b;padding:40px;display:flex;justify-content:center;}}</style>'
       f'</head><body>{resolved}</body></html>')
open('data/debug/principle_bento.html','w',encoding='utf-8').write(doc)
print("wrote data/debug/principle_bento.html", len(doc), "bytes")
