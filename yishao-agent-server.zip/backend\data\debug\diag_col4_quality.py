# -*- coding: utf-8 -*-
"""
col4 取证：用生产同函数 _stage2_html_per_slide(column_id=col4) 复现11页，
逐页打印走哪条分支(frame_id/_code_filled)，再 Playwright 抓每个低对比 DIV
的真实 color+背景+字号，定位"白压色/背景色当字色"的确切来源。
"""
import io, sys, json, re
from pathlib import Path

BK = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(BK))

from services.ppt_service import (
    _stage2_html_per_slide, _load_scheme_data, _build_root_vars,
)
from services.llm_service import generate as llm_generate

PROVIDER, MODEL = "0df96678", "deepseek-v4-pro"
STYLE, SCHEME, COLUMN = "business", "chinese-red", "col4"
RESULT = BK.parent / "data" / "output" / "鲍鱼一品煲" / "鲍鱼一品煲_col4" / "result.json"
w = io.open(1, "w", encoding="utf-8", closefd=False)


def main():
    res = json.load(open(RESULT, encoding="utf-8"))
    plan = res.get("slide_plan") or []
    # 清掉上次写回的渲染痕迹，保证纯 plan 重跑
    for i, s in enumerate(plan, 1):
        s.setdefault("seq", i)
        for k in ("html", "html_vars", "frame_id", "_code_filled"):
            s.pop(k, None)
    w.write(f"col4 slide_plan: {len(plan)} 页 → 跑生产函数\n"); w.flush()

    slides = _stage2_html_per_slide(
        PROVIDER, MODEL, llm_generate, plan,
        style_id=STYLE, parallel=3, temperature=0.3,
        column_id=COLUMN, color_scheme=SCHEME, project_id="")
    if not slides:
        w.write("FAIL: None\n"); w.flush(); return

    w.write("── 每页走哪条分支 ──\n")
    for s in slides:
        branch = ("框架" if s.get("frame_id") else
                  ("col4模板" if s.get("_code_filled") else "LLM"))
        w.write(f"  seq{s.get('seq'):2} {s.get('type','?'):14} "
                f"frame_id={s.get('frame_id','-'):22} 分支={branch}\n")
    w.flush()

    scheme = _load_scheme_data(STYLE, SCHEME)
    root = _build_root_vars(scheme)
    from playwright.sync_api import sync_playwright

    JS = r"""
    () => {
      const slide=document.querySelector('body>div');
      const px=v=>parseFloat(v)||0;
      const isPN=t=>/^\s*\d+\s*[\/／]\s*\d+\s*$/.test(t)||/^第?\d+页/.test(t);
      const lum=(r,g,b)=>{const a=[r,g,b].map(v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);});return 0.2126*a[0]+0.7152*a[1]+0.0722*a[2];};
      const parse=c=>{const m=(c||'').match(/rgba?\(([^)]+)\)/);if(!m)return null;const p=m[1].split(',').map(x=>parseFloat(x));return{r:p[0],g:p[1],b:p[2],a:p.length>3?p[3]:1};};
      const bgOf=e=>{const r=e.getBoundingClientRect();const st=document.elementsFromPoint(r.left+r.width/2,r.top+r.height/2);for(const el of st){if(el===e||e.contains(el))continue;const bg=parse(getComputedStyle(el).backgroundColor);if(bg&&bg.a>=0.5)return bg;}const sb=parse(getComputedStyle(slide).backgroundColor);return sb&&sb.a>=0.5?sb:{r:255,g:255,b:255,a:1};};
      const low=[];let under=0,clip=0;
      slide.querySelectorAll('div,span,p,td,th,li').forEach(e=>{if(e.children.length)return;const t=(e.textContent||'').trim();if(!t)return;
        clip=Math.max(clip,e.scrollHeight-e.clientHeight);
        if(!isPN(t)&&e.clientHeight>=24&&e.clientWidth>=40&&e.scrollHeight/Math.max(1,e.clientHeight)<0.60)under++;
        const fg=parse(getComputedStyle(e).color);if(!fg)return;const bg=bgOf(e);
        const Lf=lum(fg.r,fg.g,fg.b)+0.05,Lb=lum(bg.r,bg.g,bg.b)+0.05;const ra=Lf>Lb?Lf/Lb:Lb/Lf;
        if(ra<4.5)low.push({ratio:Math.round(ra*10)/10,color:getComputedStyle(e).color,bg:`rgb(${Math.round(bg.r)},${Math.round(bg.g)},${Math.round(bg.b)})`,fs:getComputedStyle(e).fontSize,txt:t.slice(0,10)});});
      return {under,clip:Math.round(clip),low};
    }
    """
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1280, "height": 720})
        for s in slides:
            h = s.get("html", "")
            doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n"
                   f"*{{box-sizing:border-box}}html,body{{margin:0;padding:0}}</style></head>"
                   f"<body>{h}</body></html>")
            pg.set_content(doc); m = pg.evaluate(JS)
            branch = ("框架" if s.get("frame_id") else ("col4模板" if s.get("_code_filled") else "LLM"))
            w.write(f"\nseq{s.get('seq'):2} [{branch}] {s.get('frame_id','-')} "
                    f"欠填={m['under']} clip={m['clip']} 低对比={len(m['low'])}\n")
            for d in m["low"][:6]:
                w.write(f"     ratio={d['ratio']} color={d['color']} bg={d['bg']} fs={d['fs']} {d['txt']!r}\n")
            w.flush()
        b.close()


if __name__ == "__main__":
    main()
