# -*- coding: utf-8 -*-
import json, sys

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)

def flat(shapes, depth=0):
    out = []
    for s in shapes:
        s["_d"] = depth
        out.append(s)
        if "group" in s:
            out.extend(flat(s["group"], depth+1))
    return out

def dump(deck, page):
    d = ALL[deck]
    sl = d["slides"][page-1]
    print(f"\n########## {deck} p{page} ##########")
    for s in flat(sl["shapes"]):
        ind = "  " * s.get("_d", 0)
        pos = f"L{s['l']} T{s['t']} W{s['w']} H{s['h']}"
        fill = f" fill=#{s['fill']}" if s.get("fill") else ""
        t = s.get("txt")
        tt = ""
        if t:
            tt = f' "{t["text"]}" [{t["chars"]}ch sz{t["sizes"]} b{int(t["bold"])}]'
        print(f"{ind}{s['kind']:10} {pos}{fill}{tt}")

# representative pages passed as args: deck:page
for arg in sys.argv[1:]:
    deck, page = arg.split(":")
    dump(deck, int(page))
