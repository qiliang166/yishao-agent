# -*- coding: utf-8 -*-
"""
完整验证：框架 = 几何 + 字号 + 字数预算（舒适目标 + 溢出上限）
- 容器规格 SPEC 从真实 PPT page4 量得（几何/字号/舒适字数）+ 公式算溢出上限
- 大模型(我)按预算填字；代码逐格校验字数∈预算；Playwright 实测零溢出
- 附「长文压力测试」：喂超量文本 → 证明预算护栏 + 代码兜底能扛住
"""
import io, sys, re, math
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

DEBUG_DIR = Path(__file__).resolve().parent
OUT_HTML = DEBUG_DIR / "frame_fill_principle.html"

VI = {  # business / chinese-red （tokens.yaml 真实值）
    "--primary":"#c41e3a","--secondary":"#8b1a2b","--accent":"#d4a017",
    "--background":"#fff8f0","--text":"#2c1810","--card_bg":"#fef5e6",
    "--negative":"#c0392b","--positive":"#27ae60",
    "--chart-0":"#c41e3a","--chart-1":"#8b1a2b","--chart-2":"#d4a017",
    "--chart-3":"#b33a2e","--chart-4":"#e8c547",
    "--text-rgb":"44,24,16","--accent-rgb":"212,160,23",
}

# ── 容器规格：框架的核心。每格 = 几何 + 字号 + 字数预算 ──────────────────────
# comfort = 真实PPT该格实际字数（大模型书写目标）
# hardcap = 溢出上限，由 几何+字号 算：可容纳中文字数 ≈ floor(宽px/字号) × floor(高px/(字号×行高))
CANVAS_W, CANVAS_H = 1280, 720
def cap(w_pct, h_pct, fs, lh=1.55):
    w = w_pct/100*CANVAS_W - 24   # 减 padding 余量
    h = h_pct/100*CANVAS_H - 12
    per_line = max(1, int(w // fs))
    lines = max(1, int(h // (fs*lh)))
    return per_line * lines

SPEC = {
    #  role          W%    H%   fs  comfort  hardcap(算)
    "title":        (82.0, 4.4, 22, 11,  cap(82.0,4.4,22)),
    "card_title":   (55.6, 3.9, 18, 15,  cap(55.6,3.9,18)),
    "tile_title":   (24.0, 3.5, 15, 6,   cap(24.0,3.5,15)),
    "tile_correct": (24.0, 5.0, 12, 22,  cap(24.0,5.0,12)),
    "tile_wrong":   (24.0, 5.0, 12, 22,  cap(24.0,5.0,12)),
    "ok_body":      (40.9,12.5, 13, 55,  cap(40.9,12.5,13)),
    "bad_body":     (40.9,12.5, 13, 55,  cap(40.9,12.5,13)),
    "param":        (86.9, 6.1, 13, 62,  cap(86.9,6.1,13)),
    "footnote":     (46.9, 2.8, 12, 23,  cap(46.9,2.8,12)),
}

# ── 真实数据：项目 KH260707-0001 principle key_points ───────────────────────
HEADING="道 · 烹饪理念与原理"; THEME_CHAR="道"; THEME_SUB="烹饪理念与原理"
PAGE_NUM,TOTAL=3,11
KEY_POINTS=[
 "涨之道：花胶先蒸后50℃浸8h，还原弹滑；沸水直涨则外融内硬",
 "脆之道：白醋焯水刻蚀表皮，210℃油温瞬间汽化膨起虎皮；低油温则干硬",
 "合之道：分而治之批量预制，最后砂煲鲍汁融合；一锅乱炖则老嫩不齐",
 "时之道：花菇6h冷水慢发保香，凤爪1h慢炖释胶，花胶煨20-30min控软弹",
]
OK_BODY="花胶软糯Q弹、胶质完整；虎皮蜂窝起爆吸汁饱满；鲍鱼弹嫩不老；四材各守其时，一味引百味。"
BAD_BODY="沸水直涨花胶外烂内硬；低温油炸凤爪成皮革；一锅乱炖老嫩不齐；急发花菇香散味失，全盘失层次。"
PARAM="关键参数：花胶蒸20min→50℃浸8-9h ｜ 凤爪炸210℃→炖1h ｜ 鲍鱼同炖15min ｜ 花菇冷水发6-8h"
FOOTNOTE="Source: 「鲍鱼一品煲」SOP · 道之四维"

def split_kp(kp):
    title,rest=(kp.split("：",1) if "：" in kp else ("",kp))
    correct,wrong=(rest.split("；",1) if "；" in rest else (rest,""))
    return title.strip(),correct.strip(),wrong.strip()

# ── 代码兜底：内容超 hardcap 时按预算截断（生产同理，此处证明护栏生效）───────
def budget(text, role):
    hc = SPEC[role][4]
    if len(text) <= hc: return text, len(text), False
    return text[:hc-1]+"…", hc, True   # 兜底：截到上限

def esc(s): return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

# ── 填字：每格都过 budget()，记录字数审计 ────────────────────────────────────
AUDIT=[]
def put(text, role):
    t,n,cut = budget(text, role)
    comfort=SPEC[role][3]; hc=SPEC[role][4]
    AUDIT.append((role, n, comfort, hc, cut))
    return esc(t)

def build_tiles():
    out=[]
    for i,kp in enumerate(KEY_POINTS):
        title,correct,wrong=split_kp(kp)
        chart=f"var(--chart-{i%5})"
        out.append(f"""
      <div style="flex:1 1 calc(50% - 6px);min-height:0;box-sizing:border-box;background:var(--background);border-radius:10px;overflow:hidden;box-shadow:0 3px 10px rgba(0,0,0,0.08);display:flex;flex-direction:column;">
        <div style="display:flex;align-items:center;gap:8px;padding:9px 12px 6px;">
          <div style="width:26px;height:26px;border-radius:7px;background:{chart};color:#ffffff;font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;">{i+1:02d}</div>
          <span style="font-size:15px;font-weight:800;color:var(--secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{put(title,'tile_title')}</span>
        </div>
        <div style="flex:1;min-height:0;display:flex;flex-direction:column;gap:5px;padding:0 12px 10px;overflow:hidden;">
          <div style="display:flex;gap:6px;align-items:flex-start;">
            <span style="flex-shrink:0;font-size:12px;font-weight:800;color:var(--positive);">✓</span>
            <span style="font-size:12px;line-height:1.5;color:var(--text);overflow:hidden;">{put(correct,'tile_correct')}</span>
          </div>
          <div style="display:flex;gap:6px;align-items:flex-start;">
            <span style="flex-shrink:0;font-size:12px;font-weight:800;color:var(--negative);">✕</span>
            <span style="font-size:12px;line-height:1.5;color:rgba(var(--text-rgb),0.72);overflow:hidden;">{put(wrong,'tile_wrong')}</span>
          </div>
        </div>
      </div>""")
    return "".join(out)

def build_html_vars():
    return f"""<div style="position:relative;width:1280px;height:720px;overflow:hidden;background:var(--background);font-family:'DM Sans',Inter,'PingFang SC','Microsoft YaHei',sans-serif;">
  <div style="position:absolute;left:0;top:0;width:100%;height:7.2%;background:var(--primary);"></div>
  <div style="position:absolute;left:5%;top:1.4%;width:82%;height:4.4%;box-sizing:border-box;display:flex;align-items:center;gap:12px;">
    <span style="width:6px;height:26px;background:var(--accent);border-radius:1px;flex-shrink:0;"></span>
    <span style="font-size:22px;font-weight:800;color:#ffffff;letter-spacing:.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{put(HEADING,'title')}</span>
  </div>
  <div style="position:absolute;left:88%;top:1.4%;width:8%;height:4.4%;box-sizing:border-box;display:flex;align-items:center;justify-content:flex-end;">
    <span style="font-size:13px;font-weight:700;color:var(--accent);">{PAGE_NUM:02d} / {TOTAL}</span>
  </div>
  <div style="position:absolute;left:5%;top:10%;width:29.7%;height:38.9%;box-sizing:border-box;background:var(--primary);border-radius:12px;overflow:hidden;box-shadow:0 6px 18px rgba(0,0,0,0.18);">
    <div style="position:absolute;top:0;left:0;right:0;height:5px;background:var(--accent);"></div>
    <div style="padding:22px 20px;height:100%;box-sizing:border-box;display:flex;flex-direction:column;">
      <div style="font-size:64px;font-weight:900;color:var(--accent);line-height:0.9;">{THEME_CHAR}</div>
      <div style="font-size:16px;font-weight:700;color:#ffffff;margin-top:6px;">{THEME_SUB}</div>
      <div style="font-size:11px;color:rgba(255,255,255,0.75);font-weight:800;letter-spacing:2px;margin-top:auto;">共 {len(KEY_POINTS)} 道 · 正反对照</div>
    </div>
  </div>
  <div style="position:absolute;left:36.2%;top:10%;width:58.8%;height:38.9%;box-sizing:border-box;background:var(--card_bg);border-radius:12px;overflow:hidden;box-shadow:0 6px 18px rgba(0,0,0,0.10);display:flex;flex-direction:column;">
    <div style="height:5px;background:var(--accent);flex-shrink:0;"></div>
    <div style="flex:1;min-height:0;padding:12px;box-sizing:border-box;display:flex;flex-wrap:wrap;gap:12px;align-content:stretch;">{build_tiles()}</div>
  </div>
  <div style="position:absolute;left:5%;top:51.7%;width:44.1%;height:19.4%;box-sizing:border-box;background:var(--primary);border-radius:10px;overflow:hidden;padding:14px 18px;display:flex;flex-direction:column;">
    <div style="font-size:14px;font-weight:800;color:var(--accent);letter-spacing:1px;margin-bottom:6px;">✓ 正确操作结果</div>
    <div style="flex:1;min-height:0;font-size:13px;line-height:1.55;color:#ffffff;overflow:hidden;">{put(OK_BODY,'ok_body')}</div>
  </div>
  <div style="position:absolute;left:50.9%;top:51.7%;width:44.1%;height:19.4%;box-sizing:border-box;background:var(--negative);border-radius:10px;overflow:hidden;padding:14px 18px;display:flex;flex-direction:column;">
    <div style="font-size:14px;font-weight:800;color:#ffffff;letter-spacing:1px;margin-bottom:6px;">✕ 错误操作后果</div>
    <div style="flex:1;min-height:0;font-size:13px;line-height:1.55;color:rgba(255,255,255,0.92);overflow:hidden;">{put(BAD_BODY,'bad_body')}</div>
  </div>
  <div style="position:absolute;left:5%;top:73.6%;width:90%;height:8.3%;box-sizing:border-box;background:var(--card_bg);border-radius:10px;overflow:hidden;border-left:5px solid var(--accent);display:flex;align-items:center;padding:0 18px;">
    <span style="font-size:13px;font-weight:600;color:var(--text);line-height:1.4;overflow:hidden;">{put(PARAM,'param')}</span>
  </div>
  <div style="position:absolute;left:5%;top:94.4%;width:60%;height:2.8%;box-sizing:border-box;display:flex;align-items:center;">
    <span style="font-size:12px;color:rgba(var(--text-rgb),0.55);">{put(FOOTNOTE,'footnote')}</span>
  </div>
</div>"""

def resolve(hv):
    out=hv
    for k in ("--text-rgb","--accent-rgb"): out=out.replace(f"var({k})",VI[k])
    for k,v in VI.items():
        if k.endswith("-rgb"): continue
        out=out.replace(f"var({k})",v)
    return out

def measure(hr):
    from playwright.sync_api import sync_playwright
    page=f"<!doctype html><html><head><meta charset='utf-8'><style>*{{margin:0;padding:0;box-sizing:border-box}}</style></head><body>{hr}</body></html>"
    with sync_playwright() as p:
        b=p.chromium.launch(); pg=b.new_page(viewport={"width":1280,"height":720})
        pg.set_content(page,wait_until="networkidle")
        r=pg.evaluate("""()=>{const W=1280,H=720;let spill=0,clip=0;
          for(const el of document.querySelectorAll('body *')){const b=el.getBoundingClientRect();
            spill=Math.max(spill,Math.max(0,b.right-W),Math.max(0,b.bottom-H),Math.max(0,-b.left),Math.max(0,-b.top));
            if(el.children.length===0&&el.textContent.trim()){const fs=parseFloat(getComputedStyle(el).fontSize)||14;
              const oh=el.scrollHeight-el.clientHeight,ow=el.scrollWidth-el.clientWidth;
              if(oh>=fs*0.6)clip=Math.max(clip,oh); if(ow>=fs*0.6)clip=Math.max(clip,ow);}}
          return {spill:Math.round(spill),clip:Math.round(clip)};}""")
        b.close()
    return r

def run(tag):
    global AUDIT; AUDIT=[]
    hv=build_html_vars(); hr=resolve(hv)
    bad=[h for h in re.findall(r"#[0-9a-fA-F]{3,8}",hv) if h.lower() not in ("#ffffff","#fff")]
    resid=re.findall(r"\{\{[^}]+\}\}",hr)
    m=measure(hr)
    OUT_HTML.write_text(f"<!doctype html><html><head><meta charset='utf-8'><style>body{{margin:0}}</style></head><body>{hr}</body></html>",encoding="utf-8")
    print("="*70); print(f"验证【{tag}】  项目 KH260707-0001 · principle"); print("="*70)
    print("容器字数审计（框架预算 vs 实填）：")
    over=0
    for role,n,comfort,hc,cut in AUDIT:
        flag="✂兜底截断" if cut else ("✓" if n<=hc else "✗超限")
        if n>hc: over+=1
        print(f"  {role:13} 实填{n:>3}  舒适目标{comfort:>3}  溢出上限{hc:>3}  {flag}")
    print("-"*70)
    print(f"[判据1 零溢出]   spill={m['spill']}  clip={m['clip']}")
    print(f"[判据2 配色变量] 非白硬编码hex={len(bad)} {bad[:4]}")
    print(f"[判据3 无残留]   占位符={len(resid)}")
    print(f"[判据4 预算内]   超上限容器数={over}（应为0）")
    print(f"[判据5 多模块]   左脊/右2×2磁贴({len(KEY_POINTS)})/正确带/错误带/参数带/脚注=6类")
    ok=(m['spill']==0 and m['clip']==0 and len(bad)==0 and len(resid)==0 and over==0)
    print(f"PROOF: {'PASS ✅' if ok else 'FAIL ❌'}")
    return ok

if __name__=="__main__":
    a=run("正常内容")
    # ── 长文压力测试：把每条 key_point 灌成 3 倍长，证明预算+兜底扛得住 ──
    print("\n\n【压力测试】把内容灌成超量长文，看框架预算+代码兜底是否守住零溢出：")
    KEY_POINTS[:]=[k+ "，"+k.split("：",1)[-1]*3 for k in KEY_POINTS]
    OK_BODY=BAD_BODY=PARAM=("超量文本"*80)
    # 重新绑定模块级变量
    g=globals(); g['OK_BODY']=OK_BODY; g['BAD_BODY']=BAD_BODY; g['PARAM']=PARAM
    b=run("长文压力(3×+超量)")
    STRESS=DEBUG_DIR/"frame_fill_principle_stress.html"
    OUT_HTML.rename(STRESS) if False else None
    import shutil; shutil.copy(OUT_HTML, STRESS)
    print(f"[压力成品] {STRESS}")
    sys.exit(0 if (a and b) else 1)
