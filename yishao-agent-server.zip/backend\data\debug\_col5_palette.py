# -*- coding: utf-8 -*-
import json
from collections import Counter, defaultdict

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)

def flat(shapes):
    """flatten groups into a list, keeping group bbox as its own entry too."""
    out = []
    for s in shapes:
        out.append(s)
        if "group" in s:
            out.extend(flat(s["group"]))
    return out

# ---- palette frequency (all fills, incl inside groups) ----
fill_ctr = Counter()
kind_ctr = Counter()
pic_per_page = []
total_slides = 0
for deck, d in ALL.items():
    for sl in d["slides"]:
        total_slides += 1
        fs = flat(sl["shapes"])
        npic = 0
        for s in fs:
            kind_ctr[s["kind"]] += 1
            if s.get("fill"):
                fill_ctr[s["fill"]] += 1
            if s["kind"] == "PICTURE":
                npic += 1
        pic_per_page.append((deck, sl["page"], npic))

print("=== TOTAL SLIDES:", total_slides, "===")
print("\n=== FILL HEX FREQUENCY (top 30) ===")
for hx, c in fill_ctr.most_common(30):
    print(f"  #{hx}: {c}")

print("\n=== SHAPE KIND FREQUENCY ===")
for k, c in kind_ctr.most_common():
    print(f"  {k}: {c}")

print("\n=== PICTURE count distribution ===")
dist = Counter(n for _, _, n in pic_per_page)
for n in sorted(dist):
    print(f"  {n} pics: {dist[n]} pages")
print("  pages with >=1 pic:", sum(1 for _,_,n in pic_per_page if n>=1), "/", total_slides)
