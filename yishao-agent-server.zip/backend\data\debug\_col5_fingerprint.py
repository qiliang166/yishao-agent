# -*- coding: utf-8 -*-
import json
from collections import Counter, defaultdict

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)

CARD_FILLS = {"F1F5F9", "E2E8F0", "ECEFF1", "F8FAFC", "FEF3C7", "FFF7ED", "FEF2F2", "F0FDF4", "FDE68A", "FCE7F3"}
NAVY = {"0F172A", "1E293B", "334155", "475569", "455A64", "64748B", "1B3A5C"}
AMBER = {"B45309", "D97706", "F59E0B", "92400E", "FCD34D", "F0BC6E", "D99E3E", "F9E5A3", "F9F3D9"}
RED = {"DC2626", "EF4444", "CB4335", "FFCCBC"}

def flat(shapes):
    out = []
    for s in shapes:
        out.append(s)
        if "group" in s:
            out.extend(flat(s["group"]))
    return out

def area(s):
    return (s.get("w") or 0) * (s.get("h") or 0)

def max_font(shapes):
    m = 0
    for s in shapes:
        t = s.get("txt")
        if t and t["sizes"]:
            m = max(m, max(t["sizes"]))
    return m

def classify(deck, sl):
    fs = flat(sl["shapes"])
    npic = sum(1 for s in fs if s["kind"] == "PICTURE")
    ntab = sum(1 for s in fs if s["kind"] == "TABLE")
    mf = max_font(fs)
    # top header bar: full-width thin navy near top
    header = any(s.get("fill") in NAVY and (s.get("w") or 0) >= 90 and (s.get("t") or 0) < 1.2 and (s.get("h") or 0) < 2 for s in fs)
    # big colored blocks (cards / panels), area>=120, not full-page bg
    big_cards = [s for s in fs if s.get("fill") and area(s) >= 120 and (s.get("w") or 0) < 96 and (s.get("h") or 0) < 96 and (s.get("t") or 0) > 3]
    # detect columns: group big cards by rounded top, count distinct lefts in the biggest band
    band = defaultdict(list)
    for s in big_cards:
        band[round((s.get("t") or 0) / 3)].append(s)
    ncol = 0
    for k, arr in band.items():
        lefts = sorted(set(round(x.get("l") or 0) for x in arr if (x.get("h") or 0) > 15))
        # merge near lefts
        merged = []
        for l in lefts:
            if not merged or l - merged[-1] > 5:
                merged.append(l)
        ncol = max(ncol, len(merged))
    # full-width bands (stacked rows): fill w>=80 h between 4 and 12
    fw_bands = [s for s in fs if s.get("fill") and (s.get("w") or 0) >= 80 and 3 < (s.get("h") or 0) < 14 and (s.get("t") or 0) > 10]
    # cover signature
    is_cover = any(s.get("fill") in NAVY and (s.get("w") or 0) > 40 and (s.get("w") or 0) < 55 and (s.get("h") or 0) > 90 for s in fs) or \
               any(t for s in fs if (t := s.get("txt")) and ("MANUAL" in t["text"] or "KITCHEN" in t["text"]))
    # TOC signature: many F1F5F9 rows w>=80 stacked + numbers
    toc_rows = [s for s in fs if s.get("fill") in CARD_FILLS and (s.get("w") or 0) >= 80 and 6 < (s.get("h") or 0) < 12]
    is_toc = len(toc_rows) >= 4
    # section divider: giant number font
    is_section = mf >= 100
    return {
        "deck": deck, "page": sl["page"], "npic": npic, "ntab": ntab, "maxfont": mf,
        "header": header, "big_cards": len(big_cards), "ncol": ncol,
        "fw_bands": len(fw_bands), "is_cover": is_cover, "is_toc": is_toc,
        "is_section": is_section, "nshapes": len(fs),
    }

rows = []
for deck, d in ALL.items():
    for sl in d["slides"]:
        rows.append(classify(deck, sl))

# assign a coarse type
def coarse(r):
    if r["is_cover"] and r["page"] == 1:
        return "COVER"
    if r["is_section"]:
        return "SECTION"
    if r["is_toc"]:
        return "TOC"
    if r["ntab"] >= 1:
        return "TABLE"
    if r["ncol"] >= 3:
        return "COLS3+"
    if r["ncol"] == 2:
        return "COLS2"
    if r["fw_bands"] >= 3:
        return "STACK_BANDS"
    if r["npic"] >= 1:
        return "IMG"
    return "OTHER"

buckets = Counter()
for r in rows:
    r["coarse"] = coarse(r)
    buckets[r["coarse"]] += 1

print("=== COARSE BUCKETS ===")
for k, c in buckets.most_common():
    print(f"  {k}: {c}")

print("\n=== OTHER pages (need manual look) ===")
for r in rows:
    if r["coarse"] == "OTHER":
        print(f"  {r['deck']} p{r['page']}: cards{r['big_cards']} col{r['ncol']} band{r['fw_bands']} pic{r['npic']} font{r['maxfont']} sh{r['nshapes']}")

# save rows for later
with open(r"D:\YISHAOAGENT\backend\data\debug\col5_fingerprints.json", "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=1)
print("\nWROTE col5_fingerprints.json")
