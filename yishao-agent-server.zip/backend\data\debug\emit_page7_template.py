# -*- coding: utf-8 -*-
"""
吐出 page7 模板：用数据驱动渲染器（frame_renderer）按真实 JSON 几何生成 HTML，
每个文字格子的内容 = 它的占位符字符串（{{kp0_title}}…），panel/divider 用真实映射色。
产出 = 带 {{}} 的真实几何骨架，直接贴进 principle.md 的 ## HTML 模板。
几何 100% 来自 frameset_abalone.json —— 本脚本不写一个坐标。
"""
import io, sys, json
from pathlib import Path
DEBUG = Path(__file__).resolve().parent
sys.path.insert(0, str(DEBUG))

from frame_renderer import render_frame, assign_content_keys

# ── 加载真实 page7 框架并打寻址 key ──
d = json.load(open(DEBUG / "frameset_abalone.json", encoding="utf-8"))
frame = assign_content_keys([f for f in d["frames"] if f["source_page"] == 7][0])

# ── 每个文字容器的 _content_key → 模板占位符 ──
# 4 竖栏：item_index/item_title/caption/body_text 各 #0..#3
# 对比带：lead_text#0 / body_text#4(正) / body_text#5(反)
# 页头页脚：page_title#0 / page_number#0 / footnote#0
PLACEHOLDER = {
    "page_title#0": "{{TITLE}}",
    "page_number#0": "{{PAGE_NUM}} / {{TOTAL_PAGES}}",
    "footnote#0": "{{FOOTNOTE}}",
    "lead_text#0": "{{BAND_LEAD}}",
    "body_text#4": "{{BAND_POS}}",
    "body_text#5": "{{BAND_NEG}}",
}
for i in range(4):
    PLACEHOLDER[f"item_index#{i}"] = f"{{{{kp{i}_index}}}}"
    PLACEHOLDER[f"item_title#{i}"] = f"{{{{kp{i}_title}}}}"
    PLACEHOLDER[f"caption#{i}"] = f"{{{{kp{i}_caption}}}}"
    PLACEHOLDER[f"body_text#{i}"] = f"{{{{kp{i}_body}}}}"

# esc() 会把 { } 原样保留（只转义 & < >），故占位符安全穿过渲染器
html = render_frame(frame, PLACEHOLDER)

out = DEBUG / "page7_template.html"
out.write_text(html, encoding="utf-8")

# ── 自检：每个占位符都出现、且渲染器没吞掉 ──
missing = [ph for ph in PLACEHOLDER.values() if ph.split("}}")[0] + "}}" not in html]
with io.open(1, "w", encoding="utf-8", closefd=False) as w:
    w.write("=" * 60 + "\n")
    w.write(f"page7 模板已吐出 → {out}  ({len(html)} chars)\n")
    w.write(f"缺失占位符: {missing if missing else '无'}\n")
    w.write(f"容器数: {len(frame['containers'])}\n")
    w.write("-" * 60 + "\n")
    w.write(html + "\n")
