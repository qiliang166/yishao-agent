# -*- coding: utf-8 -*-
"""1:1 remake of Kimi slide 4 as a multi-module composed HTML page.
Coordinates lifted verbatim from kimi_layout_dump.txt (percent of 1280x720).
Uses 13-color variables (var(--...)) resolved from a real scheme.
Pure code composition, real abalone data — no LLM.
"""
import json, yaml, os, sys
# backend/ is two levels up from data/debug/
_BACKEND = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _BACKEND)
os.chdir(_BACKEND)
import services.ppt_service as ps

W, H = 1280, 720
def X(p): return round(W * p / 100)
def Y(p): return round(H * p / 100)

# ---- real data (page 3 principle in outline == "发之道" style content) ----
with open('data/debug/last_outline_response.txt', encoding='utf-8') as f:
    s = f.read().strip()
if s.startswith('```'):
    s = s.split('\n', 1)[1]
    if s.rstrip().endswith('```'): s = s.rsplit('```', 1)[0]
pages = json.loads(s)

# Use the "术：发" table (seq4) which has 发花胶/发花菇 processing data,
# closest to Kimi slide-4 "发之道：海味的深度唤醒".
heading = "发之道：海味的深度唤醒"
seq, total = 4, 11
principle_title = "核心原理：干制-复水的精准控制"
# from seq4 / seq6 real data
principle_body = [
    "花胶处理：先蒸20分钟软化坚硬结构，再以50℃温水浸泡8-9小时，使胶质均匀吸水，达到软糯Q弹",
    "花菇处理：冷水浸泡6-8小时慢发，锁住菇香，菇体饱满有弹性",
]
right_title = "正确操作结果"
right_body = ["花胶：软糯Q弹，胶质完整保留", "花菇：菇香浓郁，口感饱满有弹性", "鲜味物质充分锁存在食材内部"]
wrong_title = "错误操作后果"
wrong_body = ["花胶沸水复水：外层糊化软烂，内部硬芯", "花菇热水急泡：菇香溶于水，菇体无味", "营养与鲜味双重流失"]
params = "关键参数：花胶 蒸20min → 50℃温水浸泡8-9h ｜ 花菇 冷水浸泡6-8h ｜ 核心原则：按食材特性选择复水方式"
source = "Source: 「鲍鱼一品煲」SOP 技术文档"

esc = __import__('html').escape

def box(l, t, w, h, style="", inner=""):
    return (f'<div style="position:absolute;left:{X(l)}px;top:{Y(t)}px;'
            f'width:{X(w)}px;height:{Y(h)}px;{style}">{inner}</div>')

parts = []
# [0] deep header bar 100 x 7.2 primary
parts.append(box(0, 0, 100, 7.2, "background:var(--primary);"))
# accent tick + title inside header
parts.append(box(5, 1.4, 82, 4.4,
    "display:flex;align-items:center;gap:14px;color:#fff;font-size:24px;font-weight:800;letter-spacing:.5px;",
    '<span style="display:inline-block;width:6px;height:26px;background:var(--accent);border-radius:1px;"></span>'
    + esc(heading)))
# [2] page number 04
parts.append(box(90, 1.4, 8, 4.4,
    "display:flex;align-items:center;justify-content:flex-end;color:var(--chart-3);font-size:20px;font-weight:700;",
    f"{seq:02d} / {total:02d}"))

# ---- upper region: left image-block (30%) + right cream principle card (58.8%) ----
# left block (image slot -> dark food block substitute)
parts.append(box(5, 10, 29.7, 38.9,
    "background:linear-gradient(135deg,var(--primary),var(--secondary));border-radius:12px;"
    "overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,.18);display:flex;flex-direction:column;"
    "align-items:center;justify-content:center;gap:14px;",
    '<svg width="72" height="72" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" '
    'stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">'
    '<path d="M12 3c-3 4-6 7-6 11a6 6 0 0012 0c0-4-3-7-6-11z"/></svg>'
    '<div style="color:#fff;font-size:22px;font-weight:800;letter-spacing:2px;">干货复水</div>'
    '<div style="color:rgba(255,255,255,.6);font-size:13px;letter-spacing:1px;">DEHYDRATED · REHYDRATION</div>'))
# right cream card
right_fields = "".join(
    f'<div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:14px;">'
    f'<span style="flex-shrink:0;width:8px;height:8px;margin-top:8px;border-radius:50%;background:var(--accent);"></span>'
    f'<span style="font-size:15.5px;line-height:1.7;color:var(--text);">{esc(b)}</span></div>'
    for b in principle_body)
parts.append(box(36.2, 10, 58.8, 38.9,
    "background:var(--card_bg);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.10);overflow:hidden;",
    # top thin secondary line
    '<div style="position:absolute;top:0;left:0;right:0;height:4px;background:var(--secondary);"></div>'
    f'<div style="padding:30px 34px;">'
    f'<div style="font-size:19px;font-weight:800;color:var(--secondary);margin-bottom:20px;'
    f'padding-bottom:12px;border-bottom:2px solid rgba(var(--secondary-rgb),.15);">{esc(principle_title)}</div>'
    f'{right_fields}</div>'))

# ---- middle region: blue "correct" card + red "wrong" card ----
def result_card(l, title, body, bg, label_color):
    items = "".join(
        f'<div style="display:flex;gap:9px;align-items:flex-start;margin-bottom:9px;">'
        f'<span style="color:{label_color};font-weight:800;flex-shrink:0;">·</span>'
        f'<span style="font-size:13.5px;line-height:1.55;color:rgba(255,255,255,.9);">{esc(b)}</span></div>'
        for b in body)
    return box(l, 51.7, 44.1, 19.4,
        f"background:{bg};border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,.14);overflow:hidden;",
        f'<div style="padding:18px 24px;">'
        f'<div style="font-size:16px;font-weight:800;color:{label_color};margin-bottom:12px;'
        f'display:flex;align-items:center;gap:8px;">'
        f'<span style="width:18px;height:18px;border-radius:5px;background:{label_color};"></span>{esc(title)}</div>'
        f'{items}</div>')
parts.append(result_card(5, right_title, right_body, "var(--primary)", "var(--chart-3)"))
parts.append(result_card(50.9, wrong_title, wrong_body, "var(--semantic-negative)", "#F0C0C0"))

# ---- bottom region: full-width cream param band ----
parts.append(box(5, 73.6, 90, 8.3,
    "background:var(--card_bg);border-radius:10px;border-left:5px solid var(--accent);"
    "display:flex;align-items:center;padding:0 26px;",
    f'<span style="font-size:14.5px;line-height:1.5;color:var(--text);font-weight:600;">{esc(params)}</span>'))
# source footnote
parts.append(box(5, 94.4, 90, 3.5,
    "display:flex;align-items:center;color:rgba(var(--text-rgb),.4);font-size:11px;",
    esc(source)))

slide_html = (f'<div style="position:relative;width:{W}px;height:{H}px;background:var(--background);'
              f"font-family:'DM Sans',Inter,'PingFang SC','Microsoft YaHei',sans-serif;overflow:hidden;\">"
              + "".join(parts) + '</div>')

# resolve colors from a real scheme
with open('resources/vi/business/tokens.yaml', encoding='utf-8') as f:
    tok = yaml.safe_load(f)
scheme = tok['color_schemes']['deep-blue']
root = ps._build_root_vars(scheme)

doc = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
       f'body{{margin:0;background:#2b2b2b;padding:40px;display:flex;justify-content:center;}}</style>'
       f'</head><body>{slide_html}</body></html>')
out = 'data/debug/p4_remake.html'
open(out, 'w', encoding='utf-8').write(doc)
print("wrote", out, len(doc), "bytes")
