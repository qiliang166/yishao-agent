# -*- coding: utf-8 -*-
import json
from collections import Counter

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)

def flat(shapes):
    out = []
    for s in shapes:
        out.append(s)
        if "group" in s:
            out.extend(flat(s["group"]))
    return out

# characterize #B45309 shapes: are they thin hairlines or big blocks?
amber = []
navy = []
card = []
for deck, d in ALL.items():
    for sl in d["slides"]:
        for s in flat(sl["shapes"]):
            f = s.get("fill")
            w = s.get("w") or 0
            h = s.get("h") or 0
            if f == "B45309":
                amber.append((w, h))
            elif f == "0F172A":
                navy.append((w, h))
            elif f == "F1F5F9":
                card.append((w, h))

def summarize(name, arr):
    print(f"\n=== {name} ({len(arr)} shapes) ===")
    thin = sum(1 for w,h in arr if min(w,h) < 1.5)
    small = sum(1 for w,h in arr if w*h < 4)
    big = sum(1 for w,h in arr if w*h >= 100)
    print(f"  thin(min dim<1.5%): {thin}  small(area<4): {small}  big(area>=100): {big}")
    # sample typical dims
    ws = Counter(round(w) for w,h in arr)
    hs = Counter(round(h) for w,h in arr)
    print("  common widths%:", ws.most_common(6))
    print("  common heights%:", hs.most_common(6))

summarize("#B45309 amber", amber)
summarize("#0F172A navy", navy)
summarize("#F1F5F9 card", card)

# check picture fills on autoshapes (background photos)
print("\n=== checking for picture-fill / background images ===")
# python-pptx fill.type: 1=solid,2=patterned,3=gradient,5=grouped,6=background,None; picture=? actually 2?
# We only stored solid fills. Re-open a couple decks to inspect fill types quickly is separate.
print("(need separate pptx re-scan for picture fills)")
