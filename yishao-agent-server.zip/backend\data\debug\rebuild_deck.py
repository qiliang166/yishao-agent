# -*- coding: utf-8 -*-
"""
外科式重建：只替换 principle 页为新的真实提取框架（B7/B4 按条数选），
其余页 100% 沿用上次生产已生成好的 html（含封面真实配图），不重跑、不打扰。
证明：principle 用真实 PPT 提取框架（非手写）、整页零溢出/零残留/配色全变量。
"""
import io, sys, json, re
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from services.ppt_service import (
    _select_framework_template, _fill_slide_template, _resolve_color_vars,
    _load_style_vi_section, _fit_code_filled_slides, _assemble_html_deck,
    _load_scheme_data,
)

STYLE_ID, SCHEME, COLUMN, PROJECT_ID = "business", "chinese-red", "col4", "fcf32913a82b"
OUT = Path(r"D:\YISHAOAGENT\data\output\鲍鱼一品煲\鲍鱼一品煲_col4")

d = json.load(open(OUT / "result.json", encoding="utf-8"))
slide_plan = d["slide_plan"]
total = len(slide_plan)
active_scheme = _load_scheme_data(STYLE_ID, SCHEME)

# ── only re-fill principle; keep every other saved slide untouched ──
rebuilt = []
for s in slide_plan:
    if s.get("type") == "principle":
        vi = _load_style_vi_section(STYLE_ID, "principle", SCHEME, resolve_vars=False,
                                    column_id=COLUMN, project_id=PROJECT_ID)
        kp = s.get("key_points", [])
        tmpl = _select_framework_template(vi, len(kp))
        html_vars = _fill_slide_template(tmpl, s, total)
        html = _resolve_color_vars(html_vars, active_scheme, css_vars=True)
        which = "B7四栏" if html.count("flex:1 1 0") >= 2 else "B4单条"
        rebuilt.append({**s, "html": html, "html_vars": html_vars, "_code_filled": True})
        print(f"  seq{s.get('seq')} principle → 真实框架 {which} (kp={len(kp)})")
    else:
        rebuilt.append({**s})  # keep saved html/html_vars verbatim

# fit-to-box only touches _code_filled (= just principle here)
rebuilt = _fit_code_filled_slides(rebuilt, active_scheme, 1280, 720)

title = slide_plan[0].get("heading", "") or "Presentation"
deck = _resolve_color_vars(_assemble_html_deck(rebuilt, title, STYLE_ID, active_scheme, canvas_w=1280, canvas_h=720),
                           active_scheme, css_vars=True)
(OUT / "index.html").write_text(deck, encoding="utf-8")
vars_slides = [{**x, "html": x.get("html_vars", x.get("html", ""))} for x in rebuilt]
(OUT / "index_vars.html").write_text(
    _assemble_html_deck(vars_slides, title, STYLE_ID, active_scheme, canvas_w=1280, canvas_h=720), encoding="utf-8")

# persist principle back into result.json so page reload shows new framework
d["slide_plan"] = rebuilt
json.dump(d, open(OUT / "result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)

resid = [r for r in re.findall(r"\{\{[^}]+\}\}", deck) if r != "{{IMAGE_URL}}"]
m = re.search(r":root\s*\{[^}]*\}", deck); root = m.group(0) if m else ""
bad = [h for h in re.findall(r"#[0-9a-fA-F]{3,8}", deck.replace(root, ""))
       if h.lower() not in ("#ffffff", "#fff")]
print("-" * 56)
print(f"整套 index.html: {len(deck)} chars, {total} 页")
print(f"残留占位符(排除IMAGE_URL): {len(resid)} {resid[:5]}")
print(f":root 外非白硬编码hex: {len(bad)} {bad[:5]}")
print(f"写出: {OUT/'index.html'}")
