# -*- coding: utf-8 -*-
import json, re
from collections import Counter, defaultdict

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)
def flat(shapes):
    out=[]
    for s in shapes:
        out.append(s)
        if "group" in s: out.extend(flat(s["group"]))
    return out
def area(s): return (s.get("w") or 0)*(s.get("h") or 0)

CARD_FILLS={"F1F5F9","E2E8F0","ECEFF1","F8FAFC","FEF3C7","FFF7ED","FEF2F2","F0FDF4","FDE68A","FCE7F3","FFFFFF","E0F2FE","E0F7FA","C8E6C9","F9F3D9","F9E5A3","FEF9C3"}
NAVY={"0F172A","1E293B","334155","475569","455A64","64748B","1B3A5C"}
AMBER={"B45309","D97706","F59E0B","92400E","FCD34D","F0BC6E","D99E3E"}
RED={"DC2626","EF4444","CB4335"}

def assign(deck, sl):
    fs=flat(sl["shapes"])
    page=sl["page"]
    npic=sum(1 for s in fs if s["kind"]=="PICTURE")
    ntab=sum(1 for s in fs if s["kind"]=="TABLE")
    mf=max((max(t["sizes"]) for s in fs if (t:=s.get("txt")) and t["sizes"]),default=0)
    txts=[t["text"] for s in fs if (t:=s.get("txt")) and t["chars"]>0]
    alltxt=" ".join(txts)
    # 1 COVER
    if page==1: return "C-COVER"
    # back cover (last page with full-width nav photo/panel + methodology)
    if npic>=1 and any((s.get("h") or 0)>55 and (s.get("w") or 0)>90 for s in fs if s["kind"] in ("PICTURE","AUTO_SHAPE")) and ("方法论" in alltxt or "Methodology" in alltxt or "交响" in alltxt):
        return "C-BACKCOVER"
    # TOC
    if "CONTENTS" in alltxt:
        return "C-TOC"
    # SECTION divider (giant number)
    if mf>=120:
        return "C-SECTION"
    # TABLE full page (single big table, few other content)
    big_tab=[s for s in fs if s["kind"]=="TABLE" and (s.get("h") or 0)>40]
    if big_tab and ntab>=1 and len([s for s in fs if s.get("fill") and area(s)>=120])<=1:
        return "H-TABLE"
    # DIAGNOSTIC tree (many 否→/是→ or connector arrows + question boxes)
    arrows=sum(1 for s in fs if (t:=s.get("txt")) and t["text"] in ("否→","是→")) + alltxt.count("→")
    qboxes=sum(1 for s in fs if s.get("fill") in (NAVY|AMBER) and 4<(s.get("h") or 0)<8 and 10<(s.get("w") or 0)<25 and (t:=s.get("txt")) and t["chars"]>1 and t["chars"]<12)
    if ("诊断树" in alltxt or "诊断" in alltxt and "树" in alltxt) and (arrows>=4 or qboxes>=3):
        return "H-DIAGTREE"
    # cards analysis
    cards=[s for s in fs if s.get("fill") and area(s)>=120 and (s.get("w") or 0)<96 and (s.get("t") or 0)>3 and (s.get("h") or 0)>10]
    tall_cards=[c for c in cards if (c.get("h") or 0)>30]
    # columns among tall cards in main band
    def colcount(cs, hmin):
        main=[c for c in cs if (c.get("h") or 0)>hmin and 10<(c.get("t") or 0)<45]
        lefts=sorted(set(round(c.get("l") or 0) for c in main))
        m=[]
        for l in lefts:
            if not m or l-m[-1]>6: m.append(l)
        return len(m), main
    ncol, maincards = colcount(cards, 25)
    # full-width stacked bands (color rows)
    bands=[s for s in fs if s.get("fill") in (AMBER|NAVY|CARD_FILLS) and (s.get("w") or 0)>=80 and 4<(s.get("h") or 0)<14 and (s.get("t") or 0)>12]
    # color swatch flow (small colored cards w~20 h5-15 with tiny caption, many pastel fills)
    pastel=[s for s in fs if s.get("fill") and s.get("fill") not in (NAVY|AMBER) and s.get("fill") in CARD_FILLS and 15<(s.get("w") or 0)<25 and 4<(s.get("h") or 0)<16]
    conn=sum(1 for s in fs if s.get("fill") in AMBER and 1.3<(s.get("w") or 0)<4 and 1.3<(s.get("h") or 0)<4)
    # SOP flow overview: 4-6 columns short cards + arrows between + big footer band
    if ("流程" in alltxt or "SOP" in alltxt) and ncol>=4:
        return "H-SOPFLOW"
    # timeline/color path (vertical steps or swatch progression)
    if ("色泽" in alltxt or "路径" in alltxt or ("→" in alltxt and pastel)) and (len(pastel)>=3 or (conn>=3 and ncol<=1)):
        return "H-TIMELINE"
    # image + info cards (food archive with photo)
    if npic>=1:
        return "H-IMGCARDS"
    # step detail 3-col (OPERATION/SCIENCE/TRANSFER) tall cards, ncol==3
    if ncol>=3 and tall_cards:
        # distinguish 3 tall vs 3 short. If cards very tall (h>45) -> deep step; else 3 principle cards
        if any((c.get("h") or 0)>45 for c in maincards):
            return "H-STEP3COL"
        return "H-3CARD"
    if ncol==2:
        return "H-2COL"
    # stacked full-width bands (>=3)
    if len(bands)>=3:
        return "H-STACKBANDS"
    # matrix/quadrant or single big principle: fallback
    # workflow strip (technique) small cards row h<15 across top with conn arrows + big body bands below
    strip=[s for s in fs if s.get("fill") in (NAVY|AMBER|CARD_FILLS) and 10<(s.get("w") or 0)<25 and 6<(s.get("h") or 0)<15 and 13<(s.get("t") or 0)<30]
    if len(strip)>=4 and conn>=3:
        return "H-WORKFLOW"
    if cards or bands:
        return "H-MIXED"
    return "H-OTHER"

assign_map=defaultdict(list)
per=[]
for deck,d in ALL.items():
    for sl in d["slides"]:
        sk=assign(deck,sl)
        assign_map[sk].append(f"{deck}p{sl['page']}")
        per.append((deck,sl["page"],sk))

print("=== SKELETON assignment counts ===")
for sk,pages in sorted(assign_map.items(), key=lambda x:-len(x[1])):
    print(f"  {sk}: {len(pages)}")
print("\n=== H-MIXED / H-OTHER pages (need manual) ===")
for sk in ("H-MIXED","H-OTHER","H-WORKFLOW"):
    print(f" [{sk}]", assign_map.get(sk,[]))

with open(r"D:\YISHAOAGENT\backend\data\debug\col5_assign.json","w",encoding="utf-8") as f:
    json.dump({k:v for k,v in assign_map.items()}, f, ensure_ascii=False, indent=1)
