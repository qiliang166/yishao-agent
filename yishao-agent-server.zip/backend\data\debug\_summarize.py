# -*- coding: utf-8 -*-
import json

with open(r"D:\YISHAOAGENT\backend\data\debug\skeleton_raw.json", encoding="utf-8") as f:
    ALL = json.load(f)

def flat(shapes):
    out = []
    for s in shapes:
        out.append(s)
        if "group" in s:
            out.extend(flat(s["group"]))
    return out

# color legend
LEG = {
    "0C1B33":"navy","0B1B33":"navy","0C1C33":"navy","102A43":"navy2",
    "1B3A5C":"navy-sec","5C1A1A":"red","7A1F1F":"red","8B1A1A":"red",
    "F0EDE8":"cream","F5F1EA":"cream","FAF7F2":"cream","FFFFFF":"white",
    "B87333":"copper","C08A3E":"copper","BFA06A":"gold","C9A84C":"gold",
}
def cname(hx):
    if not hx: return ""
    h = hx.upper()
    return LEG.get(h, "#"+h)

for deck, d in ALL.items():
    print(f"\n=================== {deck}  ({d['nslides']} slides) ===================")
    for sl in d["slides"]:
        shapes = flat(sl["shapes"])
        pics = [s for s in shapes if s["kind"].startswith("PICTURE")]
        tables = [s for s in shapes if s["kind"].startswith("TABLE")]
        texts = [s for s in shapes if "txt" in s]
        fills = [s for s in shapes if "fill" in s and s.get("w") and s["w"]>3 and s.get("h") and s["h"]>3]
        # total chars
        tot = sum(s["txt"]["chars"] for s in texts)
        # biggest font on page
        allsizes = sorted({z for s in texts for z in s["txt"]["sizes"]})
        maxfont = allsizes[-1] if allsizes else 0
        print(f"\n-- p{sl['page']:>2}  shapes={len(shapes)} pics={len(pics)} tables={len(tables)} txt={len(texts)} totchars={tot} maxfont={maxfont}")
        # list big colored blocks (regions)
        for s in sorted(fills, key=lambda x:(x.get("t") or 0, x.get("l") or 0)):
            print(f"    BOX {cname(s.get('fill')):>8}  L{s['l']:>5} T{s['t']:>5} W{s['w']:>5} H{s['h']:>5}")
        # pictures
        for s in sorted(pics, key=lambda x:(x.get("t") or 0, x.get("l") or 0)):
            print(f"    PIC          L{s['l']:>5} T{s['t']:>5} W{s['w']:>5} H{s['h']:>5}")
        # tables
        for s in tables:
            print(f"    TBL          L{s['l']:>5} T{s['t']:>5} W{s['w']:>5} H{s['h']:>5}")
        # significant texts (chars>0), sorted top->down
        for s in sorted(texts, key=lambda x:(x.get("t") or 0, x.get("l") or 0)):
            ti = s["txt"]
            if ti["chars"]==0: continue
            szs = ",".join(str(z) for z in ti["sizes"]) or "-"
            b = "B" if ti["bold"] else " "
            print(f"    T L{s['l']:>5} T{s['t']:>5} W{s['w']:>5} H{s['h']:>5} sz[{szs:>7}]{b} c={ti['chars']:>4} | {ti['text']}")
