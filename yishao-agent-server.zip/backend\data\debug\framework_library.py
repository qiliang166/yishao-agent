# -*- coding: utf-8 -*-
"""
框架库：把提取的 16 个框架整理成"给大模型看的目录" + "每个框架的槽位清单"。
- 目录：每个框架的 id / 页型 / 容器构成摘要（大模型据此选框架）
- 槽位：每个框架的文字格子 content_key 列表（大模型据此填内容）
渲染用 frame_renderer（几何全来自 JSON，零手写）。
"""
import json
from pathlib import Path
from frame_renderer import render_frame, assign_content_keys

DEBUG = Path(__file__).resolve().parent
_FS = json.load(open(DEBUG / "frameset_abalone.json", encoding="utf-8"))
_CANVAS_W, _CANVAS_H = _FS.get("canvas", [1280, 720])

# 每个角色的行高（与 frame_renderer.ROLE_STYLE 一致），用于算容量
_ROLE_LH = {
    "page_title": 1.2, "page_number": 1.0, "hero_numeral": 0.9, "hero_word": 1.0,
    "item_index": 1.0, "section_title": 1.2, "item_title": 1.2, "lead_text": 1.3,
    "item_subtitle": 1.3, "caption": 1.35, "body_text": 1.55, "footnote": 1.4, "text": 1.5,
}


def _capacity(geom, fs, role):
    """该文字格子能舒适容纳的中文字数（宽×高 / 字号，含内边距余量）。"""
    if not fs:
        fs = 14
    lh = _ROLE_LH.get(role, 1.5)
    w = geom["W"] / 100 * _CANVAS_W - 16   # 减内边距
    h = geom["H"] / 100 * _CANVAS_H - 8
    per_line = max(1, int(w // fs))        # 每行字数（中文约=字号宽）
    lines = max(1, int(h // (fs * lh)))    # 行数
    return per_line * lines

# 角色 → 大模型能懂的中文用途（帮它决定填什么内容）
ROLE_DESC = {
    "page_title": "页面主标题", "page_number": "页码", "hero_numeral": "大号数字",
    "hero_word": "大号词", "item_index": "条目序号", "section_title": "章节大标题",
    "item_title": "条目标题", "lead_text": "引导句/小标题", "item_subtitle": "条目副标题",
    "caption": "小注/说明", "body_text": "正文", "footnote": "脚注", "text": "文字",
}


def _frame_by_id(fid):
    for f in _FS["frames"]:
        if f["frame_id"] == fid:
            return assign_content_keys(f)
    return None


def frame_catalog():
    """返回给大模型的框架目录：[{id, page_type, page, summary, slots:[{key,role,role_cn,fs,example}]}]"""
    cat = []
    for f in _FS["frames"]:
        frame = assign_content_keys(f)
        slots, panels, pics, tables = [], 0, 0, 0
        for c in sorted(frame["containers"], key=lambda x: x["z"]):
            if c["role"] == "panel":
                panels += 1; continue
            if c["role"] == "divider":
                continue
            if c["kind"] == "PICTURE":
                pics += 1; continue
            if c["kind"] == "TABLE":
                tables += 1; continue
            key = c.get("_content_key")
            if not key:
                continue
            slots.append({
                "key": key, "role": c["role"],
                "role_cn": ROLE_DESC.get(c["role"], c["role"]),
                "fs": c["fs"],
                "cap": _capacity(c["geom"], c["fs"], c["role"]),
                "example": (c.get("example") or "")[:24],
            })
        # 摘要：几个填色块 + 几个文字槽 + 图/表
        summary = (f"{panels}个色块背板, {len(slots)}个文字位"
                   + (f", {pics}张图" if pics else "")
                   + (f", {tables}个表格" if tables else ""))
        cat.append({
            "id": f["frame_id"], "page_type": f["page_type"],
            "page": f["source_page"], "n_slots": len(slots),
            "summary": summary, "slots": slots,
        })
    return cat


def render_with_content(frame_id, content: dict):
    """用指定框架 + 内容字典渲染 HTML（几何来自 JSON）。缺失槽位回退原文 example。"""
    frame = _frame_by_id(frame_id)
    if frame is None:
        return ""
    return render_frame(frame, content)


if __name__ == "__main__":
    import io, sys
    w = io.open(1, "w", encoding="utf-8", closefd=False)
    cat = frame_catalog()
    w.write(f"框架库：{len(cat)} 个框架\n" + "=" * 60 + "\n")
    for c in cat:
        w.write(f"\n[{c['id']}]  页型={c['page_type']}  {c['summary']}\n")
        for s in c["slots"][:6]:
            w.write(f"    {s['key']:16} {s['role_cn']:<8} fs={s['fs']} 例:{s['example']}\n")
        if len(c["slots"]) > 6:
            w.write(f"    …… 共 {len(c['slots'])} 个文字位\n")
    w.flush()
