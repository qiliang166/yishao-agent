# -*- coding: utf-8 -*-
import json
from collections import defaultdict
import statistics as st

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)
def flat(shapes):
    out=[]
    for s in shapes:
        out.append(s)
        if "group" in s: out.extend(flat(s["group"]))
    return out
def summ(name, arr):
    if not arr: print(f"  {name}: (none)"); return
    arr=sorted(arr)
    print(f"  {name}: n={len(arr)} min={arr[0]} med={st.median(arr):.0f} p75={arr[3*len(arr)//4]} max={arr[-1]}")

NAVY={"0F172A","1E293B","334155","475569","64748B"}
AMBER={"B45309","D97706"}
# full-width insight band: wide (w>=80), t>50 usually, sz14-15, chars 40-90
band=[]
toc_sub=[]; toc_head=[]
cover_sub=[]
swatch=[]  # small stage cards h8-15 chars<30
for deck,d in ALL.items():
    for sl in d["slides"]:
        fs=flat(sl["shapes"])
        for s in fs:
            t=s.get("txt")
            if not t or t["chars"]==0: continue
            sz=max(t["sizes"]) if t["sizes"] else 0
            l,tp,w,h=s.get("l") or 0,s.get("t") or 0,s.get("w") or 0,s.get("h") or 0
            ch=t["chars"]
            if 14<=sz<=15 and w>=80 and ch>=30:
                band.append(ch)
            if sz==18 and 30<=w<=45 and ch<=12:  # TOC row title
                toc_head.append(ch)
            if sz==13 and 30<=w<=45 and ch>=8:   # TOC row subtitle
                toc_sub.append(ch)

print("=== insight full-width band (sz14-15, w>=80) ===")
summ("insight_band", band)
print("=== TOC row title (sz18) / subtitle (sz13) ===")
summ("toc_title", toc_head); summ("toc_subtitle", toc_sub)

# near-duplicate check: compare 萝卜焖牛腩01 vs 萝卜焖牛腩1 titles+shape counts
a=ALL["萝卜焖牛腩01"]; b=ALL["萝卜焖牛腩1"]
print("\n=== dup check 萝卜焖牛腩01 vs 1 ===")
print("nslides:", a["nslides"], b["nslides"])
diff=0
for i in range(min(a["nslides"],b["nslides"])):
    na=len(flat(a["slides"][i]["shapes"])); nb=len(flat(b["slides"][i]["shapes"]))
    if na!=nb: diff+=1
print("pages with differing shape count:", diff, "/", a["nslides"])

# count section-kind occurrences by keyword in titles
import re
kinds=defaultdict(int)
def classify_title(tt):
    if not tt: return None
    if "CONTENTS" in tt: return "目录TOC"
    if re.fullmatch(r"0\d", tt.strip()): return "章节分隔SECTION"
    if "香气" in tt: return "香气构成"
    if "口感" in tt: return "口感递进"
    if "色泽" in tt: return "色泽路径"
    if "原理" in tt or "化学" in tt or "知识点" in tt: return "原理总览"
    if "流程" in tt or "SOP" in tt or "工艺流程" in tt: return "SOP流程图"
    if "步骤" in tt or "关键步骤" in tt: return "步骤详解"
    if "食材" in tt or "档案" in tt or tt.startswith("核心食材") or "：鲍鱼" in tt or "猪肚" in tt or "白胡椒" in tt: return "食材档案"
    if "技法" in tt: return "技法卡片"
    if "诊断" in tt: return "诊断树"
    if "对照表" in tt or "解决方案" in tt or "速查" in tt: return "解决方案表"
    if "笔记" in tt: return "厨师笔记"
    if "方法论" in tt or "升华" in tt or "结语" in tt or "交响" in tt: return "结语升华"
    if "之道" in tt: return "道术原理(鱼头)"
    if "路径" in tt or "自检" in tt or "图谱" in tt: return "学习路径/图谱"
    return "其他:"+tt[:8]
for deck,d in ALL.items():
    for sl in d["slides"]:
        fs=flat(sl["shapes"])
        # reuse title heuristic
        cands=[s for s in fs if (t:=s.get("txt")) and t["chars"]>1 and t["sizes"] and max(t["sizes"])>=26 and 3<(s.get("t") or 0)<10]
        title=""
        if cands:
            cands.sort(key=lambda s:s.get("t") or 0); title=cands[0]["txt"]["text"]
        else:
            big=[s for s in fs if (t:=s.get("txt")) and t["sizes"] and max(t["sizes"])>=40]
            if big: title=big[0]["txt"]["text"]
            # section number pages
            sec=[s for s in fs if (t:=s.get("txt")) and t["sizes"] and max(t["sizes"])>=150]
            if sec: title="0"+sec[0]["txt"]["text"][-1] if sec[0]["txt"]["text"][-1].isdigit() else "0X"
        # cover detection page1
        if sl["page"]==1: title=title or "COVER"
        k=classify_title(title) or ("封面COVER" if sl["page"]==1 else "?")
        if sl["page"]==1: k="封面COVER"
        kinds[k]+=1
print("\n=== SECTION KIND counts across 279 pages ===")
for k,c in sorted(kinds.items(), key=lambda x:-x[1]):
    print(f"  {k}: {c}")
