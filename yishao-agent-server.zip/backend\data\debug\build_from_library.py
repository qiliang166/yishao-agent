# -*- coding: utf-8 -*-
"""
端到端构建器：用 16 框架库 + 大模型选框架 + 填内容 → 合成整套 PPT。
流程（每页）：
  1) 把内容(heading/key_points/body) + 框架目录 给大模型
  2) 大模型输出：选哪个 frame_id + 每个槽位填什么(content_key→文本)
  3) 用 frame_renderer 按该框架真实几何渲染，配色走 VI 变量
几何/坐标/配色 100% 锁死在框架里，大模型只选+填。
"""
import io, sys, json, re, asyncio
from pathlib import Path
DEBUG = Path(__file__).resolve().parent
sys.path.insert(0, str(DEBUG))
sys.path.insert(0, str(DEBUG.parents[1]))

from framework_library import frame_catalog, render_with_content
from services.ppt_service import _resolve_color_vars, _load_scheme_data, _build_root_vars, _clean_json_response
from services.llm_service import generate as llm_generate

PROVIDER, MODEL = "0df96678", "deepseek-v4-pro"   # DeepSeek
SCHEME = "chinese-red"

CAT = frame_catalog()
# 精简目录给大模型（去掉 example 里的长文本，只留结构信号）
def _catalog_for_llm():
    lines = []
    for c in CAT:
        slot_brief = ", ".join(f"{s['key']}({s['role_cn']}≤{s['cap']}字)" for s in c["slots"])
        lines.append(f"- {c['id']} [页型:{c['page_type']}, {c['summary']}]\n    槽位: {slot_brief}")
    return "\n".join(lines)

SYS = """你是PPT排版助手。用户给你一页的内容，你从"框架库"里选一个最合适的框架，并把内容填进框架的每个槽位。

规则：
1. 只能从框架库里选一个已存在的 frame_id，不许自创。
2. 按页面用途选：封面→cover框架, 目录→toc, 章节隔断→section, 正文要点→content/grid, 表格数据→table, 结尾→closing。
3. 每个槽位(content_key)填一段贴合其用途(role_cn)和字号的文字；正文可用\\n换行分点。
4. 严格遵守每个槽位的字数上限(≤N字)：宁可精炼删减，绝不超过上限，否则会溢出格子。
5. 输出纯JSON：{"frame_id":"...", "slots":{"content_key":"文本", ...}}，不输出别的。"""

def pick_and_fill(slide: dict) -> dict:
    heading = slide.get("heading", "")
    kps = slide.get("key_points", [])
    body = slide.get("body", "")
    stype = slide.get("type", "content")
    user = (f"【本页内容】\n页型建议: {stype}\n标题: {heading}\n"
            f"正文: {body[:400]}\n要点:\n"
            + "\n".join(f"  - {k if isinstance(k,str) else json.dumps(k,ensure_ascii=False)}" for k in kps)
            + f"\n\n【框架库】\n{_catalog_for_llm()}\n\n"
            f"请选一个 frame_id 并填满其槽位。输出JSON。")
    last_err = None
    for attempt in range(3):
        try:
            resp = asyncio.run(llm_generate(PROVIDER, MODEL, SYS, user, temperature=0.3, max_tokens=4096))
            cleaned = _clean_json_response(resp)
            if not cleaned.strip():
                last_err = "空响应"; continue
            data = json.loads(cleaned)
            if data.get("frame_id"):
                return data
            last_err = "缺frame_id"
        except Exception as e:
            last_err = str(e)
    raise ValueError(f"3次重试均失败: {last_err}")

def build_deck(slide_plan: list) -> list:
    out = []
    for i, s in enumerate(slide_plan, 1):
        try:
            pick = pick_and_fill(s)
            fid = pick.get("frame_id", "")
            slots = pick.get("slots", {})
            html = render_with_content(fid, slots)
            if not html:
                out.append({"seq": i, "error": f"未知frame_id={fid}", "heading": s.get("heading")})
                continue
            out.append({"seq": i, "frame_id": fid, "html": html,
                        "heading": s.get("heading"), "n_slots_filled": len(slots)})
            print(f"  seq{i}: {s.get('heading','')[:16]} → {fid} (填{len(slots)}槽)")
        except Exception as e:
            out.append({"seq": i, "error": str(e), "heading": s.get("heading")})
            print(f"  seq{i}: ERROR {e}")
    return out

if __name__ == "__main__":
    # 用鲍鱼真实大纲测试
    res = json.load(open(r"D:\YISHAOAGENT\data\output\鲍鱼一品煲\鲍鱼一品煲_col4\result.json", encoding="utf-8"))
    plan = res["slide_plan"]
    print(f"开始构建 {len(plan)} 页（大模型选框架+填内容）...")
    built = build_deck(plan)

    scheme = _load_scheme_data("business", SCHEME)
    root = _build_root_vars(scheme)

    # fit-to-box 兜底：框架格子固定，大模型偶尔仍稍长 → 自动缩字号到不裁切
    from services.ppt_service import _fit_code_filled_slides
    fit_items = [{"_code_filled": True, "html_vars": b["html"], "html": b["html"], "seq": b["seq"]}
                 for b in built if b.get("html")]
    fitted = _fit_code_filled_slides(fit_items, scheme, 1280, 720)
    fit_by_seq = {x["seq"]: x["html_vars"] for x in fitted}

    pages = []
    for b in built:
        if b.get("html"):
            raw = fit_by_seq.get(b["seq"], b["html"])
            h = _resolve_color_vars(raw, scheme, css_vars=True)
            pages.append(f"<div style='margin:20px auto;width:1280px;'>"
                         f"<div style='font:600 13px sans-serif;color:#666;margin-bottom:4px'>seq{b['seq']} · {b['frame_id']}</div>{h}</div>")
        else:
            pages.append(f"<div style='margin:20px auto;width:1280px;padding:40px;background:#fee;font:14px sans-serif'>seq{b['seq']} 失败: {b.get('error')}</div>")
    doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n*{{margin:0;padding:0;box-sizing:border-box}}</style></head>"
           f"<body style='background:#ddd;padding:20px'>{''.join(pages)}</body></html>")
    out_html = DEBUG / "deck_from_library.html"
    out_html.write_text(doc, encoding="utf-8")

    ok = sum(1 for b in built if b.get("html"))
    w = io.open(1, "w", encoding="utf-8", closefd=False)
    w.write("=" * 56 + f"\n成功 {ok}/{len(built)} 页 → {out_html}\n")
    w.flush()
