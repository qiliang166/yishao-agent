# -*- coding: utf-8 -*-
"""
确定性验证（不依赖LLM）：把 16 个真实框架各填满代表性文字 → 走生产的
_fit_code_filled_slides（双向填+对比度校正）→ Playwright 逐页实测每个内容 DIV
的填充率(scrollHeight/clientHeight) 与 WCAG 对比度。

判据：
  - 每个内容 DIV 填充率 ≥ 0.60（page_number/图片区 豁免）
  - 每个文字 DIV 对比度 ≥ 4.5（无白压白/黑压黑）
  - spill=0, clip=0, 残留 {{}}=0, 非白硬编码 hex=0
"""
import io, sys, re, json
from pathlib import Path

BK = Path(__file__).resolve().parents[2]  # backend/
sys.path.insert(0, str(BK))

from services import frameset_service as fset
from services.ppt_service import (
    _fit_code_filled_slides, _load_scheme_data, _build_root_vars,
)

STYLE, SCHEME = "business", "chinese-red"
w = io.open(1, "w", encoding="utf-8", closefd=False)

# 代表性填充文本：按 cap 生成刚好接近容量的中文，模拟"大模型填满60-100%"
_LOREM = "鲍鱼一品煲的烹饪讲究火候与时间的精准把控核心在于文火慢炖使胶质充分释放"


def _fill_text(cap: int) -> str:
    n = max(4, int(cap * 0.8))
    s = (_LOREM * ((n // len(_LOREM)) + 1))[:n]
    return s


def main():
    fs = fset.load_frameset(STYLE)
    cat = {c["id"]: c for c in fset.frame_catalog(fs)}
    scheme = _load_scheme_data(STYLE, SCHEME)

    slides = []
    for fr in fs["frames"]:
        fid = fr["frame_id"]
        c = cat[fid]
        slots = {}
        for s in c["slots"]:
            if s.get("optional"):      # 图片区不强制填（本轮可留空）
                continue
            if s["role"] == "page_number":
                continue
            slots[s["key"]] = _fill_text(s["cap"])
        hv = fset.render_from_vi(STYLE, fid, slots, seq=1, total=16)
        if not hv:
            w.write(f"  {fid}: render_from_vi 空!\n"); continue
        slides.append({"seq": len(slides) + 1, "type": fr["page_type"],
                       "frame_id": fid, "_code_filled": True, "html_vars": hv})

    w.write(f"构造 {len(slides)} 页(每页填满内容槽) → 跑 _fit_code_filled_slides\n"); w.flush()
    slides = _fit_code_filled_slides(slides, scheme, 1280, 720)

    root = _build_root_vars(scheme)
    from playwright.sync_api import sync_playwright

    JS = r"""
    () => {
      const slide=document.querySelector('body>div');
      const S=slide.getBoundingClientRect();
      const px=v=>parseFloat(v)||0;
      const isPageNum=t=>/^\s*\d+\s*\/\s*\d+\s*$/.test(t);
      const lum=(r,g,b)=>{const a=[r,g,b].map(v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);});return 0.2126*a[0]+0.7152*a[1]+0.0722*a[2];};
      const parse=c=>{const m=(c||'').match(/rgba?\(([^)]+)\)/);if(!m)return null;const p=m[1].split(',').map(x=>parseFloat(x));return {r:p[0],g:p[1],b:p[2],a:p.length>3?p[3]:1};};
      const bgOf=e=>{const r=e.getBoundingClientRect();
        const stack=document.elementsFromPoint(r.left+r.width/2,r.top+r.height/2);
        for(const el of stack){if(el===e||e.contains(el))continue;
          const bg=parse(getComputedStyle(el).backgroundColor);if(bg&&bg.a>=0.5)return bg;}
        const sb=parse(getComputedStyle(slide).backgroundColor);return sb&&sb.a>=0.5?sb:{r:255,g:255,b:255,a:1};};
      let clip=0,spill=0,minFill=1,lowc=0,under=0,checked=0;
      slide.querySelectorAll('div,span').forEach(e=>{
        const r=e.getBoundingClientRect();
        spill=Math.max(spill,Math.max(0,r.right-S.right),Math.max(0,r.bottom-S.bottom),
              Math.max(0,S.left-r.left),Math.max(0,S.top-r.top));
        if(e.children.length)return;
        const t=(e.textContent||'').trim(); if(!t)return;
        clip=Math.max(clip,e.scrollHeight-e.clientHeight);
        // 内容DIV：排除页码、极小框
        if(!isPageNum(t)&&e.clientHeight>=24&&e.clientWidth>=40){
          checked++;
          const fill=e.scrollHeight/Math.max(1,e.clientHeight);
          minFill=Math.min(minFill,fill); if(fill<0.60)under++;
        }
        const fg=parse(getComputedStyle(e).color); if(fg){const bg=bgOf(e);
          const Lf=lum(fg.r,fg.g,fg.b)+0.05,Lb=lum(bg.r,bg.g,bg.b)+0.05;
          const ratio=Lf>Lb?Lf/Lb:Lb/Lf; if(ratio<4.5)lowc++;}
      });
      return {clip:Math.round(clip),spill:Math.round(spill),
              minFill:Math.round(minFill*100)/100,under,lowc,checked};
    }
    """
    tot = {"clip": 0, "spill": 0, "under": 0, "lowc": 0, "resid": 0, "hex": 0}
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1280, "height": 720})
        for s in slides:
            h = s.get("html", "")
            resid = len(re.findall(r"\{\{[^}]+\}\}", h))
            hexes = [x for x in re.findall(r"#[0-9a-fA-F]{6}", h)
                     if x.lower() not in ("#ffffff", "#fff")]
            doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n"
                   f"*{{box-sizing:border-box}}html,body{{margin:0;padding:0}}</style></head>"
                   f"<body>{h}</body></html>")
            pg.set_content(doc)
            m = pg.evaluate(JS)
            tot["clip"] = max(tot["clip"], m["clip"]); tot["spill"] = max(tot["spill"], m["spill"])
            tot["under"] += m["under"]; tot["lowc"] += m["lowc"]
            tot["resid"] += resid; tot["hex"] += len(hexes)
            flag = "" if (m["clip"] == 0 and m["spill"] == 0 and m["under"] == 0
                          and m["lowc"] == 0 and resid == 0 and not hexes) else "  <-- CHECK"
            w.write(f"  seq{s['seq']:2} {s['frame_id']:22} 内容DIV={m['checked']:2} "
                    f"minFill={m['minFill']:.2f} 欠填={m['under']} 低对比={m['lowc']} "
                    f"clip={m['clip']} spill={m['spill']} resid={resid} hex={len(hexes)}{flag}\n")
            w.flush()
        b.close()

    w.write("=" * 64 + "\n")
    w.write(f"汇总: 欠填DIV={tot['under']} 低对比DIV={tot['lowc']} "
            f"max_clip={tot['clip']} max_spill={tot['spill']} "
            f"残留={tot['resid']} 非白hex={tot['hex']}\n")
    ok = (tot["under"] == 0 and tot["lowc"] == 0 and tot["clip"] == 0
          and tot["spill"] == 0 and tot["resid"] == 0 and tot["hex"] == 0)
    w.write(f"判据(欠填=0 低对比=0 clip=0 spill=0 残留=0 非白hex=0): "
            f"{'PASS' if ok else 'FAIL'}\n")
    w.flush()


if __name__ == "__main__":
    main()
