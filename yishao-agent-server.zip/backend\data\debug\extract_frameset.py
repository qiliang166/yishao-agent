# -*- coding: utf-8 -*-
"""
框架集提取器（增强版）：一份 PPT → 一套可渲染的容器 JSON
每页 = 一个框架；每个有文字/填色的形状 = 一个容器。
提取每容器：z层级 + 坐标(L/T/W/H %) + 字号 + 填色 + 文字颜色 + 通用角色 + 原文例子。
配色：PPT真实hex → VI 13色变量（渲染时走当前项目配色，符合"配色是VI核心"）。
输出 JSON（渲染器直接读，几何100%来自这里，不手写坐标）。
"""
import io, sys, json
from pathlib import Path
from pptx import Presentation
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

PPT = r"D:\智绘食谱\酒店菜品\PPT模版\「鲍鱼一品煲」SOP 的_道_与_术_.pptx"
OUT_DIR = Path(r"D:\YISHAOAGENT\backend\data\debug")
CANVAS_W, CANVAS_H = 1280, 720

prs = Presentation(PPT)
SW, SH = prs.slide_width, prs.slide_height

# ── 配色映射：PPT 真实 hex → VI 变量（渲染时被 _build_root_vars 替换成项目配色）──
# 依据全 PPT 出现的 6 主色 + 字色。近似色归并到最近的 VI 语义变量。
FILL_MAP = {
    "0C1B33": "var(--primary)",       # 深蓝主背板
    "1B3A5C": "var(--secondary)",     # 钢蓝次背板
    "B87333": "var(--accent)",        # 铜强调
    "F0EDE8": "var(--card_bg)",       # 奶油卡片
    "5C1A1A": "var(--semantic-negative)",  # 暗红=反例
    "4CAF50": "var(--semantic-positive)",  # 绿=正例
    "FF9999": "var(--semantic-negative)",  # 浅红→反例系
}
TEXT_MAP = {
    "FFFFFF": "#ffffff",              # 白字（唯一合法硬编码）
    "B87333": "var(--accent)",        # 铜字
    "D4A76A": "var(--accent)",        # 浅铜→accent
    "0C1B33": "var(--primary)",
    "1B3A5C": "var(--secondary)",
    "5C1A1A": "var(--semantic-negative)",
    "8B8C89": "rgba(var(--text-rgb),0.55)",  # 灰字→半透明text
    "8C8C89": "rgba(var(--text-rgb),0.55)",
    "2C1810": "var(--text)",
}

def pct(v, tot): return round(v/tot*100, 2) if v is not None else 0.0

def fill_hex(sh):
    try:
        f = sh.fill
        if f.type is not None and f.fore_color and f.fore_color.type is not None:
            return str(f.fore_color.rgb).upper()
    except Exception:
        pass
    return ""

def font_hex(sh):
    if not sh.has_text_frame:
        return ""
    for p in sh.text_frame.paragraphs:
        for r in p.runs:
            try:
                if r.font.color and r.font.color.type is not None and r.font.color.rgb:
                    return str(r.font.color.rgb).upper()
            except Exception:
                pass
    return ""

def line_hex(sh):
    """描边颜色（分隔线/边框）。返回 (hex, width_pt) 或 ("", 0)。"""
    try:
        ln = sh.line
        w = ln.width.pt if ln.width else 0
        if ln.color is not None and ln.color.type is not None and ln.color.rgb:
            return str(ln.color.rgb).upper(), w
    except Exception:
        pass
    return "", 0

def max_fs(sh):
    if not sh.has_text_frame:
        return None
    s = [round(r.font.size.pt, 1) for p in sh.text_frame.paragraphs for r in p.runs if r.font.size]
    return max(s) if s else None

def text_of(sh):
    return sh.text_frame.text.strip() if sh.has_text_frame else ""

def map_fill(hexc):
    if not hexc:
        return None
    if hexc in ("FFFFFF", "FFF"):
        return "#ffffff"
    return FILL_MAP.get(hexc, "var(--card_bg)")  # 未知填色归并到卡片色（不硬编码）

def map_text_color(hexc):
    if not hexc:
        return "var(--text)"
    return TEXT_MAP.get(hexc, "var(--text)")

# ── 通用角色推断（行业无关）──
def infer_role(L, T, W, H, fs, n):
    if T < 9 and W > 60 and fs and fs >= 18: return "page_title"
    if T < 9 and W < 12 and n <= 4:          return "page_number"
    if T > 92:                               return "footnote"
    if fs and fs >= 48:                      return "hero_numeral" if n <= 12 else "hero_word"
    if n <= 3 and fs and 20 <= fs < 48:      return "item_index"
    if fs and fs >= 22:                      return "section_title"
    if fs and fs >= 16:                      return "item_title" if n <= 12 else "lead_text"
    if fs and fs >= 14:                      return "item_subtitle" if n <= 8 else "body_text"
    if fs and fs < 14 and n > 20:            return "body_text"
    if fs and fs < 14:                       return "caption"
    return "text"

def hardcap(W, H, fs, lh=1.55):
    if not fs: fs = 14
    w = W/100*CANVAS_W - 20; h = H/100*CANVAS_H - 10
    per = max(1, int(w // fs)); lines = max(1, int(h // (fs*lh)))
    return per*lines

def page_type_label(pi, shapes_meta, npages):
    fss = [m["fs"] for m in shapes_meta if m["fs"]]
    joined = " ".join(m["ex"] for m in shapes_meta)
    has_table = any(m["kind"] == "TABLE" for m in shapes_meta)
    if pi == 1: return "cover"
    if "目录" in joined or "CONTENTS" in joined.upper(): return "toc"
    if any(f and f >= 60 for f in fss) and len(shapes_meta) <= 8 and "CHAPTER" in joined.upper(): return "section"
    if has_table: return "table"
    if pi == npages: return "closing"
    ncards = sum(1 for m in shapes_meta if m["fill"] and m["H"] > 25)
    if ncards >= 4: return "grid_or_fourcol"
    return "content"

frameset = []
slides = list(prs.slides)
npages = len(slides)
for pi, slide in enumerate(slides, 1):
    shapes_meta = []
    for idx, sh in enumerate(slide.shapes):
        kind = str(sh.shape_type).split()[0] if sh.shape_type else "?"
        L, T, W, H = pct(sh.left, SW), pct(sh.top, SH), pct(sh.width, SW), pct(sh.height, SH)
        hexc = fill_hex(sh); fcol = font_hex(sh); fs = max_fs(sh); txt = text_of(sh)
        lcol, lw = line_hex(sh)
        # 分隔线：零宽或零高、有描边、无填充无文字（如对比带中间竖线）
        is_divider = (not txt and not hexc and lcol and (W < 0.5 or H < 0.5))
        if not txt and not hexc and not is_divider and kind != "TABLE" and kind != "PICTURE":
            continue
        shapes_meta.append({"z": idx, "kind": kind, "L": L, "T": T, "W": W, "H": H,
                            "fill": hexc, "fcol": fcol, "fs": fs, "n": len(txt),
                            "line": lcol, "line_w": lw, "is_divider": is_divider,
                            "ex": txt, "ex_short": txt[:40]})
    ptype = page_type_label(pi, shapes_meta, npages)
    containers = []
    for m in shapes_meta:
        if m["kind"] == "PICTURE":
            role = "image"; comfort = hcap = 0
        elif m["kind"] == "TABLE":
            role = "data_table"; comfort = hcap = 0
        elif m.get("is_divider"):
            role = "divider"; comfort = hcap = 0
        elif m["n"] == 0:
            role = "panel"; comfort = hcap = 0
        else:
            role = infer_role(m["L"], m["T"], m["W"], m["H"], m["fs"], m["n"])
            comfort = m["n"]; hcap = hardcap(m["W"], m["H"], m["fs"])
            if role in ("item_index", "page_number") or hcap < comfort:
                hcap = max(hcap, comfort)
        containers.append({
            "z": m["z"],
            "role": role,
            "kind": m["kind"],
            "geom": {"L": m["L"], "T": m["T"], "W": m["W"], "H": m["H"]},
            "fs": m["fs"],
            "fill_hex": m["fill"] or None,
            "fill_var": map_fill(m["fill"]) if m["fill"] else None,
            "text_hex": m["fcol"] or None,
            "text_var": map_text_color(m["fcol"]) if m["n"] else None,
            "line_hex": m.get("line") or None,
            "line_var": map_text_color(m["line"]) if m.get("line") else None,
            "line_w": m.get("line_w", 0),
            "chars": {"comfort": comfort, "hardcap": hcap},
            "example": m["ex"] if m["n"] else None,
        })
    containers.sort(key=lambda c: c["z"])
    panels = [c for c in containers if c["fill_var"] and c["geom"]["H"] > 25 and c["role"] == "panel"]
    frameset.append({
        "frame_id": f"{ptype}_p{pi:02d}",
        "source_page": pi,
        "page_type": ptype,
        "container_count": len(containers),
        "repeat_panels": len(panels),
        "containers": containers,
    })

(OUT_DIR/"frameset_abalone.json").write_text(
    json.dumps({"source": "鲍鱼一品煲SOP", "canvas": [CANVAS_W, CANVAS_H],
                "fill_map": FILL_MAP, "text_map": TEXT_MAP,
                "frame_count": len(frameset), "frames": frameset},
               ensure_ascii=False, indent=2), encoding="utf-8")

print(f"✅ 提取完成：{len(frameset)} 帧 → {OUT_DIR/'frameset_abalone.json'}")
for fr in frameset:
    print(f"  {fr['frame_id']:22} 页型={fr['page_type']:16} 容器={fr['container_count']:>2}")
