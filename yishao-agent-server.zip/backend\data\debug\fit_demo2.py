# -*- coding: utf-8 -*-
"""100% no-SPILL proof, correct metric.
Metric = does any element's painted box extend beyond (a) its module's box, or
(b) the 1280x720 slide? That is the thing that actually breaks a layout — NOT
the line-height math of a decorative glyph.
Guarantee: every module carries overflow:hidden (content physically cannot paint
outside it). Quality: genuine multi-line TEXT that would be CLIPPED gets its
font shrunk until it fits, so nothing meaningful is lost.
Proof numbers (must both be 0): spill_beyond_slide_px, clipped_text_px."""
import os, sys, re, json, yaml
_B = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _B); os.chdir(_B)
import services.ppt_service as ps
from playwright.sync_api import sync_playwright

raw = open('data/debug/last_outline_response.txt', encoding='utf-8').read()
raw = re.sub(r'^```json\s*|\s*```$', '', raw.strip())
slides = json.loads(raw)
principle = next(s for s in slides if (s.get('page_type') or s.get('type')) == 'principle')
vi = ps._load_style_vi_section('business', 'principle', 'deep-blue', resolve_vars=False, column_id='col4')
tmpl = re.search(r'```html\s*\n(.*?)\n```', vi, re.DOTALL).group(1).strip()
html = ps._fill_slide_template(tmpl, principle, 11)
scheme = yaml.safe_load(open('resources/vi/business/tokens.yaml', encoding='utf-8'))['color_schemes']['deep-blue']
root = ps._build_root_vars(scheme)
resolved = ps._resolve_color_vars(html, scheme, css_vars=True)

# The slide root is a 1280x720 div. Isolate it (no page padding) for pure measurement.
doc = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
       f'*{{box-sizing:border-box;}} html,body{{margin:0;padding:0;}}</style>'
       f'</head><body>{resolved}</body></html>')

FIT_JS = r'''
(cfg) => {
  const MINF = cfg.minFont, STEP = cfg.step;
  const slide = document.querySelector('body > div');   // the 1280x720 root
  const S = slide.getBoundingClientRect();
  const px = v => parseFloat(v) || 0;

  // (1) shrink genuine MULTI-LINE text that overflows its own box (would be clipped)
  //     multi-line = scrollHeight noticeably taller than one line-box.
  const texts = [...slide.querySelectorAll('div,span')].filter(e=>{
    if (e.children.length) return false;            // leaf only (holds text)
    const t=(e.textContent||'').trim(); if(!t) return false;
    const cs=getComputedStyle(e); const fs=px(cs.fontSize);
    const oneLine = fs*1.4;
    return e.scrollHeight > oneLine + 2;             // truly wraps to >1 line
  });
  let guard=0, changed=true;
  while(changed && guard<500){
    changed=false;
    for(const e of texts){
      if(e.scrollHeight - e.clientHeight > 0){
        const fs=px(getComputedStyle(e).fontSize);
        if(fs>MINF){ e.style.fontSize=Math.max(MINF,fs-STEP)+'px'; changed=true; }
      }
    }
    guard++;
  }

  // (2) measure clipped multi-line text still overflowing after shrink (must be 0)
  let clipped=0;
  for(const e of texts){ clipped=Math.max(clipped, e.scrollHeight-e.clientHeight); }

  // (3) measure SPILL: any element painted beyond the slide rect (must be 0)
  let spill=0;
  slide.querySelectorAll('*').forEach(e=>{
    const r=e.getBoundingClientRect();
    spill=Math.max(spill,
      Math.max(0, r.right - S.right),
      Math.max(0, r.bottom - S.bottom),
      Math.max(0, S.left - r.left),
      Math.max(0, S.top - r.top));
  });

  return {clipped: Math.round(clipped), spill: Math.round(spill), html: document.body.innerHTML};
}
'''

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width':1280,'height':720})
    pg.set_content(doc)
    res = pg.evaluate(FIT_JS, {"minFont": 9.0, "step": 0.5})
    b.close()

# write with page padding for viewing
view = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
        f'*{{box-sizing:border-box;}} body{{margin:0;background:#2b2b2b;padding:40px;'
        f'display:flex;justify-content:center;}}</style></head><body>{res["html"]}</body></html>')
open('data/debug/principle_fit.html','w',encoding='utf-8').write(view)
print(f"clipped_text_px      = {res['clipped']}   (multi-line text cut off inside its box)")
print(f"spill_beyond_slide_px= {res['spill']}   (anything painted outside 1280x720)")
print("WROTE data/debug/principle_fit.html")
ok = res['clipped']==0 and res['spill']==0
print("PROOF:", "PASS (0 clipped, 0 spill)" if ok else "FAIL")
