# -*- coding: utf-8 -*-
import json
from collections import defaultdict

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)
def flat(shapes):
    out=[]
    for s in shapes:
        out.append(s)
        if "group" in s: out.extend(flat(s["group"]))
    return out
def area(s): return (s.get("w") or 0)*(s.get("h") or 0)
CARD_FILLS={"F1F5F9","E2E8F0","ECEFF1","F8FAFC","FEF3C7","FFF7ED","FEF2F2","F0FDF4","FDE68A","FCE7F3","FFFFFF","E0F2FE","E0F7FA","C8E6C9","F9F3D9","F9E5A3","FEF9C3","1E293B","EFF6FF"}
NAVY={"0F172A","1E293B","334155","475569","455A64","64748B","1B3A5C"}
AMBER={"B45309","D97706","F59E0B","92400E","FCD34D","F0BC6E","D99E3E"}

def assign(deck, sl):
    fs=flat(sl["shapes"]); page=sl["page"]
    npic=sum(1 for s in fs if s["kind"]=="PICTURE")
    ntab=sum(1 for s in fs if s["kind"]=="TABLE")
    mf=max((max(t["sizes"]) for s in fs if (t:=s.get("txt")) and t["sizes"]),default=0)
    alltxt=" ".join(t["text"] for s in fs if (t:=s.get("txt")) and t["chars"]>0)
    nchars=sum(t["chars"] for s in fs if (t:=s.get("txt")))
    if page==1: return "C-COVER"
    if npic>=1 and any((s.get("h") or 0)>55 and (s.get("w") or 0)>90 for s in fs) and ("方法论" in alltxt or "Methodology" in alltxt or "交响" in alltxt or "掌握一门" in alltxt):
        return "C-BACKCOVER"
    if "CONTENTS" in alltxt: return "C-TOC"
    if mf>=120: return "C-SECTION"
    # closing: sparse page, big title 40-48, methodology text, no cards/table
    ncards_big=len([s for s in fs if s.get("fill") and area(s)>=120 and (s.get("h") or 0)>15])
    if mf>=40 and ntab==0 and ncards_big<=1 and ("方法论" in alltxt or "一道菜" in alltxt or "methodology" in alltxt.lower()):
        return "C-CLOSING"
    big_tab=[s for s in fs if s["kind"]=="TABLE" and (s.get("h") or 0)>40]
    if big_tab and ncards_big<=2:
        return "H2-TABLE"
    arrows=sum(1 for s in fs if (t:=s.get("txt")) and t["text"] in ("否→","是→")) + alltxt.count("→")
    if "诊断树" in alltxt and arrows>=4:
        return "H9-DIAGTREE"
    fwbig=[s for s in fs if s.get("fill") in (NAVY|AMBER) and (s.get("w") or 0)>=85 and 18<(s.get("h") or 0)<26]
    if len(fwbig)>=3 and ("方法论" in alltxt or "升华" in alltxt or "思维" in alltxt or "精神" in alltxt):
        return "H11-SUMMARY3BAND"
    if "笔记" in alltxt:
        return "H10-CHEFNOTES"
    cards=[s for s in fs if s.get("fill") and area(s)>=120 and (s.get("w") or 0)<96 and (s.get("t") or 0)>3 and (s.get("h") or 0)>10]
    def colcount(hmin):
        main=[c for c in cards if (c.get("h") or 0)>hmin and 10<(c.get("t") or 0)<45]
        lefts=sorted(set(round(c.get("l") or 0) for c in main)); m=[]
        for l in lefts:
            if not m or l-m[-1]>6: m.append(l)
        return len(m), main
    ncol, maincards = colcount(25)
    conn=sum(1 for s in fs if s.get("fill") in AMBER and 1.3<(s.get("w") or 0)<4 and 1.3<(s.get("h") or 0)<4)
    pastel=[s for s in fs if s.get("fill") and s.get("fill") not in (NAVY|AMBER) and s.get("fill") in CARD_FILLS and 15<(s.get("w") or 0)<25 and 4<(s.get("h") or 0)<16]
    strip=[s for s in fs if s.get("fill") in (NAVY|AMBER|CARD_FILLS) and 10<(s.get("w") or 0)<25 and 6<(s.get("h") or 0)<15 and 13<(s.get("t") or 0)<30]
    if ("流程" in alltxt or "SOP" in alltxt) and (ncol>=4 or len(strip)>=4):
        return "H7-SOPFLOW"
    if ("色泽" in alltxt or "路径" in alltxt) and (len(pastel)>=3 or conn>=3):
        return "H6-TIMELINE"
    if ("技法" in alltxt) and (len(strip)>=4 or conn>=3):
        return "H8-TECHWORKFLOW"
    if npic>=1:
        return "H5-IMGCARDS"
    if ("食材" in alltxt or "档案" in alltxt or "核心食材" in alltxt) and ncol<3:
        return "H5-IMGCARDS"
    # step/technique detail: 2 top compare cards + stacked full-width science bands
    top2=[c for c in cards if (c.get("h") or 0)>12 and 12<(c.get("t") or 0)<35]
    bands_fw=[s for s in fs if s.get("fill") in (NAVY|CARD_FILLS) and (s.get("w") or 0)>=80 and 8<(s.get("h") or 0)<30 and (s.get("t") or 0)>30]
    if ("步骤" in alltxt or "技法" in alltxt) and len(top2)>=2 and len(bands_fw)>=1:
        return "H3-2COL"
    if ncol>=3:
        if any((c.get("h") or 0)>45 for c in maincards):
            return "H1-STEP3COL"
        return "H4-NCARD"
    if ncol==2:
        return "H3-2COL"
    if len(pastel)>=3 or conn>=3:
        return "H6-TIMELINE"
    if len(strip)>=4:
        return "H8-TECHWORKFLOW"
    # aroma/口感 matrix with asymmetric cards
    if ("香气" in alltxt or "口感" in alltxt) and ncards_big>=3:
        return "H4-NCARD"
    return "H-MIXED?"

amap=defaultdict(list)
for deck,d in ALL.items():
    for sl in d["slides"]:
        amap[assign(deck,sl)].append(f"{deck}p{sl['page']}")
print("=== FINAL v2 counts ===")
tot=0
order=["C-SECTION","H5-IMGCARDS","H1-STEP3COL","H2-TABLE","C-COVER","C-TOC","H6-TIMELINE","H4-NCARD","H8-TECHWORKFLOW","H7-SOPFLOW","H3-2COL","H10-CHEFNOTES","C-CLOSING","H9-DIAGTREE","C-BACKCOVER","H11-SUMMARY3BAND","H-MIXED?"]
for sk in order:
    if sk in amap:
        tot+=len(amap[sk]); print(f"  {sk}: {len(amap[sk])}")
for sk,pages in amap.items():
    if sk not in order:
        tot+=len(pages); print(f"  {sk}: {len(pages)}")
print("  TOTAL:", tot)
print("\n H-MIXED?:", amap.get("H-MIXED?",[]))
print("\n H3-2COL:", amap.get("H3-2COL",[]))
print("\n C-CLOSING:", amap.get("C-CLOSING",[]))
