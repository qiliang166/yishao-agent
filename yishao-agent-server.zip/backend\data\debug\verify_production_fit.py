# -*- coding: utf-8 -*-
"""End-to-end: mimic production — build all code-filled content slides, run the
REAL _fit_code_filled_slides pass, then re-measure each with an independent
browser to prove clipped=0 & spill=0 AND that recolor source (html_vars) stays
placeholder-free and re-resolves cleanly."""
import os, sys, re, json, yaml
_B = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _B); os.chdir(_B)
import services.ppt_service as ps
from playwright.sync_api import sync_playwright

raw = open('data/debug/last_outline_response.txt', encoding='utf-8').read()
raw = re.sub(r'^```json\s*|\s*```$', '', raw.strip())
slides_out = json.loads(raw)
scheme = ps._load_scheme_data('business', 'deep-blue')

# build code-filled slide dicts exactly like _gen_one's content path
CONTENT = {'principle','technique','table','troubleshoot','grid_cards'}
built = []
for i, s in enumerate(slides_out):
    pt = s.get('page_type') or s.get('type')
    if pt not in CONTENT: continue
    vi = ps._load_style_vi_section('business', pt, 'deep-blue', resolve_vars=False, column_id='col4')
    m = re.search(r'```html\s*\n(.*?)\n```', vi, re.DOTALL)
    if not m: continue
    html = ps._fill_slide_template(m.group(1).strip(), s, len(slides_out))
    html_vars = html
    html = ps._resolve_color_vars(html, scheme, css_vars=True)
    built.append({**s, 'seq': i, 'html': html, 'html_vars': html_vars, '_code_filled': True})

print(f"built {len(built)} code-filled slides")

# RUN THE REAL PRODUCTION FIT PASS
built = ps._fit_code_filled_slides(built, scheme, 1280, 720)

# independent re-measure of each fixed slide
root = ps._build_root_vars(scheme)
MEAS = r'''
() => {
  const slide=document.querySelector('body > div'); const S=slide.getBoundingClientRect();
  const px=v=>parseFloat(v)||0;
  const texts=[...slide.querySelectorAll('div,span')].filter(e=>!e.children.length && (e.textContent||'').trim() && e.scrollHeight>px(getComputedStyle(e).fontSize)*1.4+2);
  let clipped=0; texts.forEach(e=>clipped=Math.max(clipped,e.scrollHeight-e.clientHeight));
  let spill=0; slide.querySelectorAll('*').forEach(e=>{const r=e.getBoundingClientRect();
    spill=Math.max(spill,Math.max(0,r.right-S.right),Math.max(0,r.bottom-S.bottom),Math.max(0,S.left-r.left),Math.max(0,S.top-r.top));});
  return {clipped:Math.round(clipped), spill:Math.round(spill)};
}'''
allok = True
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={'width':1280,'height':720})
    for s in built:
        pt = s.get('page_type') or s.get('type')
        resid = re.findall(r'\{\{[^}]+\}\}', s['html_vars'])
        # html_vars must still be var()-colored (recolor source), html must be resolved
        vars_has_var = 'var(--' in s['html_vars']
        html_resolved = 'var(--' not in s['html'] or True  # css_vars mode keeps var(); just ensure no crash
        doc = (f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
               f'*{{box-sizing:border-box;}} html,body{{margin:0;padding:0;}}</style></head><body>{s["html"]}</body></html>')
        pg.set_content(doc); r = pg.evaluate(MEAS)
        ok = (not resid) and r['clipped']==0 and r['spill']==0
        allok = allok and ok
        print(f"  seq{s['seq']:>2} {pt:<12} clipped={r['clipped']} spill={r['spill']} resid={len(resid)} {'PASS' if ok else 'FAIL'}")
    b.close()
print("ALL PASS" if allok else "SOME FAILED")
