# -*- coding: utf-8 -*-
"""
数据驱动框架渲染器：读 frameset JSON 的真实容器几何 → 自动生成 HTML。
几何(L/T/W/H)、字号、层级、配色 100% 来自 JSON —— 本文件里没有一个手写坐标。
内容由 content 字典按角色注入（新项目内容填进 PPT 真实骨架）。

用法：render_frame(frame_dict, content_dict) -> html 字符串（用 var(--x) 配色）
"""
import io, sys, json, re
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
DEBUG = Path(__file__).resolve().parent


def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


# ── 每个角色 → 排版属性（字重/行高/对齐/垂直定位）。纯样式，不含几何数字 ──
ROLE_STYLE = {
    "page_title":  {"weight": 800, "lh": 1.2,  "align": "left",   "valign": "center"},
    "page_number": {"weight": 700, "lh": 1.0,  "align": "right",  "valign": "center"},
    "hero_numeral":{"weight": 900, "lh": 0.9,  "align": "left",   "valign": "top"},
    "hero_word":   {"weight": 900, "lh": 1.0,  "align": "left",   "valign": "top"},
    "item_index":  {"weight": 900, "lh": 1.0,  "align": "left",   "valign": "top"},
    "section_title":{"weight": 800, "lh": 1.2, "align": "left",   "valign": "center"},
    "item_title":  {"weight": 800, "lh": 1.2,  "align": "left",   "valign": "center"},
    "lead_text":   {"weight": 800, "lh": 1.3,  "align": "left",   "valign": "center"},
    "item_subtitle":{"weight": 700, "lh": 1.3, "align": "left",   "valign": "center"},
    "caption":     {"weight": 700, "lh": 1.35, "align": "left",   "valign": "center"},
    "body_text":   {"weight": 400, "lh": 1.55, "align": "left",   "valign": "top"},
    "footnote":    {"weight": 400, "lh": 1.4,  "align": "left",   "valign": "center"},
    "text":        {"weight": 400, "lh": 1.5,  "align": "left",   "valign": "top"},
}


def _geom_style(g):
    """绝对定位样式 —— 数字全部来自 JSON 的 g（L/T/W/H），本函数不写死任何坐标。"""
    return (f"position:absolute;left:{g['L']}%;top:{g['T']}%;"
            f"width:{g['W']}%;height:{g['H']}%;box-sizing:border-box;overflow:hidden;")


def render_frame(frame, content):
    """遍历容器（按 z 升序），每个容器用真实几何生成一个绝对定位 div。"""
    parts = []
    for c in sorted(frame["containers"], key=lambda x: x["z"]):
        g = c["geom"]
        role = c["role"]
        base = _geom_style(g)

        # ── 背板/图片/表格 ──
        if role == "panel":
            bg = c["fill_var"] or "transparent"
            parts.append(f'<div style="{base}background:{bg};border-radius:8px;"></div>')
            continue
        if role == "divider":
            col = c.get("line_var") or "rgba(var(--text-rgb),0.2)"
            w = max(1, round(c.get("line_w", 1) or 1))
            # 零宽=竖线（用左边框），零高=横线（用上边框）
            if g["W"] < g["H"]:
                parts.append(f'<div style="{base}border-left:{w}px solid {col};"></div>')
            else:
                parts.append(f'<div style="{base}border-top:{w}px solid {col};"></div>')
            continue
        if c["kind"] == "PICTURE":
            parts.append(f'<div style="{base}background:rgba(var(--text-rgb),0.06);'
                         f'border:1px dashed rgba(var(--text-rgb),0.25);border-radius:8px;"></div>')
            continue
        if c["kind"] == "TABLE":
            parts.append(f'<div style="{base}background:var(--card_bg);border-radius:8px;"></div>')
            continue

        # ── 文字容器：字号来自 JSON，字色来自 JSON 映射变量 ──
        fs = c["fs"] or 14
        color = c["text_var"] or "var(--text)"
        st = ROLE_STYLE.get(role, ROLE_STYLE["text"])
        # 内容：content 字典按 (role, 出现序) 提供；缺省回退到原文 example
        key = c.get("_content_key")
        txt = content.get(key) if key and key in content else (c.get("example") or "")
        flex = ("display:flex;flex-direction:column;"
                + ("justify-content:center;" if st["valign"] == "center" else "justify-content:flex-start;"))
        parts.append(
            f'<div style="{base}{flex}font-size:{fs}px;font-weight:{st["weight"]};'
            f'line-height:{st["lh"]};color:{color};text-align:{st["align"]};'
            f'white-space:pre-line;">{esc(txt)}</div>'
        )

    inner = "\n  ".join(parts)
    return (f'<div style="position:relative;width:1280px;height:720px;overflow:hidden;'
            f'background:var(--background);font-family:\'DM Sans\',Inter,'
            f'\'PingFang SC\',\'Microsoft YaHei\',sans-serif;">\n  {inner}\n</div>')


def assign_content_keys(frame):
    """给每个文字容器打 _content_key（role + 同role出现序），供 content 字典寻址。"""
    seen = {}
    for c in sorted(frame["containers"], key=lambda x: x["z"]):
        if c["role"] in ("panel", "divider") or c["kind"] in ("PICTURE", "TABLE"):
            continue
        i = seen.get(c["role"], 0)
        c["_content_key"] = f"{c['role']}#{i}"
        seen[c["role"]] = i + 1
    return frame


if __name__ == "__main__":
    # 加载真实 page7 框架
    d = json.load(open(DEBUG / "frameset_abalone.json", encoding="utf-8"))
    frame = [f for f in d["frames"] if f["source_page"] == 7][0]
    assign_content_keys(frame)

    # 打印每个文字容器的寻址 key（方便填内容）
    print("page7 文字容器寻址表：")
    for c in sorted(frame["containers"], key=lambda x: x["z"]):
        if c.get("_content_key"):
            print(f"  {c['_content_key']:16} fs={c['fs']} ex={(c['example'] or '')[:20]}")
