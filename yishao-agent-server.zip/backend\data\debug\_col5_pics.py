# -*- coding: utf-8 -*-
import json
from collections import Counter

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)

def flat(shapes):
    out = []
    for s in shapes:
        out.append(s)
        if "group" in s:
            out.extend(flat(s["group"]))
    return out

print("=== PICTURE locations ===")
for deck, d in ALL.items():
    for sl in d["slides"]:
        pics = [s for s in flat(sl["shapes"]) if s["kind"] == "PICTURE"]
        for p in pics:
            print(f"{deck} p{sl['page']}: L{p['l']} T{p['t']} W{p['w']} H{p['h']}")

print("\n=== TABLE locations ===")
for deck, d in ALL.items():
    for sl in d["slides"]:
        tabs = [s for s in flat(sl["shapes"]) if s["kind"] == "TABLE"]
        for t in tabs:
            print(f"{deck} p{sl['page']}: TABLE L{t['l']} T{t['t']} W{t['w']} H{t['h']}")
