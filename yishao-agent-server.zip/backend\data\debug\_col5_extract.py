# -*- coding: utf-8 -*-
import json, os
from pptx import Presentation

BASE = r"D:\智绘食谱\酒店菜品\PPT模版"
# Handbook / courseware files only (exclude any filename containing 'SOP')
FILES = {
    "花雕蒸膏蟹":   "专业厨房研习手册：花雕蒸膏蟹.pptx",
    "古厨麻香鸡":   "古厨麻香鸡（脆皮麻香鸡）菜肴研习手册.pptx",
    "土豆红焖牛腩": "土豆红焖牛腩 · 菜肴研习手册.pptx",
    "潮汕砂锅粥":   "潮汕海鲜砂锅粥 · 菜肴研习手册.pptx",
    "砂锅焗鱼头":   "砂锅焗鱼头技法的术与道 (1).pptx",
    "胡椒猪肚鸡":   "胡椒猪肚鸡 · 菜肴研习手册.pptx",
    "红葱头蒸鸡":   "菜肴研习手册：红葱头蒸鸡.pptx",
    "萝卜焖牛腩01": "萝卜焖牛腩 · 菜肴研习手册01.pptx",
    "萝卜焖牛腩1":  "萝卜焖牛腩 · 菜肴研习手册1.pptx",
    "金沙焗虾":     "金沙黄金焗虾 · 教学课件.pptx",
    "鲍鱼一品煲":   "鲍鱼一品煲 · 研习手册.pptx",
    "鹅肝蒸水蛋":   "鹅肝虾仁蒸水蛋 · 菜肴研习手册.pptx",
}

SW = SH = None

def shp_kind(shape):
    try:
        return str(shape.shape_type).split()[0] if shape.shape_type else "NONE"
    except Exception:
        return "UNK"

def fill_hex(shape):
    try:
        f = shape.fill
        if f.type == 1:
            return str(f.fore_color.rgb)
    except Exception:
        pass
    return None

def text_info(shape):
    if not shape.has_text_frame:
        return None
    txt = shape.text_frame.text or ""
    sizes, bolds, colors = [], [], []
    for p in shape.text_frame.paragraphs:
        for r in p.runs:
            if r.font.size is not None:
                sizes.append(int(r.font.size.pt))
            if r.font.bold:
                bolds.append(True)
            try:
                if r.font.color and r.font.color.type is not None:
                    colors.append(str(r.font.color.rgb))
            except Exception:
                pass
    return {
        "text": txt.replace("\n", " \\n ")[:80],
        "chars": len(txt),
        "nlines": (txt.count("\n") + 1) if txt else 0,
        "sizes": sorted(set(sizes)),
        "bold": bool(bolds),
        "font_colors": sorted(set(colors))[:3],
    }

def walk(shapes, out):
    for sh in shapes:
        entry = {"kind": shp_kind(sh), "name": sh.name}
        try:
            entry["l"] = round(sh.left / SW * 100, 1) if sh.left is not None else None
            entry["t"] = round(sh.top / SH * 100, 1) if sh.top is not None else None
            entry["w"] = round(sh.width / SW * 100, 1) if sh.width is not None else None
            entry["h"] = round(sh.height / SH * 100, 1) if sh.height is not None else None
        except Exception:
            entry["l"] = entry["t"] = entry["w"] = entry["h"] = None
        fh = fill_hex(sh)
        if fh:
            entry["fill"] = fh
        ti = text_info(sh)
        if ti:
            entry["txt"] = ti
        if sh.shape_type is not None and str(sh.shape_type).startswith("GROUP"):
            entry["group"] = []
            walk(sh.shapes, entry["group"])
        out.append(entry)

ALL = {}
for deck, fn in FILES.items():
    path = os.path.join(BASE, fn)
    prs = Presentation(path)
    SW = prs.slide_width
    SH = prs.slide_height
    dims = (round(SW / 914400, 2), round(SH / 914400, 2))
    deck_slides = []
    for i, slide in enumerate(prs.slides, 1):
        shapes = []
        walk(slide.shapes, shapes)
        deck_slides.append({"page": i, "shapes": shapes})
    ALL[deck] = {"file": fn, "dims_in": dims, "nslides": len(deck_slides), "slides": deck_slides}
    print(f"{deck}: {len(deck_slides)} slides, dims={dims}")

out_path = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(ALL, f, ensure_ascii=False, indent=1)
print("WROTE col5_skeleton_raw.json", os.path.getsize(out_path), "bytes")
