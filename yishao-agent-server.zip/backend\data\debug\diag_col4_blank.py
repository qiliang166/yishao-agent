# -*- coding: utf-8 -*-
"""诊断：col4 index.html 每页可见文字量，定位空白页。"""
import io, sys
from pathlib import Path

BK = Path(__file__).resolve().parents[2]
IDX = BK.parent / "data" / "output" / "鲍鱼一品煲" / "鲍鱼一品煲_col4" / "index.html"
w = io.open(1, "w", encoding="utf-8", closefd=False)

from playwright.sync_api import sync_playwright

JS = r"""
() => {
  const out=[];
  // 每个 slide 是 body 下的顶层容器；尽量宽松抓取
  const slides=[...document.querySelectorAll('body *')].filter(e=>{
    const r=e.getBoundingClientRect();
    return r.width>=1000 && r.height>=600 && r.height<900;
  });
  const seen=new Set();
  slides.forEach((s,i)=>{
    const txt=(s.innerText||'').replace(/\s+/g,'').trim();
    const key=txt.slice(0,20)+':'+Math.round(s.getBoundingClientRect().top);
    if(seen.has(key)) return; seen.add(key);
    out.push({idx:out.length+1, chars:txt.length, sample:(s.innerText||'').trim().slice(0,40)});
  });
  return out;
}
"""

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(IDX.as_uri())
    pg.wait_for_timeout(800)
    res = pg.evaluate(JS)
    b.close()

w.write(f"index.html: {IDX}\n检测到 {len(res)} 个页面块\n" + "=" * 56 + "\n")
for r in res:
    flag = "  <-- 空/极少" if r["chars"] < 15 else ""
    w.write(f"  #{r['idx']:2} 文字数={r['chars']:4}  {r['sample']!r}{flag}\n")
w.flush()
