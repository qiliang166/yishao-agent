# -*- coding: utf-8 -*-
"""
验证「大模型读框架集，按内容选框架」——最小可运行版
- 框架集 = 从真实 PPT 提取的 2 个 principle 类框架（都带精确坐标/字号/字数预算）：
    B4  单条正反对比（page4）：容量 items=1（左图+右卡+蓝正带+红错带+参数带）
    B7  四栏并列（page7）    ：容量 items=3~4（每栏 序号+标题+副标+正文，底部对比带）
- 选择器 = 按内容 key_points 条数选：4条→B7、1条→B4
- 内容 = 真实鲍鱼 principle 4 条（涨/脆/合/时之道）→ 应自动选到 B7 真实框架
- 配色只走 chinese-red VI 变量；Playwright 实测零溢出
"""
import io, sys, re
from pathlib import Path
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
DEBUG = Path(__file__).resolve().parent

VI = {"--primary":"#c41e3a","--secondary":"#8b1a2b","--accent":"#d4a017",
      "--background":"#fff8f0","--text":"#2c1810","--card_bg":"#fef5e6",
      "--negative":"#c0392b","--positive":"#27ae60",
      "--chart-0":"#c41e3a","--chart-1":"#8b1a2b","--chart-2":"#d4a017",
      "--chart-3":"#b33a2e","--chart-4":"#e8c547",
      "--text-rgb":"44,24,16","--accent-rgb":"212,160,23"}

HEADING="道 · 烹饪理念与原理"; THEME_CHAR="道"; THEME_SUB="烹饪理念与原理"
PAGE_NUM,TOTAL=3,11
KEY_POINTS=[
 "涨之道：花胶先蒸后50℃浸8h，还原弹滑；沸水直涨则外融内硬",
 "脆之道：白醋焯水刻蚀表皮，210℃油温瞬间汽化膨起虎皮；低油温则干硬",
 "合之道：分而治之批量预制，最后砂煲鲍汁融合；一锅乱炖则老嫩不齐",
 "时之道：花菇6h冷水慢发保香，凤爪1h慢炖释胶，花胶煨20-30min控软弹",
]

def split_kp(kp):
    title,rest=(kp.split("：",1) if "：" in kp else ("",kp))
    correct,wrong=(rest.split("；",1) if "；" in rest else (rest,""))
    return title.strip(),correct.strip(),wrong.strip()

def esc(s): return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

# ── 框架集：每个框架 = 元数据(容量) + 渲染函数。坐标/字号 100% 来自真实 PPT ──
FRAMESET = {}
def frame(name, cap_min, cap_max, src):
    def deco(fn): FRAMESET[name]={"min":cap_min,"max":cap_max,"src":src,"render":fn}; return fn
    return deco

# ---- B7 四栏并列（真实 page7 坐标）：装 3~4 条 ----
@frame("principle_B7_fourcol", 3, 4, "page7 味之道")
def render_B7(kps):
    # 每栏坐标来自 page7：L 5.0/29.06/53.12/77.19, W 21.25(末栏17.81), T10 H47.22
    lefts=[5.0,29.06,53.12,77.19]; widths=[21.25,21.25,21.25,17.81]
    cols=[]
    for i,kp in enumerate(kps[:4]):
        title,correct,wrong=split_kp(kp)
        L,W=lefts[i],widths[i]; chart=f"var(--chart-{i%5})"
        cols.append(f"""
  <div style="position:absolute;left:{L}%;top:10%;width:{W}%;height:47.22%;box-sizing:border-box;background:{chart};border-radius:10px;overflow:hidden;">
    <div style="padding:14px 14px 10px;height:100%;box-sizing:border-box;display:flex;flex-direction:column;">
      <div style="font-size:28px;font-weight:900;color:rgba(255,255,255,0.85);line-height:1;">{i+1:02d}</div>
      <div style="font-size:18px;font-weight:800;color:#ffffff;margin-top:8px;">{esc(title)}</div>
      <div style="font-size:12px;color:var(--accent);font-weight:700;margin-top:4px;">正解</div>
      <div style="font-size:13px;color:rgba(255,255,255,0.92);line-height:1.5;margin-top:6px;overflow:hidden;">{esc(correct)}</div>
      <div style="margin-top:auto;background:rgba(0,0,0,0.18);border-radius:6px;padding:6px 8px;overflow:hidden;">
        <span style="font-size:11px;color:var(--accent);font-weight:800;">✕ 误</span>
        <span style="font-size:11.5px;color:rgba(255,255,255,0.85);line-height:1.45;"> {esc(wrong)}</span>
      </div>
    </div>
  </div>""")
    # 底部对比带（page7 T59.72 H27.78 奶油带）
    band=f"""
  <div style="position:absolute;left:5%;top:59.72%;width:90%;height:27.78%;box-sizing:border-box;background:var(--card_bg);border-radius:10px;overflow:hidden;display:flex;flex-direction:column;padding:14px 18px;">
    <div style="font-size:16px;font-weight:800;color:var(--secondary);margin-bottom:8px;">四维一体 vs 各自为政</div>
    <div style="flex:1;min-height:0;display:flex;gap:18px;">
      <div style="flex:1;font-size:13px;color:var(--text);line-height:1.6;overflow:hidden;"><b style="color:var(--positive);">✓ 本SOP：</b>涨定弹滑、脆立虎皮、合融百味、时守火候，四道各司其职，一味引百味。</div>
      <div style="width:1px;background:rgba(var(--text-rgb),0.15);"></div>
      <div style="flex:1;font-size:13px;color:var(--text);line-height:1.6;overflow:hidden;"><b style="color:var(--negative);">✕ 常见误：</b>沸水直涨、低温油炸、一锅乱炖、急发抢时，食材各自失格，全盘失层次。</div>
    </div>
  </div>"""
    return _wrap(cols+[band])

# ---- B4 单条正反（真实 page4 坐标）：装 1 条 ----
@frame("principle_B4_single", 1, 1, "page4 发之道")
def render_B4(kps):
    title,correct,wrong=split_kp(kps[0])
    body=f"""
  <div style="position:absolute;left:5%;top:10%;width:29.69%;height:38.89%;box-sizing:border-box;background:var(--primary);border-radius:10px;overflow:hidden;display:flex;flex-direction:column;justify-content:center;padding:20px;">
    <div style="font-size:56px;font-weight:900;color:var(--accent);line-height:0.9;">{esc(THEME_CHAR)}</div>
    <div style="font-size:16px;color:#ffffff;font-weight:700;margin-top:6px;">{esc(title)}</div>
  </div>
  <div style="position:absolute;left:36.25%;top:10%;width:58.75%;height:38.89%;box-sizing:border-box;background:var(--card_bg);border-radius:10px;overflow:hidden;">
    <div style="height:5px;background:var(--accent);"></div>
    <div style="padding:14px 18px;"><div style="font-size:18px;font-weight:800;color:var(--secondary);">{esc(title)}</div>
    <div style="font-size:15px;color:var(--text);line-height:1.6;margin-top:8px;">{esc(correct)}</div></div>
  </div>
  <div style="position:absolute;left:5%;top:51.67%;width:44.06%;height:19.44%;box-sizing:border-box;background:var(--primary);border-radius:8px;padding:12px 16px;overflow:hidden;">
    <div style="font-size:14px;font-weight:800;color:var(--accent);">✓ 正确操作结果</div>
    <div style="font-size:13px;color:#ffffff;line-height:1.55;margin-top:6px;">{esc(correct)}</div>
  </div>
  <div style="position:absolute;left:50.94%;top:51.67%;width:44.06%;height:19.44%;box-sizing:border-box;background:var(--negative);border-radius:8px;padding:12px 16px;overflow:hidden;">
    <div style="font-size:14px;font-weight:800;color:#ffffff;">✕ 错误操作后果</div>
    <div style="font-size:13px;color:rgba(255,255,255,0.92);line-height:1.55;margin-top:6px;">{esc(wrong)}</div>
  </div>
  <div style="position:absolute;left:5%;top:73.61%;width:90%;height:8.33%;box-sizing:border-box;background:var(--card_bg);border-radius:8px;border-left:5px solid var(--accent);display:flex;align-items:center;padding:0 18px;overflow:hidden;">
    <span style="font-size:13px;color:var(--text);">关键参数：{esc(correct)}</span>
  </div>"""
    return _wrap([body])

def _wrap(parts):
    head=f"""
  <div style="position:absolute;left:0;top:0;width:100%;height:7.22%;background:var(--primary);"></div>
  <div style="position:absolute;left:5%;top:1.39%;width:82%;height:4.44%;display:flex;align-items:center;gap:12px;box-sizing:border-box;">
    <span style="width:6px;height:26px;background:var(--accent);border-radius:1px;flex-shrink:0;"></span>
    <span style="font-size:22px;font-weight:800;color:#ffffff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">{esc(HEADING)}</span>
  </div>
  <div style="position:absolute;left:88%;top:1.39%;width:8%;height:4.44%;display:flex;align-items:center;justify-content:flex-end;box-sizing:border-box;">
    <span style="font-size:13px;font-weight:700;color:var(--accent);">{PAGE_NUM:02d} / {TOTAL}</span>
  </div>
  <div style="position:absolute;left:5%;top:94.44%;width:60%;height:2.78%;display:flex;align-items:center;box-sizing:border-box;">
    <span style="font-size:12px;color:rgba(var(--text-rgb),0.55);">Source: 「鲍鱼一品煲」SOP · 道之四维</span>
  </div>"""
    return (f"""<div style="position:relative;width:1280px;height:720px;overflow:hidden;background:var(--background);font-family:'DM Sans',Inter,'PingFang SC','Microsoft YaHei',sans-serif;">{head}{''.join(parts)}
</div>""")

# ── 选择器：按内容条数从框架集选最贴的框架（这就是"读框架集选框架"）──
def select_frame(kps):
    n=len(kps)
    cands=[(name,f) for name,f in FRAMESET.items() if f["min"]<=n<=f["max"]]
    if not cands:  # 无完美匹配 → 选容量上限最接近的
        cands=sorted(FRAMESET.items(), key=lambda kv: abs(kv[1]["max"]-n))[:1]
    name,meta=cands[0]
    return name,meta

def resolve(hv):
    out=hv
    for k in ("--text-rgb","--accent-rgb"): out=out.replace(f"var({k})",VI[k])
    for k,v in VI.items():
        if k.endswith("-rgb"): continue
        out=out.replace(f"var({k})",v)
    return out

def measure(hr):
    from playwright.sync_api import sync_playwright
    page=f"<!doctype html><html><head><meta charset='utf-8'><style>*{{margin:0;padding:0;box-sizing:border-box}}</style></head><body>{hr}</body></html>"
    with sync_playwright() as p:
        b=p.chromium.launch(); pg=b.new_page(viewport={"width":1280,"height":720})
        pg.set_content(page,wait_until="networkidle")
        r=pg.evaluate("""()=>{const W=1280,H=720;let sp=0,cl=0;
          for(const el of document.querySelectorAll('body *')){const b=el.getBoundingClientRect();
            sp=Math.max(sp,Math.max(0,b.right-W),Math.max(0,b.bottom-H),Math.max(0,-b.left),Math.max(0,-b.top));
            if(el.children.length===0&&el.textContent.trim()){const fs=parseFloat(getComputedStyle(el).fontSize)||14;
              const oh=el.scrollHeight-el.clientHeight;if(oh>=fs*0.6)cl=Math.max(cl,oh);}}
          return{sp:Math.round(sp),cl:Math.round(cl)};}""")
        b.close()
    return r

def run(kps, tag, outfile):
    name,meta=select_frame(kps)
    hv=meta["render"](kps); hr=resolve(hv)
    resid=re.findall(r'\{\{[^}]+\}\}',hr)
    bad=[h for h in re.findall(r'#[0-9a-fA-F]{3,8}',hv) if h.lower() not in ('#ffffff','#fff')]
    m=measure(hr)
    (DEBUG/outfile).write_text(f"<!doctype html><meta charset=utf-8><body style=margin:0>{hr}",encoding='utf-8')
    print("="*66); print(f"【{tag}】内容 {len(kps)} 条")
    print(f"  框架集候选: {list(FRAMESET.keys())}")
    print(f"  → 选中框架: {name}  (容量{meta['min']}-{meta['max']}, 源自真实 {meta['src']})")
    print(f"  零溢出: spill={m['sp']} clip={m['cl']}   非白hex={len(bad)}   残留={len(resid)}")
    ok=(m['sp']==0 and m['cl']==0 and len(bad)==0 and len(resid)==0)
    print(f"  {'PASS ✅' if ok else 'FAIL ❌ '+str(bad[:3])}")
    print(f"  成品: {DEBUG/outfile}")
    return ok

if __name__=="__main__":
    a=run(KEY_POINTS, "4条数据→应选B7四栏", "frameset_principle_4.html")
    b=run(KEY_POINTS[:1], "1条数据→应选B4单条", "frameset_principle_1.html")
    sys.exit(0 if (a and b) else 1)
