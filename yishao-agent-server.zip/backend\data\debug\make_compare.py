# -*- coding: utf-8 -*-
"""
并排对比图：左=原 PPT page7（真实几何 + 原鲍鱼文字，由 JSON example 还原），
右=合成结果（同一真实几何 + 新填充内容，走生产管线）。证明框架 1:1。
两边都用真实提取几何，只是内容不同。
"""
import io, sys, json, re
from pathlib import Path
DEBUG = Path(__file__).resolve().parent
sys.path.insert(0, str(DEBUG))
sys.path.insert(0, str(DEBUG.parents[1]))

from frame_renderer import render_frame, assign_content_keys
from services.ppt_service import (
    _select_framework_template, _fill_slide_template, _resolve_color_vars,
    _load_style_vi_section, _load_scheme_data, _build_root_vars,
)

SCHEME = "chinese-red"
scheme = _load_scheme_data("business", SCHEME)
root = _build_root_vars(scheme)

# ── 左：原 PPT page7（空 content → 渲染器回退到 example = 原鲍鱼文字）──
d = json.load(open(DEBUG / "frameset_abalone.json", encoding="utf-8"))
frame = assign_content_keys([f for f in d["frames"] if f["source_page"] == 7][0])
left_html = _resolve_color_vars(render_frame(frame, {}), scheme, css_vars=True)

# ── 右：合成结果（真实数据走生产管线）──
res = Path(r"D:\YISHAOAGENT\data\output\鲍鱼一品煲\鲍鱼一品煲_col4\result.json")
dr = json.load(open(res, encoding="utf-8"))
slide = [s for s in dr["slide_plan"] if s.get("type") == "principle"][0]
total = len(dr["slide_plan"])
vi = _load_style_vi_section("business", "principle", SCHEME, resolve_vars=False,
                            column_id="col4", project_id="fcf32913a82b")
tmpl = _select_framework_template(vi, len(slide.get("key_points", [])))
right_html = _resolve_color_vars(_fill_slide_template(tmpl, slide, total), scheme, css_vars=True)

# ── 并排（缩到 640 宽，两块 + 标签）──
def wrap(label, inner):
    return (f"<div style='display:inline-block;vertical-align:top;margin:8px;'>"
            f"<div style='font:700 16px sans-serif;color:#222;margin:4px 0 8px;text-align:center'>{label}</div>"
            f"<div style='width:640px;height:360px;overflow:hidden;border:1px solid #ccc;'>"
            f"<div style='transform:scale(0.5);transform-origin:top left;'>{inner}</div></div></div>")

doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n"
       f"*{{margin:0;padding:0;box-sizing:border-box}}</style></head>"
       f"<body style='background:#f5f5f5;padding:12px;white-space:nowrap;'>"
       f"{wrap('① 原 PPT page7（真实几何 + 原文）', left_html)}"
       f"{wrap('② 合成结果（同几何 + 新内容 / chinese-red）', right_html)}"
       f"</body></html>")
out = DEBUG / "page7_compare.html"
out.write_text(doc, encoding="utf-8")

from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1360, "height": 440})
    pg.set_content(doc, wait_until="networkidle")
    pg.screenshot(path=str(DEBUG / "page7_compare.png"))
    b.close()

w = io.open(1, "w", encoding="utf-8", closefd=False)
w.write(f"并排对比图已生成 → {DEBUG / 'page7_compare.png'}\n")
w.write(f"HTML → {out}\n")
w.flush()
