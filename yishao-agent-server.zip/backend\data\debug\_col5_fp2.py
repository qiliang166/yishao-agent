# -*- coding: utf-8 -*-
import json, re
from collections import Counter, defaultdict

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)

CARD_FILLS = {"F1F5F9","E2E8F0","ECEFF1","F8FAFC","FEF3C7","FFF7ED","FEF2F2","F0FDF4","FDE68A","FCE7F3","FFFFFF","E0F2FE","E0F7FA","C8E6C9","F9F3D9","F9E5A3"}
NAVY = {"0F172A","1E293B","334155","475569","455A64","64748B","1B3A5C"}
AMBER = {"B45309","D97706","F59E0B","92400E","FCD34D","F0BC6E","D99E3E"}
RED = {"DC2626","EF4444","CB4335"}

def flat(shapes):
    out=[]
    for s in shapes:
        out.append(s)
        if "group" in s: out.extend(flat(s["group"]))
    return out
def area(s): return (s.get("w") or 0)*(s.get("h") or 0)

# section title = first big bold text at top (~T5.6, sz 28/32)
def title_of(fs):
    cands=[s for s in fs if (t:=s.get("txt")) and t["chars"]>2 and t["sizes"] and max(t["sizes"])>=26 and (s.get("t") or 0)<10 and (s.get("t") or 0)>3]
    if cands:
        cands.sort(key=lambda s:(s.get("t") or 0))
        return cands[0]["txt"]["text"]
    # cover/section big title
    big=[s for s in fs if (t:=s.get("txt")) and t["chars"]>1 and t["sizes"] and max(t["sizes"])>=40]
    if big: return big[0]["txt"]["text"]
    return ""

# capacity: collect body text blocks (sz 13-16, chars>30) per page column count context
rows=[]
for deck,d in ALL.items():
    for sl in d["slides"]:
        fs=flat(sl["shapes"])
        npic=sum(1 for s in fs if s["kind"]=="PICTURE")
        ntab=sum(1 for s in fs if s["kind"]=="TABLE")
        mf=0
        for s in fs:
            t=s.get("txt")
            if t and t["sizes"]: mf=max(mf,max(t["sizes"]))
        title=title_of(fs)
        # big cards
        cards=[s for s in fs if s.get("fill") and area(s)>=120 and (s.get("w") or 0)<96 and (s.get("t") or 0)>3 and (s.get("h") or 0)>12]
        # columns in main band (top 14-52)
        main=[c for c in cards if 12<(c.get("t") or 0)<40 and (c.get("h") or 0)>25]
        lefts=sorted(set(round(c.get("l") or 0) for c in main))
        merged=[]
        for l in lefts:
            if not merged or l-merged[-1]>6: merged.append(l)
        ncol=len(merged)
        # full-width bands
        bands=[s for s in fs if s.get("fill") and (s.get("w") or 0)>=80 and 3<(s.get("h") or 0)<14 and (s.get("t") or 0)>10]
        # arrow connectors (small amber squares between cards) or 否/是 text
        arrows=sum(1 for s in fs if (t:=s.get("txt")) and ("→" in t["text"] or t["text"] in ("否→","是→")))
        # small connector squares
        connsq=sum(1 for s in fs if s.get("fill") in AMBER and 1.5<(s.get("w") or 0)<4 and 1.5<(s.get("h") or 0)<4)
        # body char counts (medium text)
        bodies=[t["chars"] for s in fs if (t:=s.get("txt")) and t["sizes"] and 12<=max(t["sizes"])<=16 and t["chars"]>=25]
        rows.append(dict(deck=deck,page=sl["page"],npic=npic,ntab=ntab,mf=mf,title=title[:34],
                         ncards=len(cards),ncol=ncol,nbands=len(bands),arrows=arrows,connsq=connsq,
                         bodies=bodies,nsh=len(fs)))

# print all titles grouped for section-kind analysis
print("=== ALL PAGE TITLES (deck p# | title | ncol cards band pic tab arrow font) ===")
for r in rows:
    print(f"{r['deck'][:5]:5} p{r['page']:<2}| {r['title']:<34} | c{r['ncol']} k{r['ncards']} b{r['nbands']} p{r['npic']} t{r['ntab']} a{r['arrows']+r['connsq']} f{r['mf']}")

with open(r"D:\YISHAOAGENT\backend\data\debug\col5_fingerprints2.json","w",encoding="utf-8") as f:
    json.dump(rows,f,ensure_ascii=False,indent=1)
