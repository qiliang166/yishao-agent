# -*- coding: utf-8 -*-
import json
from collections import defaultdict
import statistics as st

RAW = r"D:\YISHAOAGENT\backend\data\debug\col5_skeleton_raw.json"
with open(RAW, encoding="utf-8") as f:
    ALL = json.load(f)

def flat(shapes):
    out=[]
    for s in shapes:
        out.append(s)
        if "group" in s: out.extend(flat(s["group"]))
    return out

# collect text shapes by (font-size, role-heuristic) buckets
def summ(name, arr):
    if not arr:
        print(f"  {name}: (none)")
        return
    arr=sorted(arr)
    print(f"  {name}: n={len(arr)} min={arr[0]} p25={arr[len(arr)//4]} med={st.median(arr):.0f} p75={arr[3*len(arr)//4]} max={arr[-1]}")

roles=defaultdict(list)
fontrole=defaultdict(set)
for deck,d in ALL.items():
    for sl in d["slides"]:
        fs=flat(sl["shapes"])
        for s in fs:
            t=s.get("txt")
            if not t or t["chars"]==0: continue
            sz=max(t["sizes"]) if t["sizes"] else 0
            l,tp,w,h=s.get("l") or 0,s.get("t") or 0,s.get("w") or 0,s.get("h") or 0
            ch=t["chars"]
            # section title
            if 3<tp<10 and sz>=26 and w>70:
                roles["section_title(sz28-32)"].append(ch)
            # card small label EN (sz11-12 upper)
            elif sz in (11,12) and ch<30 and tp>12:
                roles["card_label_EN(sz11-12)"].append(ch)
            # card heading (sz18-22)
            elif 18<=sz<=22 and ch<=20:
                roles["card_heading(sz18-22)"].append(ch)
            # big stat number
            elif sz>=36 and ch<=6:
                fontrole["bignum"].add(sz)
            # body text sz13-16 medium blocks
            elif 13<=sz<=16 and ch>=25:
                roles["card_body(sz13-16)"].append(ch)
            # insight band sz14-15 wide
            elif 14<=sz<=15 and w>=80 and ch>=30:
                roles["fullwidth_band(sz14-15)"].append(ch)

print("=== CAPACITY per role (char counts) ===")
for k in ["section_title(sz28-32)","card_heading(sz18-22)","card_label_EN(sz11-12)","card_body(sz13-16)","fullwidth_band(sz14-15)"]:
    summ(k, roles[k])

# 3-col step card body specifically (the OPERATION/SCIENCE/TRANSFER pattern): body in cols at t~21-25, w25-29
colbody=[]
for deck,d in ALL.items():
    for sl in d["slides"]:
        fs=flat(sl["shapes"])
        for s in fs:
            t=s.get("txt")
            if not t or t["chars"]==0: continue
            sz=max(t["sizes"]) if t["sizes"] else 0
            l,tp,w,h=s.get("l") or 0,s.get("t") or 0,s.get("w") or 0,s.get("h") or 0
            if 13<=sz<=14 and 24<=w<=30 and tp>18 and t["chars"]>=40 and h>15:
                colbody.append(t["chars"])
print("\n=== 3-col detail card body (sz13-14, w~25-29%) ===")
summ("col_detail_body", colbody)
