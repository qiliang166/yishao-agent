# -*- coding: utf-8 -*-
"""PROOF: technique page as a TRUE multi-module asymmetric composition.
Left = vertical process rail (all steps, compact). Right-top = spotlight of the
main cooking sequence broken into arrow-linked chips. Right-bottom = two detail
tiles (调味 / 要领). Bottom = key-parameter strip. Several modules of different
size/role — not a row of identical step cards.
Real abalone data, 13-color variables. Manual text-fit stands in for later LLM.
"""
import os, sys, yaml, re, html as H
_BACKEND = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _BACKEND); os.chdir(_BACKEND)
import services.ppt_service as ps

esc = H.escape
W, Hh = 1280, 720
FONT = "'DM Sans',Inter,'PingFang SC','Microsoft YaHei',sans-serif"

heading = "术 · 分步骤通用操作"
# real seq6 data, distilled into roles
rail = [  # left process rail: (no, name)
    ("01", "预处理"), ("02", "分段调味"), ("03", "工艺要点"), ("04", "主工序"), ("05", "装盘"),
]
# right-top spotlight: the main sequence (KP4) as arrow chips
main_seq = ["炸210℃至虎皮", "飞水去油", "香料汤中火炖1h", "加鲍鱼再15min", "花胶高汤煨20–30min"]
# right-bottom two detail tiles
tile_flavor = ("分段调味", "凤爪先抹生抽炸 → 香料汤炖底味 → 花胶高汤浸吸味，三段各司其味")
tile_key = ("工艺要领", "本菜不挂浆；生抽涂抹起美拉德褐变，高温爆皮自身成壳")
# preprocessing detail (KP1) as the left rail's expandable note under 01
prep = "凤爪醋焯抹生抽 · 鲍鱼盐搓去膜开水定 · 花胶蒸20min浸8h · 花菇冷水浸6h"
# bottom params
params = [("210℃", "炸制油温"), ("1h", "香料汤炖"), ("15min", "加鲍同炖"), ("20–30min", "花胶煨制")]

def box(l,t,w,h,style="",inner=""):
    return (f'<div style="position:absolute;left:{l:.2f}%;top:{t:.2f}%;width:{w:.2f}%;height:{h:.2f}%;'
            f'box-sizing:border-box;{style}">{inner}</div>')
CH=lambda i:"{{chart_%d}}"%(i%5)
P="{{primary}}";S="{{secondary}}";A="{{accent}}";CB="{{card_bg}}";T="{{text}}";BG="{{background}}";NEG="{{semantic_negative}}";GOLD="{{chart_3}}"

parts=[]
# header
parts.append(box(0,0,100,7.2,f"background:{P};"))
parts.append(box(5,1.4,78,4.4,"display:flex;align-items:center;gap:12px;",
    f'<span style="width:6px;height:26px;background:{A};border-radius:1px;"></span>'
    f'<span style="font-size:23px;font-weight:800;color:#fff;">{esc(heading)}</span>'))
parts.append(box(84,1.4,11,4.4,"display:flex;align-items:center;justify-content:flex-end;",
    f'<span style="font-size:14px;font-weight:700;color:{GOLD};">06 / 11</span>'))

# LEFT process rail (module 1) — vertical numbered timeline, compact
rail_items=[]
for i,(no,nm) in enumerate(rail):
    last = i==len(rail)-1
    connector = "" if last else '<div style="flex:1;width:2px;background:rgba(255,255,255,0.18);margin-top:2px;"></div>'
    pb = "0" if last else "16px"
    rail_items.append(
        f'<div style="display:flex;gap:12px;position:relative;padding-bottom:{pb};">'
        f'<div style="display:flex;flex-direction:column;align-items:center;">'
        f'<div style="width:34px;height:34px;border-radius:50%;background:{CH(i)};color:#fff;font-size:14px;'
        f'font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;z-index:2;">{no}</div>'
        f'{connector}'
        f'</div>'
        f'<div style="padding-top:6px;"><div style="font-size:15px;font-weight:700;color:#fff;">{esc(nm)}</div></div>'
        f'</div>')
parts.append(box(5,10,24,82,
    f"background:{P};border-radius:14px;overflow:hidden;box-shadow:0 8px 24px rgba(0,0,0,0.2);",
    f'<div style="position:absolute;top:0;left:0;right:0;height:5px;background:{A};"></div>'
    f'<div style="padding:26px 22px;height:100%;box-sizing:border-box;display:flex;flex-direction:column;">'
    f'<div style="font-size:13px;color:{GOLD};font-weight:800;letter-spacing:2px;margin-bottom:20px;">工序总览 · 5 步</div>'
    f'{"".join(rail_items)}'
    f'<div style="margin-top:auto;font-size:11.5px;color:rgba(255,255,255,0.5);line-height:1.6;'
    f'border-top:1px solid rgba(255,255,255,0.12);padding-top:12px;">预处理：{esc(prep)}</div>'
    f'</div>'))

# RIGHT-TOP spotlight (module 2) — main sequence as arrow chips
chips=""
for i,step in enumerate(main_seq):
    chips+=(f'<div style="flex:1;min-width:0;background:#fff;border-radius:9px;padding:12px 10px;text-align:center;'
            f'box-shadow:0 2px 8px rgba(0,0,0,0.07);border-top:3px solid {CH(i)};">'
            f'<div style="font-size:12.5px;color:{T};line-height:1.4;font-weight:600;">{esc(step)}</div></div>')
    if i<len(main_seq)-1:
        chips+=f'<div style="display:flex;align-items:center;color:{A};font-size:18px;font-weight:800;flex-shrink:0;">→</div>'
parts.append(box(31,10,64,30,
    f"background:{CB};border-radius:12px;box-shadow:0 4px 14px rgba(0,0,0,0.09);overflow:hidden;",
    f'<div style="padding:16px 20px;height:100%;box-sizing:border-box;display:flex;flex-direction:column;">'
    f'<div style="font-size:16px;font-weight:800;color:{S};margin-bottom:14px;display:flex;align-items:center;gap:9px;">'
    f'<span style="width:20px;height:20px;border-radius:6px;background:{A};color:#fff;font-size:12px;display:flex;'
    f'align-items:center;justify-content:center;">04</span>主工序 · 熟制流程</div>'
    f'<div style="flex:1;display:flex;align-items:stretch;gap:8px;">{chips}</div></div>'))

# RIGHT-MIDDLE two detail tiles (module 3,4)
for i,(title,body) in enumerate([tile_flavor,tile_key]):
    l = 31 if i==0 else 63.5
    parts.append(box(l,42,31.5,28,
        f"background:{CB if i else P};border-radius:12px;box-shadow:0 4px 14px rgba(0,0,0,0.09);overflow:hidden;",
        f'<div style="padding:16px 20px;height:100%;box-sizing:border-box;display:flex;flex-direction:column;">'
        f'<div style="font-size:15px;font-weight:800;color:{S if i else GOLD};margin-bottom:10px;">{esc(title)}</div>'
        f'<div style="font-size:13.5px;color:{T if i else "rgba(255,255,255,0.9)"};line-height:1.7;">{esc(body)}</div></div>'))

# BOTTOM param strip (module 5)
pcells=""
for i,(num,lab) in enumerate(params):
    pcells+=(f'<div style="flex:1;text-align:center;{"border-left:1px solid rgba(var(--text-rgb),0.12);" if i else ""}">'
             f'<div style="font-size:26px;font-weight:800;color:{CH(i)};line-height:1;">{esc(num)}</div>'
             f'<div style="font-size:12px;color:rgba(var(--text-rgb),0.55);margin-top:5px;">{esc(lab)}</div></div>')
parts.append(box(31,72,64,20,
    f"background:{CB};border-radius:12px;box-shadow:0 4px 14px rgba(0,0,0,0.09);",
    f'<div style="display:flex;align-items:center;height:100%;padding:0 10px;">{pcells}</div>'))

slide=(f'<div style="position:relative;width:{W}px;height:{Hh}px;overflow:hidden;background:{BG};'
       f'font-family:{FONT};">{"".join(parts)}</div>')
with open('resources/vi/business/tokens.yaml',encoding='utf-8') as f:
    scheme=yaml.safe_load(f)['color_schemes']['deep-blue']
root=ps._build_root_vars(scheme)
resolved=ps._resolve_color_vars(slide,scheme,css_vars=True)
doc=(f'<!doctype html><html><head><meta charset="utf-8"><style>{root}\n'
     f'body{{margin:0;background:#2b2b2b;padding:40px;display:flex;justify-content:center;}}</style>'
     f'</head><body>{resolved}</body></html>')
open('data/debug/technique_multi.html','w',encoding='utf-8').write(doc)
print("wrote data/debug/technique_multi.html", len(doc), "bytes")
