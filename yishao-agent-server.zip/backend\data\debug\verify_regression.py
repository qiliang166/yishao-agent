# -*- coding: utf-8 -*-
"""Regression: ensure structural pages (cover/toc/section/summary/closing) still
fill correctly after the _fill_slide_template enhancements (bullets/cells/columns/
first-rest were purely additive; {{text}} & {{#CHAPTERS}} must be unchanged)."""
import os, sys, re, json, yaml
_B = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, _B); os.chdir(_B)
import services.ppt_service as ps

scheme = ps._load_scheme_data('business', 'deep-blue')
raw = open('data/debug/last_outline_response.txt', encoding='utf-8').read()
raw = re.sub(r'^```json\s*|\s*```$', '', raw.strip())
slides = json.loads(raw)

def try_page(pt, slide):
    vi = ps._load_style_vi_section('business', pt, 'deep-blue', resolve_vars=False, column_id='col4')
    if not vi or '## HTML 模板' not in vi:
        print(f"  {pt:<10} : no HTML template (LLM path) — skip"); return
    m = re.search(r'```html\s*\n(.*?)\n```', vi, re.DOTALL)
    html = ps._fill_slide_template(m.group(1).strip(), slide, len(slides))
    resid = re.findall(r'\{\{[^}]+\}\}', html)
    print(f"  {pt:<10} : filled OK, residual={len(resid)} {resid[:3]}")

# cover(0), toc(1), and section-like if present
for i, s in enumerate(slides):
    pt = s.get('page_type') or s.get('type')
    if pt in ('cover','toc','section','summary','closing','copyright'):
        try_page(pt, s)
print("regression check done")
