# -*- coding: utf-8 -*-
import os
from collections import Counter
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

BASE = r"D:\智绘食谱\酒店菜品\PPT模版"
FILES = {
    "花雕蒸膏蟹":   "专业厨房研习手册：花雕蒸膏蟹.pptx",
    "古厨麻香鸡":   "古厨麻香鸡（脆皮麻香鸡）菜肴研习手册.pptx",
    "土豆红焖牛腩": "土豆红焖牛腩 · 菜肴研习手册.pptx",
    "潮汕砂锅粥":   "潮汕海鲜砂锅粥 · 菜肴研习手册.pptx",
    "砂锅焗鱼头":   "砂锅焗鱼头技法的术与道 (1).pptx",
    "胡椒猪肚鸡":   "胡椒猪肚鸡 · 菜肴研习手册.pptx",
    "红葱头蒸鸡":   "菜肴研习手册：红葱头蒸鸡.pptx",
    "萝卜焖牛腩01": "萝卜焖牛腩 · 菜肴研习手册01.pptx",
    "萝卜焖牛腩1":  "萝卜焖牛腩 · 菜肴研习手册1.pptx",
    "金沙焗虾":     "金沙黄金焗虾 · 教学课件.pptx",
    "鲍鱼一品煲":   "鲍鱼一品煲 · 研习手册.pptx",
    "鹅肝蒸水蛋":   "鹅肝虾仁蒸水蛋 · 菜肴研习手册.pptx",
}

def fill_type(shape):
    try:
        return shape.fill.type
    except Exception:
        return "ERR"

picfill_pages = Counter()  # pages with picture-fill autoshapes
picfill_total = 0
picture_total = 0
picfill_dims = []

for deck, fn in FILES.items():
    prs = Presentation(os.path.join(BASE, fn))
    SW, SH = prs.slide_width, prs.slide_height
    for i, slide in enumerate(prs.slides, 1):
        has_picfill = False
        def scan(shapes):
            global picfill_total, picture_total, has_picfill
            for sh in shapes:
                st = sh.shape_type
                if st == MSO_SHAPE_TYPE.PICTURE:
                    picture_total += 1
                if st == MSO_SHAPE_TYPE.GROUP:
                    scan(sh.shapes)
                    continue
                ft = fill_type(sh)
                # fill.type 2 == picture? In python-pptx MSO_FILL: PICTURE=6, PATTERNED=2
                if ft == 6:
                    picfill_total += 1
                    has_picfill = True
                    try:
                        picfill_dims.append((round(sh.width/SW*100), round(sh.height/SH*100)))
                    except Exception:
                        pass
        scan(slide.shapes)
        if has_picfill:
            picfill_pages[deck] += 1

print("PICTURE shapes total:", picture_total)
print("PICTURE-FILL autoshapes total:", picfill_total)
print("picfill pages per deck:", dict(picfill_pages))
print("picfill dims sample:", Counter(picfill_dims).most_common(10))
