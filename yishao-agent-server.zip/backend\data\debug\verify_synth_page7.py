# -*- coding: utf-8 -*-
"""
端到端验证：真实 principle 数据 → 真实 page7 框架（principle.md）→ 走生产管线填充 →
Playwright 实测 spill/clip、残留、配色变量，并截图。证明「合成PPT」用的是真提取框架。
"""
import io, sys, json, re
from pathlib import Path
DEBUG = Path(__file__).resolve().parent
sys.path.insert(0, str(DEBUG.parents[1]))  # backend/

from services.ppt_service import (
    _select_framework_template, _fill_slide_template, _resolve_color_vars,
    _load_style_vi_section, _load_scheme_data, _build_root_vars,
)

STYLE_ID, SCHEME, COLUMN, PROJECT_ID = "business", "chinese-red", "col4", "fcf32913a82b"

# ── 取真实 principle slide 数据 ──
res = Path(r"D:\YISHAOAGENT\data\output\鲍鱼一品煲\鲍鱼一品煲_col4\result.json")
d = json.load(open(res, encoding="utf-8"))
slide = [s for s in d["slide_plan"] if s.get("type") == "principle"][0]
total = len(d["slide_plan"])

# ── 走生产管线：选框架 → 填充 → 配色变量→hex ──
vi = _load_style_vi_section(STYLE_ID, "principle", SCHEME, resolve_vars=False,
                            column_id=COLUMN, project_id=PROJECT_ID)
tmpl = _select_framework_template(vi, len(slide.get("key_points", [])))
html_vars = _fill_slide_template(tmpl, slide, total)
scheme = _load_scheme_data(STYLE_ID, SCHEME)
html = _resolve_color_vars(html_vars, scheme, css_vars=True)

# ── 组装成独立页面（:root 变量 + reset），截图用 ──
root = _build_root_vars(scheme)
doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n"
       f"*{{margin:0;padding:0;box-sizing:border-box}}</style></head>"
       f"<body style='margin:0'>{html}</body></html>")
out_html = DEBUG / "page7_synth.html"
out_html.write_text(doc, encoding="utf-8")

# ── 校验残留 / 配色 / 手写坐标 ──
resid = re.findall(r"\{\{[^}]+\}\}", html)
m_root = re.search(r":root\s*\{[^}]*\}", doc)
root_block = m_root.group(0) if m_root else ""
bad_hex = [h for h in re.findall(r"#[0-9a-fA-F]{3,8}", html)
           if h.lower() not in ("#ffffff", "#fff")]
# principle.md 模板里是否有手写坐标注释残留（应无 chart_color 循环、无我编的 flex:1 1 0 冒充）
uses_flex_fake = "flex:1 1 0" in tmpl

# ── Playwright 实测零溢出 ──
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.set_content(doc, wait_until="networkidle")
    meas = pg.evaluate("""()=>{const W=1280,H=720;let sp=0,cl=0;
      for(const el of document.querySelectorAll('body *')){const b=el.getBoundingClientRect();
        sp=Math.max(sp,Math.max(0,b.right-W),Math.max(0,b.bottom-H),Math.max(0,-b.left),Math.max(0,-b.top));
        if(el.children.length===0&&el.textContent.trim()){const fs=parseFloat(getComputedStyle(el).fontSize)||14;
          const oh=el.scrollHeight-el.clientHeight;if(oh>=fs*0.6)cl=Math.max(cl,oh);}}
      return{sp:Math.round(sp),cl:Math.round(cl)};}""")
    pg.screenshot(path=str(DEBUG / "page7_synth.png"))
    b.close()

w = io.open(1, "w", encoding="utf-8", closefd=False)
w.write("=" * 60 + "\n")
w.write("端到端验证 principle page7（真实数据 + 真实提取框架）\n")
w.write("=" * 60 + "\n")
w.write(f"[框架来源] cap 命中: {'真实4竖栏(cap:2-4)' if not uses_flex_fake else '⚠ 仍是手写flex'}\n")
w.write(f"[零溢出]   spill={meas['sp']}  clip={meas['cl']}\n")
w.write(f"[配色变量] 非白硬编码hex = {len(bad_hex)} {bad_hex[:4]}\n")
w.write(f"[无残留]   占位符 = {len(resid)} {resid[:6]}\n")
ok = (meas['sp'] == 0 and meas['cl'] == 0 and len(bad_hex) == 0 and len(resid) == 0 and not uses_flex_fake)
w.write(f"PROOF: {'PASS ✅ 合成用的是真提取框架' if ok else 'FAIL ❌'}\n")
w.write(f"HTML: {out_html}\n截图: {DEBUG / 'page7_synth.png'}\n")
w.flush()
