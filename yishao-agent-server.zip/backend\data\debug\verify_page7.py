# -*- coding: utf-8 -*-
"""
验证 page7：用真实几何骨架 + 新项目内容渲染，Playwright 实测零溢出，截图。
证明：几何 100% 来自 PPT 提取的 JSON（非手写），内容是新项目的。
配色走 VI 变量（此处用 chinese-red 演示，换配色只改 :root）。
"""
import io, sys, json, re
from pathlib import Path
DEBUG = Path(__file__).resolve().parent
sys.path.insert(0, str(DEBUG.parents[1]))

from frame_renderer import render_frame, assign_content_keys
from services.ppt_service import _build_root_vars, _load_scheme_data

# ── 加载真实 page7 框架 ──
d = json.load(open(DEBUG / "frameset_abalone.json", encoding="utf-8"))
frame = assign_content_keys([f for f in d["frames"] if f["source_page"] == 7][0])

# ── 新项目内容（制造业SOP，证明"真几何+新内容"，非鲍鱼）──
CONTENT = {
    "page_title#0": "工序之道：品质叠加的多维构建",
    "page_number#0": "07",
    "item_index#0": "01", "item_title#0": "备料", "caption#0": "基础物料层",
    "body_text#0": "来料检验：抽样比对规格\n分料上线：按工单配比\n作用：确保源头一致性",
    "item_index#1": "02", "item_title#1": "加工", "caption#1": "核心成型骨架",
    "body_text#1": "参数设定：温度压力校准\n首件确认：三检合一\n作用：锁定关键尺寸",
    "item_index#2": "03", "item_title#2": "装配", "caption#2": "独立功能注入",
    "body_text#2": "扭矩管控：分级拧紧\n防错测试：逐台通电\n作用：保证功能可靠",
    "item_index#3": "04", "item_title#3": "终检", "caption#3": "点睛之笔",
    "body_text#3": "全尺寸复测\n作用：出厂前提供最终品质背书",
    "lead_text#0": "分段管控 vs 一次性放行",
    "body_text#4": "四段式管控（本SOP）\n每工序保持独立质检节点，问题当段拦截，良率稳定可追溯。",
    "body_text#5": "一次性放行（常见错误）\n全流程末端才检，缺陷批量流出，返工成本高、追溯难。",
    "footnote#0": "Source: 项目 SOP · 工序质量构建",
}

html = render_frame(frame, CONTENT)

# ── 配色：用真实 tokens.yaml 的 chinese-red，走 :root 变量 ──
scheme = _load_scheme_data("business", "chinese-red")
root = _build_root_vars(scheme)
doc = (f"<!doctype html><html><head><meta charset='utf-8'><style>{root}\n"
       f"*{{margin:0;padding:0;box-sizing:border-box}}</style></head>"
       f"<body style='margin:0'>{html}</body></html>")
out_html = DEBUG / "page7_from_ppt.html"
out_html.write_text(doc, encoding="utf-8")

# ── 校验：几何来自JSON / 配色变量 / 无残留 ──
resid = re.findall(r"\{\{[^}]+\}\}", html)
# 检查渲染器源码里没有手写坐标（%数字）—— 几何应全来自 JSON
rsrc = (DEBUG / "frame_renderer.py").read_text(encoding="utf-8")
hardcoded_coords = re.findall(r"(?:left|top|width|height):\s*\d+\.?\d*%", rsrc)
bad_hex = [h for h in re.findall(r"#[0-9a-fA-F]{3,8}", html) if h.lower() not in ("#ffffff", "#fff")]

# ── Playwright 实测零溢出 ──
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.set_content(doc, wait_until="networkidle")
    m = pg.evaluate("""()=>{const W=1280,H=720;let sp=0,cl=0;
      for(const el of document.querySelectorAll('body *')){const b=el.getBoundingClientRect();
        sp=Math.max(sp,Math.max(0,b.right-W),Math.max(0,b.bottom-H),Math.max(0,-b.left),Math.max(0,-b.top));
        if(el.children.length===0&&el.textContent.trim()){const fs=parseFloat(getComputedStyle(el).fontSize)||14;
          const oh=el.scrollHeight-el.clientHeight;if(oh>=fs*0.6)cl=Math.max(cl,oh);}}
      return{sp:Math.round(sp),cl:Math.round(cl)};}""")
    pg.screenshot(path=str(DEBUG / "page7_from_ppt.png"))
    b.close()

print("=" * 60)
print("验证 page7（真实几何 + 新项目内容）")
print("=" * 60)
print(f"[几何来源] 渲染器源码手写坐标数量 = {len(hardcoded_coords)} （应为0，几何全来自JSON）")
print(f"[零溢出]   spill={m['sp']}  clip={m['cl']}")
print(f"[配色变量] 非白硬编码hex = {len(bad_hex)} {bad_hex[:4]}")
print(f"[无残留]   占位符 = {len(resid)}")
print(f"[容器数]   渲染 {len(frame['containers'])} 个容器（4竖栏+对比带+页头页脚）")
ok = (len(hardcoded_coords) == 0 and m['sp'] == 0 and m['cl'] == 0 and len(bad_hex) == 0 and len(resid) == 0)
print(f"PROOF: {'PASS ✅ 这是从PPT提取的真实框架' if ok else 'FAIL ❌'}")
print(f"成品HTML: {out_html}")
print(f"截图:     {DEBUG / 'page7_from_ppt.png'}")