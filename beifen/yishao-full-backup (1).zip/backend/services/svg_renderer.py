"""Style loader — reads PPT-Agent style YAMLs and exposes metadata for the frontend."""
import os
import sys
import json
import yaml

if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.join(sys._MEIPASS, 'backend')
else:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_STYLE_GROUPS = {
    "blueprint": "Tech / Dark",
    "tech": "Tech / Dark",
    "intuition-machine": "Tech / Dark",
    "business": "Professional",
    "minimal": "Professional",
    "notion": "Professional",
    "scientific": "Professional",
    "editorial-infographic": "Professional",
    "creative": "Creative",
    "bold-editorial": "Creative",
    "vector-illustration": "Creative",
    "chalkboard": "Thematic",
    "fantasy-animation": "Thematic",
    "pixel-art": "Thematic",
    "vintage": "Thematic",
    "nature": "Thematic",
    "sketch-notes": "Thematic",
    "watercolor": "Thematic",
    "watercolor": "Thematic",
    "sketch-notes": "Thematic",
}


def _resolve_styles_dir():
    d = os.path.join(BASE_DIR, "data", "styles")
    if os.path.isdir(d):
        return d
    return ""


def _load_index():
    p = os.path.join(BASE_DIR, "data", "styles", "index.json")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"resources": []}


class StyleLoader:
    def __init__(self):
        self._styles_dir = _resolve_styles_dir()
        self._index = _load_index()

    def list_styles(self):
        styles_by_group = {}
        for entry in self._index.get("resources", []):
            if entry.get("domain") != "style":
                continue
            style_id = entry["id"].replace("style-", "")
            yaml_path = os.path.join(self._styles_dir, f"{style_id}.yaml")
            colors = {"primary": "", "secondary": "", "accent": "", "background": "", "text": "", "card_bg": "", "chart_colors": []}
            mood = ""
            if os.path.exists(yaml_path):
                try:
                    with open(yaml_path, "r", encoding="utf-8") as f:
                        data = yaml.safe_load(f)
                    cs = data.get("color_scheme", {})
                    colors = {
                        "primary": cs.get("primary", ""),
                        "secondary": cs.get("secondary", ""),
                        "accent": cs.get("accent", ""),
                        "background": cs.get("background", ""),
                        "text": cs.get("text", ""),
                        "card_bg": cs.get("card_bg", ""),
                        "chart_colors": cs.get("chart_colors") or [],
                    }
                    mood = data.get("mood", "")
                except Exception:
                    pass

            group = _STYLE_GROUPS.get(style_id, "Other")
            item = {
                "id": style_id,
                "name": entry.get("name", style_id),
                "group": group,
                "mood": mood,
                "keywords": entry.get("keywords", []),
                "colors": colors,
            }
            styles_by_group.setdefault(group, []).append(item)

        return [
            {"group": g, "styles": s}
            for g, s in styles_by_group.items()
        ]
